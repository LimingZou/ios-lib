//
//  TKRouter.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <Foundation/Foundation.h>

@class TKViewController, TKViewModel;
@interface TKRouter : NSObject

/// Retrieves the shared router instance.
///
/// Returns the shared router instance.
+ (instancetype)sharedInstance;

/// Retrieves the view corresponding to the given view model.
///
/// viewModel - The view model
///
/// Returns the view corresponding to the given view model.
- (TKViewController *)viewControllerForViewModel:(TKViewModel *)viewModel;

+ (void)registerController:(Class)controller withModule:(Class)moduleClass;

+ (NSDictionary *)allRegisteredModules;

@end
