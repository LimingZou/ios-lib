//
//  TKRouter.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKRouter.h"
#import "TKViewController.h"
#import "TKViewModel.h"

@interface TKRouter ()

@property (nonatomic, strong) NSMutableDictionary *moduleDict; // <moduleName, moduleClass>

@end

@implementation TKRouter


+ (instancetype)sharedInstance {
    static TKRouter *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        sharedInstance.moduleDict = [NSMutableDictionary dictionary];
    });
    return sharedInstance;
}

- (TKViewController *)viewControllerForViewModel:(TKViewModel *)viewModel {
    NSString *viewController = self.moduleDict[NSStringFromClass(viewModel.class)];
    
    NSParameterAssert([NSClassFromString(viewController) isSubclassOfClass:[TKViewController class]]);
    NSParameterAssert([NSClassFromString(viewController) instancesRespondToSelector:@selector(initWithViewModel:)]);
    return [[NSClassFromString(viewController) alloc] initWithViewModel:viewModel];
}

+ (void)registerController:(Class)controller withModule:(Class)moduleClass{
    [TKRouter.sharedInstance.moduleDict setObject:NSStringFromClass(controller) forKey:NSStringFromClass(moduleClass)];
}

+ (NSArray *)allRegisteredModules {
    return TKRouter.sharedInstance.moduleDict.allValues;
}

@end
