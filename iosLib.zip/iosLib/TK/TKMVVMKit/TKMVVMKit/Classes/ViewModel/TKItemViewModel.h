//
//  TKItemViewModel.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKItemViewModel : NSObject

@property(nonatomic, strong) NSIndexPath *indexPath;
@property(nonatomic, assign) Class cellClass;
@property (nonatomic, assign) CGFloat height;

@end

NS_ASSUME_NONNULL_END
