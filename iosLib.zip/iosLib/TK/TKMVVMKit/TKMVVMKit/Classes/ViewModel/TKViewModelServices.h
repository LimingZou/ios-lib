//
//  TKViewModelServices.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TKGraphApi/TKGClient.h>

#import "TKNavigationProtocol.h"

@protocol TKViewModelServices <NSObject, TKNavigationProtocol>

@required

/// A reference to OCTClient instance.
@property (nonatomic, strong) TKGClient *client;


@end
