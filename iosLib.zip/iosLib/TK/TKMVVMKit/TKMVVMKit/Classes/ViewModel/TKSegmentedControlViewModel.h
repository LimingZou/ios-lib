//
//  TKSegmentedControlViewModel.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKSegmentedControlViewModel : TKViewModel

@end

NS_ASSUME_NONNULL_END
