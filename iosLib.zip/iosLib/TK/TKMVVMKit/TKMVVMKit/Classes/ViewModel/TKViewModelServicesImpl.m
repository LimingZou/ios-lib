//
//  TKViewModelServicesImpl.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewModelServicesImpl.h"

static NSMutableDictionary *moduleDict;

@implementation TKViewModelServicesImpl

@synthesize client = _client;

- (instancetype)init {
    self = [super init];
    if (self) {
    }
    return self;
}

- (void)pushViewModel:(TKViewModel *)viewModel animated:(BOOL)animated {}

- (void)popViewModelAnimated:(BOOL)animated {}

- (void)dismiss{}

- (void)popToRootViewModelAnimated:(BOOL)animated {}

- (void)presentViewModel:(TKViewModel *)viewModel animated:(BOOL)animated completion:(VoidBlock)completion {}

- (void)dismissViewModelAnimated:(BOOL)animated completion:(VoidBlock)completion {}

- (void)resetRootViewModel:(TKViewModel *)viewModel {}


+ (void)registerService:(Protocol*)serviceProtocol withModule:(Class)moduleClass{
    NSString *protocolStr = NSStringFromProtocol(serviceProtocol);
    [moduleDict setObject:moduleClass forKey:protocolStr];
}


+ (void)unregisterService:(Protocol*)serviceProtocol{
    NSString *protocolStr = NSStringFromProtocol(serviceProtocol);
    [moduleDict removeObjectForKey:protocolStr];
}


+ (id)moduleByService:(Protocol*)serviceProtocol{
    NSString *protocolStr = NSStringFromProtocol(serviceProtocol);
    return [moduleDict objectForKey:protocolStr];
}

@end

