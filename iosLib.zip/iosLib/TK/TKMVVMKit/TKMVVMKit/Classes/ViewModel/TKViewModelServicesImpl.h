//
//  TKViewModelServicesImpl.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TKViewModelServices.h"

@interface TKViewModelServicesImpl : NSObject<TKViewModelServices>

/**
 Method to register the module srevice with module class.
 Each Module do the registeration before app launch event, like in the +load method.
 @param serviceProtocol the protocol for the module's service
 @param moduleClass The class of the module
 */
+ (void)registerService:(Protocol*)serviceProtocol
             withModule:(Class)moduleClass;

/**
 Method to unregister service
 @param serviceProtocol the protocol for the module's service
 */
+ (void)unregisterService:(Protocol*)serviceProtocol;

/**
 Get module instance by service protocol.
 @param serviceProtocol the service protocol used to register the module
 @return module instance
 */
+ (id)moduleByService:(Protocol*)serviceProtocol;

@end
