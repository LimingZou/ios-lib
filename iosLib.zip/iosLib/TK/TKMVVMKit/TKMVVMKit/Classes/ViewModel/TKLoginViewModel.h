//
//  TKLoginViewModel.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/25.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKLoginViewModel : TKViewModel

/// The username entered by the user.
@property (nonatomic, copy) NSString *username;

/// The password entered by the user.
@property (nonatomic, copy) NSString *password;

@property (nonatomic, strong, readonly) RACSignal *validLoginSignal;
/// The command of login button.
@property (nonatomic, strong, readonly) RACCommand *loginCommand;

@end

NS_ASSUME_NONNULL_END
