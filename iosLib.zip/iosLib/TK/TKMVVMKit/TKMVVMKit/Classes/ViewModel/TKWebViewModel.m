//
//  TKWebViewModel.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKWebViewModel.h"

@implementation TKWebViewModel

- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params {
    self = [super initWithServices:services params:params];
    if (self) {
        self.request = params[@"request"];
    }
    return self;
}

@end
