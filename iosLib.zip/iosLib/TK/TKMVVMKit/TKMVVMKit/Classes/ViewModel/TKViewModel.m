//
//  TKViewModel.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewModel.h"

@interface TKViewModel ()

@property (nonatomic, strong, readwrite) id<TKViewModelServices> services;
@property (nonatomic, copy, readwrite) NSDictionary *params;

@property (nonatomic, strong, readwrite) RACSubject *errors;
@property (nonatomic, strong, readwrite) RACSubject *willDisappearSignal;
@property (nonatomic, strong, readwrite) RACSubject *willDeallocSignal;

@end

@implementation TKViewModel

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    TKViewModel *viewModel = [super allocWithZone:zone];
    
    @weakify(viewModel)
    [[viewModel
        rac_signalForSelector:@selector(initWithServices:params:)]
        subscribeNext:^(id x) {
            @strongify(viewModel)
            [viewModel initialize];
        }];
    
    return viewModel;
}

- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params {
    self = [super init];
    if (self) {
        self.shouldFetchLocalDataOnViewModelInitialize = YES;
        self.shouldRequestRemoteDataOnViewDidLoad = YES;
        self.title    = params[@"title"];
        self.services = services;
        self.params   = params;
    }
    return self;
}

- (RACSubject *)errors {
    if (!_errors) _errors = [RACSubject subject];
    return _errors;
}

- (RACSubject *)willDisappearSignal {
    if (!_willDisappearSignal) _willDisappearSignal = [RACSubject subject];
    return _willDisappearSignal;
}

- (RACSubject *)willDeallocSignal {
    if (!_willDeallocSignal) _willDeallocSignal = [RACSubject subject];
    return _willDeallocSignal;
}

- (void)initialize {}

- (void)dealloc{
    NSLog(@"%@ dealloc",self);
}

@end
