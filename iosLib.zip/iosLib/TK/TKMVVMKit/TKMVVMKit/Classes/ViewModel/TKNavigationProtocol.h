//
//  TKNavigationProtocol.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TKBasic/TKConstant.h>

#import "TKViewModel.h"

@protocol TKNavigationProtocol <NSObject>

/// Pushes the corresponding view controller.
///
/// Uses a horizontal slide transition.
/// Has no effect if the corresponding view controller is already in the stack.
///
/// viewModel - the view model
/// animated  - use animation or not
- (void)pushViewModel:(TKViewModel *)viewModel animated:(BOOL)animated;



/// Pops the top view controller in the stack.
///
/// animated - use animation or not
- (void)popViewModelAnimated:(BOOL)animated;

/// Pops until there's only a single view controller left on the stack.
///
/// animated - use animation or not
- (void)popToRootViewModelAnimated:(BOOL)animated;

/// Present the corresponding view controller.
///
/// viewModel  - the view model
/// animated   - use animation or not
/// completion - the completion handler
- (void)presentViewModel:(TKViewModel *)viewModel animated:(BOOL)animated completion:(VoidBlock)completion;

/// Dismiss the popup view controller.
///
- (void)dismiss;

/// Dismiss the presented view controller.
///
/// animated   - use animation or not
/// completion - the completion handler
- (void)dismissViewModelAnimated:(BOOL)animated completion:(VoidBlock)completion;

/// Reset the corresponding view controller as the root view controller of the application's window.
///
/// viewModel - the view model
- (void)resetRootViewModel:(TKViewModel *)viewModel;

@end

