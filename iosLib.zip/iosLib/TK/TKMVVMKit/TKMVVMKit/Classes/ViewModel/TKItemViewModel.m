//
//  TKItemViewModel.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKItemViewModel.h"

@implementation TKItemViewModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.height = 64.f;
    }
    return self;
}

@end
