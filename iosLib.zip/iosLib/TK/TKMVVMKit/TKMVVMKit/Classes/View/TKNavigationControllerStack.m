//
//  TKNavigationControllerStack.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKNavigationControllerStack.h"
#import "TKRouter.h"
#import "TKNavigationController.h"
#import "TKTabBarController.h"
#import "TKViewControllerAnimatedTransition.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import <TKBasic/TKConstant.h>

@interface TKNavigationControllerStack () <UINavigationControllerDelegate>

@property (nonatomic, strong) id<TKViewModelServices> services;
@property (nonatomic, strong) NSMutableArray *navigationControllers;
@property (nonatomic, strong) NSMutableArray *popupControllers;

@end

@implementation TKNavigationControllerStack

- (instancetype)initWithServices:(id<TKViewModelServices>)services {
    self = [super init];
    if (self) {
        self.services = services;
        self.navigationControllers = [[NSMutableArray alloc] init];
        self.popupControllers = [[NSMutableArray alloc] init];
        [self registerNavigationHooks];
    }
    return self;
}

- (void)pushNavigationController:(UINavigationController *)navigationController {
    if ([self.navigationControllers containsObject:navigationController]) return;
    navigationController.delegate = self;
    [self.navigationControllers addObject:navigationController];
}

- (void)pushPopupController:(UIViewController *)popupController {
    if ([self.popupControllers containsObject:popupController]) return;
    [self.popupControllers addObject:popupController];
}

- (UINavigationController *)popNavigationController {
    UINavigationController *navigationController = self.navigationControllers.lastObject;
    [self.navigationControllers removeLastObject];
    return navigationController;
}

- (UINavigationController *)topNavigationController {
    return self.navigationControllers.lastObject;
}

- (void)registerNavigationHooks {
    @weakify(self)
    [[(NSObject *)self.services
        rac_signalForSelector:@selector(pushViewModel:animated:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
         TKViewController *topViewController = (TKViewController *)[self.navigationControllers.lastObject topViewController];
         if (topViewController.tabBarController) {
             topViewController.snapshot = [topViewController.tabBarController.view snapshotViewAfterScreenUpdates:NO];
         } else {
             topViewController.snapshot = [[self.navigationControllers.lastObject view] snapshotViewAfterScreenUpdates:NO];
         }
         UIViewController *viewController = (UIViewController *)[TKRouter.sharedInstance viewControllerForViewModel:tuple.first];
         viewController.hidesBottomBarWhenPushed = YES;
         [self.navigationControllers.lastObject pushViewController:viewController animated:[tuple.second boolValue]];
    }];

    [[(NSObject *)self.services
        rac_signalForSelector:@selector(popViewModelAnimated:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        [(UINavigationController *)self.navigationControllers.lastObject popViewControllerAnimated:[tuple.first boolValue]];
    }];

    [[(NSObject *)self.services
        rac_signalForSelector:@selector(popToRootViewModelAnimated:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        [(UINavigationController *)self.navigationControllers.lastObject popToRootViewControllerAnimated:[tuple.first boolValue]];
    }];

    [[(NSObject *)self.services
        rac_signalForSelector:@selector(presentViewModel:animated:completion:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        UIViewController *viewController = (UIViewController *)[TKRouter.sharedInstance viewControllerForViewModel:tuple.first];

        UINavigationController *presentingViewController = self.navigationControllers.lastObject;
        if (![viewController isKindOfClass:UINavigationController.class]) {
            viewController = [[TKNavigationController alloc] initWithRootViewController:viewController];
        }
        viewController.modalPresentationStyle = UIModalPresentationFullScreen;
        [self pushNavigationController:(UINavigationController *)viewController];
            
        [presentingViewController presentViewController:viewController animated:[tuple.second boolValue] completion:tuple.third];
    }];


    [[(NSObject *)self.services
        rac_signalForSelector:@selector(dismissViewModelAnimated:completion:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        [self.navigationControllers.lastObject dismissViewControllerAnimated:[tuple.first boolValue] completion:tuple.second];
        [self popNavigationController];
    }];

    [[(NSObject *)self.services
        rac_signalForSelector:@selector(resetRootViewModel:)]
        subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        [self.navigationControllers removeAllObjects];

        UIViewController *viewController = (UIViewController *)[TKRouter.sharedInstance viewControllerForViewModel:tuple.first];

        if (![viewController isKindOfClass:[UINavigationController class]] &&
            ![viewController isKindOfClass:[TKTabBarController class]]) {
            viewController = [[TKNavigationController alloc] initWithRootViewController:viewController];
            [self pushNavigationController:(UINavigationController *)viewController];
        }

        ([UIApplication sharedApplication].delegate).window.rootViewController = viewController;
    }];
}

#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (IOS11) {
        viewController.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:NULL];
    }
}

- (id<UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
                         interactionControllerForAnimationController:(TKViewControllerAnimatedTransition *)animationController {
    return animationController.fromViewController.interactivePopTransition;
}

- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                  animationControllerForOperation:(UINavigationControllerOperation)operation
                                               fromViewController:(TKViewController *)fromVC
                                                 toViewController:(TKViewController *)toVC {
    if (fromVC.interactivePopTransition != nil) {
        return [[TKViewControllerAnimatedTransition alloc] initWithNavigationControllerOperation:operation
                                                                               fromViewController:fromVC
                                                                                 toViewController:toVC];
    }
    return nil;
}

@end
