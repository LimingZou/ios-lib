//
//  TKIOS13InsetGroupedTableView.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
/**
 A subclass of UITableView that back-ports the "inset grouped" style
 that was introduced in iOS 13 to previous versions of iOS.
 Defaults back to the native system implementation on iOS 13 and above.
 */
NS_SWIFT_NAME(InsetGroupedTableView)
@interface TKIOS13InsetGroupedTableView : UITableView

@end

NS_ASSUME_NONNULL_END
