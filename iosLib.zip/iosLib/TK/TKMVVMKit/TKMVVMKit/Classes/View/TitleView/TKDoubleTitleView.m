//
//  TKDoubleTitleView.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKDoubleTitleView.h"
#import <ReactiveObjC/ReactiveObjC.h>

@interface TKDoubleTitleView ()

@property (nonatomic, strong, readwrite) UILabel *titleLabel;
@property (nonatomic, strong, readwrite) UILabel *subtitleLabel;

@end

@implementation TKDoubleTitleView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initialize];
    }
    return self;
}

- (void)initialize {
    [self addSubview:self.titleLabel];
    [self addSubview:self.subtitleLabel];
    
    @weakify(self)
    RACSignal *titleLabelSignal = [RACObserve(self.titleLabel, text) doNext:^(id x) {
        @strongify(self)
        [self.titleLabel sizeToFit];
    }];
    
    RACSignal *subtitleLabelSignal = [RACObserve(self.subtitleLabel, text) doNext:^(id x) {
        @strongify(self)
        [self.subtitleLabel sizeToFit];
    }];
    
    [[RACSignal combineLatest:@[ titleLabelSignal, subtitleLabelSignal ]] subscribeNext:^(RACTuple *tuple) {
        @strongify(self)
        self.frame = CGRectMake(CGRectGetMinX(self.frame), CGRectGetMinY(self.frame), MAX(CGRectGetWidth(self.titleLabel.frame), CGRectGetWidth(self.subtitleLabel.frame)), 44);
    }];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGRect titleLabelFrame = self.titleLabel.frame;
    titleLabelFrame.size.width = MIN(CGRectGetWidth(self.titleLabel.frame), CGRectGetWidth(self.frame));
    titleLabelFrame.origin.x = CGRectGetWidth(self.frame) / 2 - CGRectGetWidth(titleLabelFrame) / 2;
    titleLabelFrame.origin.y = 4;
    self.titleLabel.frame = titleLabelFrame;
    
    CGRect subtitleLabelFrame = self.subtitleLabel.frame;
    subtitleLabelFrame.size.width = MIN(CGRectGetWidth(self.subtitleLabel.frame), CGRectGetWidth(self.frame));
    subtitleLabelFrame.origin.x = CGRectGetWidth(self.frame) / 2 - CGRectGetWidth(subtitleLabelFrame) / 2;
    subtitleLabelFrame.origin.y = CGRectGetHeight(self.frame) - 4 - CGRectGetHeight(self.subtitleLabel.frame);
    self.subtitleLabel.frame = subtitleLabelFrame;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:17];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.textColor = [UINavigationBar appearance].titleTextAttributes[NSForegroundColorAttributeName];
    }
    return _titleLabel;
}

- (UILabel *)subtitleLabel {
    if (!_subtitleLabel) {
        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.font = [UIFont systemFontOfSize:13];
        _subtitleLabel.textAlignment = NSTextAlignmentCenter;
        _subtitleLabel.textColor = [UINavigationBar appearance].titleTextAttributes[NSForegroundColorAttributeName];
    }
    return _subtitleLabel;
}

@end
