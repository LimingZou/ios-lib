//
//  TKTableViewCell.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TKReactiveView.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKTableViewCell : UITableViewCell<TKReactiveView>

@property (nonatomic, weak) UITableView *tableView;

@property (nonatomic, readonly) CGFloat cellHeight;

@end

NS_ASSUME_NONNULL_END
