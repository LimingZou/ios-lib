//
//  TKScrollViewController.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKScrollViewController : TKViewController<UIScrollViewDelegate>

@property(nonatomic, strong) UIScrollView *scrollview;

- (UIEdgeInsets)contentInset;
@end

NS_ASSUME_NONNULL_END
