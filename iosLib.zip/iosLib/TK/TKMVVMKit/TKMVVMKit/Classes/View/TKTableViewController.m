//
//  TKTableViewController.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKTableViewController.h"
#import "TKTableViewModel.h"
#import "TKFPSLabel.h"
#import "TKTableViewCell.h"
#import "TKItemViewModel.h"
#import "TKIOS13InsetGroupedTableView.h"
#import "CBStoreHouseRefreshControl.h"
#import "TKFPSLabel.h"
#import "SVPullToRefresh.h"
#import <TKBasic/TKConstant.h>

@interface TKTableViewController ()

@property (nonatomic, strong, readwrite) UISearchBar *searchBar;
@property (nonatomic, strong, readwrite) UITableView *tableView;

@property (nonatomic, strong) TKFPSLabel *fpsLabel;

@property (nonatomic, strong, readonly) TKTableViewModel *viewModel;
@property (nonatomic, strong, readwrite) CBStoreHouseRefreshControl *refreshControl;

@property(nonatomic, assign, readwrite) UITableViewStyle style;
/// Compatible with ios13 InsetGrouped style,  UITableViewStyleInsetGrouped
@property(nonatomic, assign, readwrite) BOOL openInsetGrouped;
@end

@implementation TKTableViewController

@dynamic viewModel;

- (instancetype)initWithStyle:(UITableViewStyle)style {
    if (self = [super init]) {
        _style = style;
    }
    return self;
}

- (instancetype)init {
    if (self = [super init]) {
        return [self initWithStyle:UITableViewStylePlain];
    }
    return self;
}

- (instancetype)initWithViewModel:(TKViewModel *)viewModel {
    self = [super initWithViewModel:viewModel];
    if (self) {
        if ([viewModel shouldRequestRemoteDataOnViewDidLoad]) {
            @weakify(self)
            [[self rac_signalForSelector:@selector(viewDidLoad)] subscribeNext:^(id x) {
                @strongify(self)
                [self.viewModel.requestRemoteDataCommand execute:@1];
            }];
        }
        self.style = self.viewModel.style;
    }
    return self;
}

-(UITableView *)tableView
{
    if ( nil == _tableView ) {
        if (UITableViewStyleGrouped == self.style && self.viewModel.enabledIOS13)
            _tableView = [[TKIOS13InsetGroupedTableView alloc] initWithFrame:self.view.bounds style:self.style];
        else
            _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:self.style];
        _tableView.backgroundColor = HexRGB(0xFFFFFF);
        _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.emptyDataSetDelegate = self;
        _tableView.emptyDataSetSource = self;
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (UISearchBar *)searchBar
{
    if ( nil == _searchBar) {
        _searchBar = [[UISearchBar alloc] init];
        _searchBar.delegate = self;
        [self.view addSubview:_searchBar];
    }
    return _searchBar;
}

- (void)setView:(UIView *)view {
    [super setView:view];
    if ([view isKindOfClass:UITableView.class]) self.tableView = (UITableView *)view;
}

- (UIEdgeInsets)contentInset {
    return IS_IPHONEX_SET ? UIEdgeInsetsMake(88, 0, 0, 0) : UIEdgeInsetsMake(64, 0, 0, 0);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        self.tableView.insetsContentViewsToSafeArea = NO;
        self.tableView.sectionFooterHeight = CGFLOAT_MIN;
        self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    if (self.searchBar != nil) {
        UIView *tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
        self.tableView.tableHeaderView = tableHeaderView;

        [tableHeaderView addSubview:self.searchBar];

        self.searchBar.translatesAutoresizingMaskIntoConstraints = NO;

        [tableHeaderView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[searchBar]|"
                                                                                options:0
                                                                                metrics:nil
                                                                                  views:@{ @"searchBar": self.searchBar }]];

        [tableHeaderView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[searchBar]|"
                                                                                options:0
                                                                                metrics:nil
                                                                                  views:@{ @"searchBar": self.searchBar }]];
    }

    self.tableView.contentOffset = CGPointMake(0, CGRectGetHeight(self.searchBar.frame) - self.contentInset.top);
    self.tableView.contentInset  = self.contentInset;
    self.tableView.scrollIndicatorInsets = self.contentInset;
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    
    self.tableView.separatorColor = HexRGB(0xEEEEEE);
    self.tableView.separatorInset = UIEdgeInsetsZero;
    
    self.tableView.sectionIndexColor = [UIColor darkGrayColor];
    self.tableView.sectionIndexBackgroundColor = [UIColor clearColor];
    self.tableView.sectionIndexMinimumDisplayRowCount = 20;
    

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];

    @weakify(self)
    if (self.viewModel.shouldPullToRefresh) {
        self.refreshControl = [CBStoreHouseRefreshControl attachToScrollView:self.tableView
                                                                      target:self
                                                               refreshAction:@selector(refreshTriggered:)
                                                                       plist:@"storehouse"
                                                                       color:HexRGB(0xEFF3F6)
                                                                   lineWidth:1.5
                                                                  dropHeight:80
                                                                       scale:1
                                                        horizontalRandomness:150
                                                     reverseLoadingAnimation:YES
                                                     internalAnimationFactor:0.5];
    }

    if (self.viewModel.shouldInfiniteScrolling) {
        [self.tableView addInfiniteScrollingWithActionHandler:^{
            @strongify(self)
            [[[self.viewModel.requestRemoteDataCommand
                execute:@(self.viewModel.page + 1)]
                deliverOnMainThread]
                subscribeNext:^(NSArray *results) {
                    @strongify(self)
                    self.viewModel.page += 1;
                } error:^(NSError *error) {
                    @strongify(self)
                    [self.tableView.infiniteScrollingView stopAnimating];
                } completed:^{
                    @strongify(self)
                    [self.tableView.infiniteScrollingView stopAnimating];
                }];
        }];

        RAC(self.tableView, showsInfiniteScrolling) = [[RACObserve(self.viewModel, dataSource)
            deliverOnMainThread]
            map:^(NSArray *dataSource) {
                @strongify(self)
                NSUInteger count = 0;
                for (NSArray *array in dataSource) {
                    count += array.count;
                }
                return @(count >= self.viewModel.perPage);
        }];
    }

#if DEBUG
    self.fpsLabel = [[TKFPSLabel alloc] init];
    [self.view insertSubview:self.fpsLabel atIndex:MAXFLOAT];

    CGRect frame = self.fpsLabel.frame;
    frame.origin.y = CGRectGetHeight(self.view.frame) - self.contentInset.bottom - 12 - frame.size.height;
    frame.origin.x = 12;
    self.fpsLabel.frame = frame;
    self.fpsLabel.alpha  = 1;
    self.fpsLabel.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin;

    [self.fpsLabel sizeToFit];
#endif
}
#if DEBUG
- (void)viewDidLayoutSubviews {
    [self.view bringSubviewToFront:self.fpsLabel];
}
#endif

- (void)dealloc {
    _tableView.dataSource = nil;
    _tableView.delegate = nil;
}

- (void)bindViewModel {
    [super bindViewModel];
    
    @weakify(self)
    [[[RACObserve(self.viewModel, dataSource)
        distinctUntilChanged]
        deliverOnMainThread]
        subscribeNext:^(id x) {
            @strongify(self)
            [self reloadData];
        }];

    [self.viewModel.requestRemoteDataCommand.executing subscribeNext:^(NSNumber *executing) {
        @strongify(self)
        UIView *emptyDataSetView = [self.tableView.subviews.rac_sequence objectPassingTest:^(UIView *view) {
            return [NSStringFromClass(view.class) isEqualToString:@"DZNEmptyDataSetView"];
        }];
        emptyDataSetView.alpha = 1.0 - executing.floatValue;
    }];
}

- (void)reloadData {
    [self.tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView dequeueReusableCellWithIdentifier:(NSString *)identifier forIndexPath:(NSIndexPath *)indexPath {
    return [tableView dequeueReusableCellWithIdentifier:identifier forIndexPath:indexPath];
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath withObject:(id)object {
    if ([cell isKindOfClass:TKTableViewCell.class]) {
        [(TKTableViewCell *)cell bindViewModel:object];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.viewModel.dataSource ? self.viewModel.dataSource.count : 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.viewModel.dataSource[section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    id object = self.viewModel.dataSource[indexPath.section][indexPath.row];
    UITableViewCell *cell = nil;
    if ([object isKindOfClass:TKItemViewModel.class]){
        TKItemViewModel *item =(TKItemViewModel *)object;
        item.indexPath = indexPath;
        cell = [self.tableView dequeueReusableCellWithIdentifier:NSStringFromClass(item.cellClass)];
        if (!cell) {
            cell = [[item.cellClass alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass(item.cellClass)];
            ((TKTableViewCell *)cell).tableView = tableView;
        }

    } else {
       cell = [self tableView:tableView dequeueReusableCellWithIdentifier:@"TableViewCell" forIndexPath:indexPath];
    }
    
    [self configureCell:cell atIndexPath:indexPath withObject:(id)object];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section >= self.viewModel.sectionIndexTitles.count) return nil;
    return self.viewModel.sectionIndexTitles[section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    if (self.searchBar != nil) {
        if (self.viewModel.sectionIndexTitles.count != 0) {
            return [self.viewModel.sectionIndexTitles.rac_sequence startWith:UITableViewIndexSearch].array;
        }
    }
    return self.viewModel.sectionIndexTitles;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    if (self.searchBar != nil) {
        if (index == 0) {
            [tableView scrollRectToVisible:self.searchBar.frame animated:NO];
        }
        return index - 1;
    }
    return index;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.viewModel.didSelectCommand execute:indexPath];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    id object = self.viewModel.dataSource[indexPath.section][indexPath.row];
    if ([object isKindOfClass:TKItemViewModel.class]){
        TKItemViewModel *viewModel = self.viewModel.dataSource[indexPath.section][indexPath.row];
        return viewModel.height;
    }
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return self.viewModel.sectionHeaderHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return self.viewModel.sectionFooterHeight;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self.refreshControl scrollViewDidScroll];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    if (self.fpsLabel.alpha == 0) {
        [UIView animateWithDuration:0.3
                              delay:0
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                            self.fpsLabel.alpha = 1;
                         }
                         completion:NULL];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self.refreshControl scrollViewDidEndDragging];
    
    if (!decelerate) {
        if (self.fpsLabel.alpha != 0) {
            [UIView animateWithDuration:1
                                  delay:2
                                options:UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                                 self.fpsLabel.alpha = 0;
                             }
                             completion:NULL];
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (self.fpsLabel.alpha != 0) {
        [UIView animateWithDuration:1
                              delay:2
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                             self.fpsLabel.alpha = 0;
                         }
                         completion:NULL];
    }
}

- (void)scrollViewDidScrollToTop:(UIScrollView *)scrollView {
    if (self.fpsLabel.alpha == 0) {
        [UIView animateWithDuration:0.3
                              delay:0
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                             self.fpsLabel.alpha = 1;
                         }
                         completion:NULL];
    }
}

#pragma mark - Listening for the user to trigger a refresh

- (void)refreshTriggered:(id)sender {
    @weakify(self)
    [[[self.viewModel.requestRemoteDataCommand
         execute:@1]
         deliverOnMainThread]
        subscribeNext:^(id x) {
            @strongify(self)
            self.viewModel.page = 1;
        } error:^(NSError *error) {
            @strongify(self)
            [self.refreshControl finishingLoading];
        } completed:^{
            @strongify(self)
            [self.refreshControl finishingLoading];
        }];
}

#pragma mark - UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    [searchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    self.viewModel.keyword = searchText;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];

    searchBar.text = nil;
    self.viewModel.keyword = nil;
}

#pragma mark - DZNEmptyDataSetSource

- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
    return [[NSAttributedString alloc] initWithString:@"No Data"];
}

#pragma mark - DZNEmptyDataSetDelegate

- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView {
    return self.viewModel.dataSource == nil;
}

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
    return YES;
}

- (CGPoint)offsetForEmptyDataSet:(UIScrollView *)scrollView {
    return CGPointMake(0, -(self.tableView.contentInset.top - self.tableView.contentInset.bottom) / 2);
}

@end

