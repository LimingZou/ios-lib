//
//  TKSegmentedViewController.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewController.h"

NS_ASSUME_NONNULL_BEGIN

@class TKSegmentedControlController;

@protocol TKSegmentedControlControllerDelegate <NSObject>

@optional

- (void)segmentedControlController:(TKSegmentedControlController *)segmentedControlController didSelectViewController:(UIViewController *)viewController;

@end

@interface TKSegmentedControlController : TKViewController

@property (nonatomic, copy) NSArray *viewControllers;
@property (nonatomic, strong, readonly) UISegmentedControl *segmentedControl;
@property (nonatomic, assign) id<TKSegmentedControlControllerDelegate> delegate;

@end

@interface UIViewController (TKSegmentedControlItem)

@property (nonatomic, copy) NSString *segmentedControlItem;

@end

NS_ASSUME_NONNULL_END
