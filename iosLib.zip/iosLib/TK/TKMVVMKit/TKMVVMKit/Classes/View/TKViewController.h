//
//  TKViewController.h
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class TKViewModel;
@interface TKViewController : UIViewController

/// The `viewModel` parameter in `-initWithViewModel:` method.
@property (nonatomic, strong, readonly) TKViewModel *viewModel;
@property (nonatomic, strong, readonly) UIPercentDrivenInteractiveTransition *interactivePopTransition;
@property (nonatomic, strong) UIView *snapshot;
@property (nonatomic, assign, readonly) int level;

/// Initialization method. This is the preferred way to create a new view.
///
/// viewModel - corresponding view model
///
/// Returns a new view.
- (instancetype)initWithViewModel:(TKViewModel *)viewModel;

/// Binds the corresponding view model to the view.
- (void)bindViewModel;

@end

NS_ASSUME_NONNULL_END
