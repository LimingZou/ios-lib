//
//  TKScrollViewController.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKScrollViewController.h"
#import <TKBasic/TKConstant.h>

@interface TKScrollViewController ()

@end

@implementation TKScrollViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (!self.scrollview){
        self.scrollview = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        self.scrollview.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        self.scrollview.contentOffset = CGPointMake(0, self.contentInset.top);
        self.scrollview.contentInset  = self.contentInset;
        self.scrollview.scrollIndicatorInsets = self.contentInset;
        self.scrollview.alwaysBounceVertical = YES;
        [self.view addSubview:self.scrollview];
    }
    
    if (IOS11) {
        self.scrollview.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    if (!self.scrollview.delegate){
        self.scrollview.delegate = self;
    }
}
- (UIEdgeInsets)contentInset {
    return IS_IPHONEX_SET ? UIEdgeInsetsMake(0, 0, 83, 0) : UIEdgeInsetsMake(0, 0, 49, 0);
}

@end
