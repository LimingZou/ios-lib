//
//  TKTabBarController.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKTabBarController.h"
#import <TKBasic/TKConstant.h>

@interface TKTabBarController ()

@property (nonatomic, strong, readwrite) UITabBarController *tabBarController;

@end

@implementation TKTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];

    UITabBar.appearance.barTintColor = HexRGB(0xFCFCFC);
    UITabBar.appearance.translucent = NO;
    UITabBar.appearance.shadowImage = [UIImage new];
    UITabBar.appearance.backgroundImage = [[UIImage alloc] init];
    
    self.tabBarController = [[UITabBarController alloc] init];
    
    [self addChildViewController:self.tabBarController];
    [self.view addSubview:self.tabBarController.view];
}

- (BOOL)shouldAutorotate {
    return self.tabBarController.selectedViewController.shouldAutorotate;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return self.tabBarController.selectedViewController.supportedInterfaceOrientations;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return self.tabBarController.selectedViewController.preferredStatusBarStyle;
}

@end
