//
//  TKViewController.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKViewController.h"
#import "TKViewModel.h"
#import "TKLoginViewModel.h"
#import "TKDoubleTitleView.h"
#import "TKLoadingTitleView.h"
#import "TKViewModelServicesImpl.h"
@interface TKViewController () <UIGestureRecognizerDelegate>

@property (nonatomic, strong, readwrite) TKViewModel *viewModel;
@property (nonatomic, strong, readwrite) UIPercentDrivenInteractiveTransition *interactivePopTransition;
@property (nonatomic, assign, readwrite) int level;

@end

@implementation TKViewController

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    TKViewController *viewController = [super allocWithZone:zone];

    @weakify(viewController)
    [[viewController
        rac_signalForSelector:@selector(viewDidLoad)]
        subscribeNext:^(id x) {
            @strongify(viewController)
            [viewController bindViewModel];
        }];

    return viewController;
}

- (TKViewController *)initWithViewModel:(id)viewModel {
    self = [super init];
    if (self) {
        self.viewModel = viewModel;

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.extendedLayoutIncludesOpaqueBars = YES;
    self.view.backgroundColor = HexRGB(0xffffff);
    self.level = (int)[[self.navigationController viewControllers] indexOfObject:self];

    if (self.navigationController != nil && self != self.navigationController.viewControllers.firstObject) {
        UIPanGestureRecognizer *popRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePopRecognizer:)];
        [self.view addGestureRecognizer:popRecognizer];
        popRecognizer.delegate = self;
    }
}

- (void)bindViewModel {
    // System title view
    RAC(self, title) = RACObserve(self.viewModel, title);

    UIView *titleView = self.navigationItem.titleView;

    // Double title view
    TKDoubleTitleView *doubleTitleView = [[TKDoubleTitleView alloc] init];

    RAC(doubleTitleView.titleLabel, text)    = RACObserve(self.viewModel, title);
    RAC(doubleTitleView.subtitleLabel, text) = RACObserve(self.viewModel, subtitle);

    @weakify(self)
    [[self
        rac_signalForSelector:@selector(viewWillTransitionToSize:withTransitionCoordinator:)]
        subscribeNext:^(id x) {
            @strongify(self)
            doubleTitleView.titleLabel.text    = self.viewModel.title;
            doubleTitleView.subtitleLabel.text = self.viewModel.subtitle;
        }];

    // Loading title view
    TKLoadingTitleView *loadingTitleView = [[NSBundle bundleWithIdentifier:@"org.cocoapods.TKMVVMKit"] loadNibNamed:@"TKLoadingTitleView" owner:nil options:nil].firstObject;
    loadingTitleView.frame = CGRectMake((SCREEN_WIDTH - CGRectGetWidth(loadingTitleView.frame)) / 2.0, 0, CGRectGetWidth(loadingTitleView.frame), CGRectGetHeight(loadingTitleView.frame));

    RAC(self.navigationItem, titleView) = [RACObserve(self.viewModel, titleViewType).distinctUntilChanged map:^(NSNumber *value) {
        TKTitleViewType titleViewType = value.unsignedIntegerValue;
        switch (titleViewType) {
            case TKTitleViewTypeDefault:
                return titleView;
            case TKTitleViewTypeDoubleTitle:
                return (UIView *)doubleTitleView;
            case TKTitleViewTypeLoadingTitle:
                return (UIView *)loadingTitleView;
        }
    }];

    [self.viewModel.errors subscribeNext:^(NSError *error) {
        @strongify(self)


        if ([error.domain isEqual:@"TKClientErrorDomain"] && error.code == 666) {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Tips"
                                                                                     message:@"Your authorization has expired, please login again"
                                                                              preferredStyle:UIAlertControllerStyleAlert];

            [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                @strongify(self)

                TKLoginViewModel *loginViewModel = [[TKLoginViewModel alloc] initWithServices:self.viewModel.services params:nil];
                [self.viewModel.services resetRootViewModel:loginViewModel];
            }]];

            [self presentViewController:alertController animated:YES completion:NULL];
        } else if (error.code != 000 && error.code != 111) {
            NSLog(@"%@", error.localizedDescription);
        }
    }];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.viewModel.willDisappearSignal sendNext:nil];
    
    // Being popped, take a snapshot
    if ([self isMovingFromParentViewController]) {
        self.snapshot = [self.navigationController.view snapshotViewAfterScreenUpdates:NO];
    }
}

- (BOOL)shouldAutorotate {
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

#pragma mark - UIPanGestureRecognizer handlers

- (void)handlePopRecognizer:(UIPanGestureRecognizer *)recognizer {
    CGFloat progress = [recognizer translationInView:self.view].x / CGRectGetWidth(self.view.frame);
    progress = MIN(1.0, MAX(0.0, progress));

    if (recognizer.state == UIGestureRecognizerStateBegan) {
        // Create a interactive transition and pop the view controller
        self.interactivePopTransition = [[UIPercentDrivenInteractiveTransition alloc] init];
        [self.navigationController popViewControllerAnimated:YES];
    } else if (recognizer.state == UIGestureRecognizerStateChanged) {
        // Update the interactive transition's progress
        [self.interactivePopTransition updateInteractiveTransition:progress];
    } else if (recognizer.state == UIGestureRecognizerStateEnded || recognizer.state == UIGestureRecognizerStateCancelled) {
        // Finish or cancel the interactive transition
        if (progress > 0.2) {
            [self.interactivePopTransition finishInteractiveTransition];
        } else {
            [self.interactivePopTransition cancelInteractiveTransition];
        }

        self.interactivePopTransition = nil;
    }
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIPanGestureRecognizer *)recognizer {
    return [recognizer velocityInView:self.view].x > 0;
}

- (void)dealloc{
    [self.viewModel.willDeallocSignal sendNext:nil];
    NSLog(@"%@ dealloc",self);
}

@end
