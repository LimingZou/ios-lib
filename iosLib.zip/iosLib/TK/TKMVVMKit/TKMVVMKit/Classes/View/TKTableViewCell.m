//
//  TKTableViewCell.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKTableViewCell.h"
#import "TKItemViewModel.h"
#import <TKBasic/TKConstant.h>

@interface TKTableViewCell ()

@property (nonatomic, strong) TKItemViewModel *viewModel;

@end

@implementation TKTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = HexRGB(0xFFFFFF);
        self.multipleSelectionBackgroundView = [[UIView alloc] initWithFrame:self.bounds];
        self.multipleSelectionBackgroundView.backgroundColor = [UIColor clearColor];
    }
    return self;
}
- (CGFloat)cellHeight
{
    return self.viewModel.height;
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated{
    [super setEditing:editing animated:animated];
    // Configure the view for the editing state
}
- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated{
    if(highlighted){
        self.backgroundColor = HexRGB(0xF1F6FE);
    }else{
        self.backgroundColor = HexRGB(0xFFFFFF);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    if(selected){
        self.backgroundColor = HexRGB(0xF1F6FE);
    }else{
        self.backgroundColor = HexRGB(0xFFFFFF);
    }
}

- (void)bindViewModel:(TKItemViewModel *)viewModel {
    self.viewModel = viewModel;
}



@end
