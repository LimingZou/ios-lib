//
//  UISearchBar+TKShowsCancelButton.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "UISearchBar+TKShowsCancelButton.h"
#import <objc/runtime.h>

@implementation UISearchBar (TKShowsCancelButton)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        Class class = [self class];
        
        SEL sel1 = NSSelectorFromString(@"setShowsCancelButton:");
        SEL sel2 = NSSelectorFromString(@"xy_setShowsCancelButton:");
        
        Method m1 = class_getInstanceMethod(class, sel1);
        Method m2 = class_getInstanceMethod(class, sel2);
        
        IMP imp1 = class_getMethodImplementation(class, sel1);
        if (imp1 != NULL) {
            method_exchangeImplementations(m1, m2);
        }
        
        SEL sel3 = NSSelectorFromString(@"setShowsCancelButton:animated:");
        SEL sel4 = NSSelectorFromString(@"xy_setShowsCancelButton:animated:");
        
        Method m3 = class_getInstanceMethod(class, sel3);
        Method m4 = class_getInstanceMethod(class, sel4);
        
        IMP imp3 = class_getMethodImplementation(class, sel3);
        if (imp3 != NULL) {
            method_exchangeImplementations(m3, m4);
        }
    });
}

- (void)xy_setShowsCancelButton:(BOOL)showsCancelButton {}

- (void)xy_setShowsCancelButton:(BOOL)showsCancelButton animated:(BOOL)animated {}

@end
