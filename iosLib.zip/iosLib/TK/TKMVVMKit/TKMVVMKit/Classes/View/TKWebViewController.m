//
//  TKWebViewController.m
//  DialogClient
//
//  Created by tretalk-888 on 2021/3/23.
//  Copyright © 2021 MrCola. All rights reserved.
//

#import "TKWebViewController.h"
#import "TKWebViewModel.h"
#import "TKViewModelServicesImpl.h"

@interface TKWebViewController ()

@property (nonatomic, strong, readwrite) WKWebView *webView;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *webViewTopConstraint;
@property (nonatomic, strong, readonly) TKWebViewModel *viewModel;

@end

@implementation TKWebViewController

@dynamic viewModel;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.navigationController.viewControllers.count == 1) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"membership_close"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]  style:UIBarButtonItemStylePlain target:nil action:NULL];
        self.navigationItem.leftBarButtonItem.rac_command = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
            [self.viewModel.services dismissViewModelAnimated:YES completion:nil];
            return [RACSignal empty];
        }];
    }
    
     WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
     WKPreferences *preference = [[WKPreferences alloc] init];
     preference.minimumFontSize = 0;
     preference.javaScriptEnabled = YES;
     preference.javaScriptCanOpenWindowsAutomatically = YES;
     config.preferences = preference;
     config.allowsInlineMediaPlayback = YES;
    if (@available(iOS 10.0, *)) {
        config.mediaTypesRequiringUserActionForPlayback = YES;
    } else {
        // Fallback on earlier versions
    }
     config.allowsPictureInPictureMediaPlayback = YES;
     config.applicationNameForUserAgent = @"ChinaDailyForiPad";

    
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    self.webView.backgroundColor = HexRGB(0xffffff);
    self.webView.UIDelegate = self;
    self.webView.navigationDelegate = self;
    [self.view addSubview:self.webView];
    
    if (@available(iOS 11.0, *)) {
        self.webView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }

    self.webView.scrollView.contentOffset = CGPointMake(0, self.contentInset.top);
    self.webView.scrollView.contentInset  = self.contentInset;
    self.webView.scrollView.scrollIndicatorInsets = self.contentInset;
    
    RACSignal *didFinishLoadSignal   = [self rac_signalForSelector:@selector(webView:didFinishNavigation:) fromProtocol:@protocol(WKNavigationDelegate)];
    RACSignal *didFailLoadLoadSignal = [self rac_signalForSelector:@selector(webView:didFailNavigation:withError:) fromProtocol:@protocol(WKNavigationDelegate)];
    
    TKTitleViewType type = self.viewModel.titleViewType;
    RAC(self.viewModel, titleViewType) = [[RACSignal
        merge:@[ didFinishLoadSignal, didFailLoadLoadSignal ]]
        mapReplace:@(type)];
    
    NSParameterAssert(self.viewModel.request);
    NSLog(@"%@",self.viewModel.request);
    [self.webView loadRequest:self.viewModel.request];
}

- (void)viewWillAppear:(BOOL)animated{
     [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

- (UIEdgeInsets)contentInset {
    return IS_IPHONEX_SET ? UIEdgeInsetsMake(88, 0, 0, 0) : UIEdgeInsetsMake(64, 0, 0, 0);
}
#ifdef __IPHONE_11_0

- (void)viewSafeAreaInsetsDidChange {
    [super viewSafeAreaInsetsDidChange];

    if (IS_IPHONEX_SET) {
        self.webViewTopConstraint.constant = self.view.safeAreaInsets.top;
    }
}

#endif


#pragma mark - <WKNavigationDelegate>


- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView{}
@end
