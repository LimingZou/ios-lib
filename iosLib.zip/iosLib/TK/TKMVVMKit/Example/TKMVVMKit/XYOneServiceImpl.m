//
//  XYOneServiceImpl.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/4/12.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYOneServiceImpl.h"

@implementation XYOneServiceImpl
{
    BOOL _isPlayed;
}

@synthesize isPlayed = _isPlayed;

+(void)load{
    [TKViewModelServicesImpl registerService:@protocol(XYOneService) withModule:self.class];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _isPlayed = YES;
    }
    return self;
}

- (RACSignal *)requestAppInfoFromAppStoreWithAppID:(NSString *)appID{
    return [RACSignal empty];
}

@end
