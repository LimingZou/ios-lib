//
//  XYOneService.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/4/12.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol XYOneService <NSObject>

@property (nonatomic, readonly) BOOL  isPlayed;

- (RACSignal *)requestAppInfoFromAppStoreWithAppID:(NSString *)appID;

@end
