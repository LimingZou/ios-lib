//
//  XYSubViewController.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYSubViewController.h"
#import "XYSubViewModel.h"

@interface XYSubViewController ()
@property (nonatomic, strong) XYSubViewModel *viewModel;
@end

@implementation XYSubViewController
@dynamic viewModel;

+(void)load{
    [TKRouter registerController:XYSubViewController.class withModule:XYSubViewModel.class];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
