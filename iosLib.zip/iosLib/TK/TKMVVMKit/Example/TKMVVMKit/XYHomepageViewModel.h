//
//  XYHomepageViewModel.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <TKMVVMKit/TKMVVMKit.h>

#import "XYViewModel_One.h"
#import "XYViewModel_Two.h"
#import "XYViewModel_Three.h"



NS_ASSUME_NONNULL_BEGIN

@interface XYHomepageViewModel : TKTabBarViewModel

/// The view model of `Main` interface.
@property (nonatomic, strong, readonly) XYViewModel_One *oneViewModel;

/// The view model of `Works` interface.
@property (nonatomic, strong, readonly) XYViewModel_Two *twoViewModel;

/// The view model of `Profile` interface.
@property (nonatomic, strong, readonly) XYViewModel_Three *threeViewModel;

@end

NS_ASSUME_NONNULL_END
