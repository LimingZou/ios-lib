//
//  XYUnitItemViewModel.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYUnitItemViewModel.h"
#import "XYItem.h"

#import "XYUnitItemTableViewCell.h"

@interface XYUnitItemViewModel ()
@property (nonatomic, copy, readwrite) XYItem *item;

@property (nonatomic, copy, readwrite) NSString *rename;
@end
@implementation XYUnitItemViewModel


- (instancetype)initWithItem:(XYItem *)item{
    self = [super init];
    if (self) {
        self.item = item;
        self.rename = [NSString stringWithFormat:@"%@(%@)",item.title, item.subTitle];

        self.cellClass = XYUnitItemTableViewCell.class;

    }
    return self;
}

@end

