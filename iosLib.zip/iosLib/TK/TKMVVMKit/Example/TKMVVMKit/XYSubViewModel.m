//
//  XYSubViewModel.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYSubViewModel.h"
#import "XYItem.h"
@interface XYSubViewModel ()
@property (nonatomic, strong) XYItem *datail;
@end

@implementation XYSubViewModel

- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params {
    self = [super initWithServices:services params:params];
    if (self) {
        XYItem *detail = params[@"detail"];
        
        self.datail = detail;
    }
    return self;
}

- (void)initialize {
    [super initialize];
    
    self.title = self.datail.title;
    
}
@end
