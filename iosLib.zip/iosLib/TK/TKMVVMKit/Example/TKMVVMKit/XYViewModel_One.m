//
//  XYViewModel_One.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYViewModel_One.h"
#import "XYItem.h"
#import "XYUnitItemViewModel.h"
#import "XYSubViewModel.h"

@implementation XYViewModel_One

+ (void)load{
    // 注册组件路由
}

- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params{
    self = [super initWithServices:services params:params];
    if (self) {
        //...
    }
    return self;
}
- (void)initialize {
    [super initialize];

    
    
    self.title = @"分组一";
    self.subtitle = @"副标题";
    
    self.titleViewType = TKTitleViewTypeDoubleTitle;
    self.shouldPullToRefresh = NO;
    self.shouldRequestRemoteDataOnViewDidLoad = NO;

    @weakify(self)
    RACSignal *fetchLocalDataSignal = [RACSignal return:[self fetchLocalData]];
    
    RAC(self, items) = [fetchLocalDataSignal deliverOnMainThread];
    
    RAC(self, dataSource) = [[RACObserve(self, items) map:^id(NSArray *items) {
        BOOL reverse = YES;

        NSString *sortKey = @"creationDate";
        
        //Sort the files
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:sortKey ascending:!reverse];
        items = [items sortedArrayUsingDescriptors:@[sortDescriptor]];

        return items;
    }] flattenMap:^(NSArray *items) {
        return [self dataSourceSignalWithFileContents:items];
    }];

    self.didSelectCommand = [[RACCommand alloc] initWithSignalBlock:^(NSIndexPath *indexPath) {
        @strongify(self)
        XYItem *item = ((XYUnitItemViewModel *)self.dataSource[indexPath.section][indexPath.row]).item;

        XYSubViewModel *detailViewModel = [[XYSubViewModel alloc] initWithServices:self.services
                                                                                            params:@{ @"detail": item }];
        [self.services pushViewModel:detailViewModel animated:YES];
        return [RACSignal empty];
    }];
}

- (NSArray *)fetchLocalData {
    
    XYItem *item1 = [XYItem new];
    item1.title = @"单元一";
    item1.subTitle = @"1111";
    item1.creationDate = 1616988108;
    
    XYItem *item2 = [XYItem new];
    item2.title = @"单元二";
    item2.subTitle = @"2222";
    item2.creationDate = 1616988109;
    
    return @[item1, item2];
}

- (RACSignal *)dataSourceSignalWithFileContents:(NSArray *)fileContents{
    if (fileContents.count == 0) return [RACSignal return:nil];;
    NSArray *viewModels = [fileContents.rac_sequence map:^(XYItem *item) {
        XYUnitItemViewModel *viewModel = [[XYUnitItemViewModel alloc] initWithItem:item];
        return viewModel;
    }].array;
    
    return [RACSignal return:@[ viewModels ]];
}

@end
