//
//  XYItem.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYItem.h"

@implementation XYItem

-(id)copyWithZone:(NSZone *)zone{
    return self;
}

@end
