//
//  TKAppDelegate.h
//  TKMVVMKit
//
//  Created by LimingZou on 04/12/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

@import UIKit;

#define XYSharedAppDelegate ((TKAppDelegate *)[UIApplication sharedApplication].delegate)


@interface TKAppDelegate : UIResponder <UIApplicationDelegate>

/// The window of current application.
@property (strong, nonatomic) UIWindow *window;
/// Are you using app for the first time
@property (nonatomic, readonly) BOOL  firstEnter;
/// Navigation stack of the application
@property (nonatomic, strong, readonly) TKNavigationControllerStack *navigationControllerStack;


@end
