//
//  XYViewModel_Two.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYViewModel_Two.h"
#import "XYOneService.h"
@implementation XYViewModel_Two


- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params{
    self = [super initWithServices:services params:params];
    if (self) {
        //...
        
        id<XYOneService>service = [TKViewModelServicesImpl moduleByService:@protocol(XYOneService)];
        [[service requestAppInfoFromAppStoreWithAppID:@"09203"] subscribeNext:^(id  _Nullable x) {
                    
        }];
        BOOL isPlyed = service.isPlayed;
    }
    return self;
}
- (void)initialize {
    [super initialize];

    self.title = @"分组二";
    
}

@end
