//
//  XYOneServiceImpl.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/4/12.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYOneService.h"

@interface XYOneServiceImpl : NSObject<XYOneService>

@end
