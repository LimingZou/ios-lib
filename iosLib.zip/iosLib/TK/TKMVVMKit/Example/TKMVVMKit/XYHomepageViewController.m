//
//  TKHomepageViewController.m
//  TKMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYHomepageViewController.h"
#import "XYHomepageViewModel.h"
#import "XYViewController_One.h"
#import "XYViewController_Two.h"
#import "XYViewController_Three.h"

@interface XYHomepageViewController ()

@property (nonatomic, strong) XYHomepageViewModel *viewModel;

@end

@implementation XYHomepageViewController

@dynamic viewModel;

+(void)load{
    [TKRouter registerController:XYHomepageViewController.class withModule:XYHomepageViewModel.class];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UINavigationController *oneNavigationController = ({
        XYViewController_One *oneViewController = [[XYViewController_One alloc] initWithViewModel:self.viewModel.oneViewModel];

        oneViewController.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"分组一" image:[UIImage new] selectedImage:[UIImage new]];

        [[TKNavigationController alloc] initWithRootViewController:oneViewController];
    });

    UINavigationController *twoNavigationController = ({
        XYViewController_Two *twoViewController = [[XYViewController_Two alloc] initWithViewModel:self.viewModel.twoViewModel];

        twoViewController.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"分组二" image:[UIImage new] selectedImage:[UIImage new]];

        [[TKNavigationController alloc] initWithRootViewController:twoViewController];
    });

    UINavigationController *threeNavigationController = ({
        XYViewController_Three *threeViewController = [[XYViewController_Three alloc] initWithViewModel:self.viewModel.threeViewModel];

        threeViewController.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"分组三" image:[UIImage new] selectedImage:[UIImage new]];

        [[TKNavigationController alloc] initWithRootViewController:threeViewController];
    });

    self.tabBarController.viewControllers = @[ oneNavigationController, twoNavigationController, threeNavigationController ];

    
    [XYSharedAppDelegate.navigationControllerStack pushNavigationController:oneNavigationController];


    self.tabBarController.delegate = self;
    
    @weakify(self)
    [[self
        rac_signalForSelector:@selector(tabBarController:didSelectViewController:)
        fromProtocol:@protocol(UITabBarControllerDelegate)]
        subscribeNext:^(RACTuple *tuple) {
            [XYSharedAppDelegate.navigationControllerStack popNavigationController];
            [XYSharedAppDelegate.navigationControllerStack pushNavigationController:tuple.second];
    }];
    
    [RACObserve(self.tabBarController, selectedIndex) subscribeNext:^(NSNumber *selectedIndex) {
        @strongify(self)
        [XYSharedAppDelegate.navigationControllerStack popNavigationController];
        [XYSharedAppDelegate.navigationControllerStack pushNavigationController:self.tabBarController.viewControllers[selectedIndex.integerValue]];
    }];
    
    self.tabBarController.delegate = self;

}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    if (self.tabBarController.selectedViewController == viewController) {
        UINavigationController *navigationController = (UINavigationController *)self.tabBarController.selectedViewController;
        UIViewController *viewController = navigationController.topViewController;
        if ([viewController isKindOfClass:[XYViewController_One class]]) {
            XYViewController_One *oneViewController = (XYViewController_One *)viewController;
            [oneViewController refresh];
        }
    }
    return YES;
}


@end
