//
//  XYUnitItemTableViewCell.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <TKMVVMKit/TKMVVMKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYUnitItemTableViewCell : TKTableViewCell

@end

NS_ASSUME_NONNULL_END
