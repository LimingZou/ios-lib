//
//  XYViewController_Two.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <TKMVVMKit/TKMVVMKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYViewController_Two : TKViewController

@end

NS_ASSUME_NONNULL_END
