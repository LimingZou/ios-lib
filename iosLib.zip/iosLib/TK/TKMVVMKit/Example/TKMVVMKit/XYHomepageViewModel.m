//
//  XYHomepageViewModel.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYHomepageViewModel.h"

@interface XYHomepageViewModel ()

@property (nonatomic, strong, readwrite) XYViewModel_One *oneViewModel;
@property (nonatomic, strong, readwrite) XYViewModel_Two *twoViewModel;
@property (nonatomic, strong, readwrite) XYViewModel_Three *threeViewModel;

@end


@implementation XYHomepageViewModel

- (void)initialize {
    [super initialize];
    
    self.oneViewModel    = [[XYViewModel_One alloc] initWithServices:self.services params:nil];
    self.twoViewModel    = [[XYViewModel_Two alloc] initWithServices:self.services params:nil];
    self.threeViewModel  = [[XYViewModel_Three alloc] initWithServices:self.services params:nil];
}

@end
