//
//  XYViewController_One.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYViewController_One.h"
#import "XYViewModel_One.h"

@interface XYViewController_One ()
@property (nonatomic, strong, readonly) XYViewModel_One *viewModel;
@end

@implementation XYViewController_One
@dynamic viewModel;

+(void)load{
    [TKRouter registerController:XYViewController_One.class withModule:XYViewModel_One.class];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)refresh{
    
}

@end
