//
//  XYViewController_Three.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYViewController_Three.h"
#import "XYViewModel_Three.h"

@interface XYViewController_Three ()
@property (nonatomic, strong, readonly) XYViewModel_Three *viewModel;

@end

@implementation XYViewController_Three

@dynamic viewModel;

+(void)load{
    [TKRouter registerController:XYViewController_Three.class withModule:XYViewModel_Three.class];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
