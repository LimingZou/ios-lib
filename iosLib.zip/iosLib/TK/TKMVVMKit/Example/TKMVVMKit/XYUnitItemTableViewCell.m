//
//  XYUnitItemTableViewCell.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYUnitItemTableViewCell.h"
#import "XYUnitItemViewModel.h"

@interface XYUnitItemTableViewCell ()
@property (nonatomic, strong) XYUnitItemViewModel *viewModel;
@end

@implementation XYUnitItemTableViewCell

- (void)bindViewModel:(XYUnitItemViewModel *)viewModel {
    self.viewModel = viewModel;

    self.textLabel.text = viewModel.rename;

}

@end
