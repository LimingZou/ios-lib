//
//  XYViewModel_Three.m
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "XYViewModel_Three.h"

@implementation XYViewModel_Three

- (instancetype)initWithServices:(id<TKViewModelServices>)services params:(NSDictionary *)params{
    self = [super initWithServices:services params:params];
    if (self) {
        //...
    }
    return self;
}
- (void)initialize {
    [super initialize];

    self.title = @"分组三";
    
}

@end
