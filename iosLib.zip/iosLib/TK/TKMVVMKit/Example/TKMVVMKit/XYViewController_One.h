//
//  XYViewController_One.h
//  XYMVVMKit_Example
//
//  Created by tretalk-888 on 2021/3/26.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <TKMVVMKit/TKMVVMKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYViewController_One : TKTableViewController

- (void)refresh;

@end

NS_ASSUME_NONNULL_END
