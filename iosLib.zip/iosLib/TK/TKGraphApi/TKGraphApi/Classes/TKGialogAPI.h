//
//  TKGialogAPI.h
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#ifndef TKGialogAPI_h
#define TKGialogAPI_h


#endif /* TKGialogAPI_h */
