//
//  TKGServer.m
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKGServer.h"
#import "TKGServer+Private.h"

NSString * const TKGServerDotComAPIEndpoint = @"https://api.github.com";
NSString * const TKGServerDotComBaseWebURL = @"https://github.com";
NSString * const TKGServerEnterpriseAPIEndpointPathComponent = @"api/v3";

// Enterprise defaults to HTTP, and not all instances have HTTPS set up.
NSString * const TKGServerDefaultEnterpriseScheme = @"http";

// Expose Enterprise HTTPS scheme for clients.
NSString * const TKGServerHTTPSEnterpriseScheme = @"https";

@interface TKGServer ()

@property (nonatomic, copy, readwrite) NSURL *baseURL;

@end

@implementation TKGServer

#pragma mark Properties

- (NSURL *)APIEndpoint {
    if (self.baseURL == nil) {
        // This environment variable can be used to debug API requests by
        // redirecting them to a different URL.
        NSString *endpoint = NSProcessInfo.processInfo.environment[@"API_ENDPOINT"];
        if (endpoint != nil) return [NSURL URLWithString:endpoint];

        return [NSURL URLWithString:TKGServerDotComAPIEndpoint];
    } else {
        return [self.baseURL URLByAppendingPathComponent:TKGServerEnterpriseAPIEndpointPathComponent isDirectory:YES];
    }
}

- (NSURL *)baseWebURL {
    if (self.baseURL == nil) {
        return [NSURL URLWithString:TKGServerDotComBaseWebURL];
    } else {
        return self.baseURL;
    }
}

- (BOOL)isEnterprise {
    return self.baseURL != nil;
}

#pragma mark Lifecycle

+ (instancetype)dotComServer {
    static TKGServer *dotComServer = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dotComServer = [[self alloc] initWithBaseURL:nil];
    });
    return dotComServer;
}

+ (instancetype)serverWithBaseURL:(NSURL *)baseURL {
    if (baseURL == nil) return self.dotComServer;

    return [[TKGServer alloc] initWithBaseURL:baseURL];
}

- (instancetype)initWithBaseURL:(NSURL *)baseURL {
    self = [super init];
    if (self == nil) return nil;

    _baseURL = baseURL;

    return self;
}

#pragma mark Migration

+ (NSDictionary *)dictionaryValueFromArchivedExternalRepresentation:(NSDictionary *)externalRepresentation version:(NSUInteger)fromVersion {
    NSMutableDictionary *dictionaryValue = [[super dictionaryValueFromArchivedExternalRepresentation:externalRepresentation version:fromVersion] mutableCopy];

    NSString *baseURLString = externalRepresentation[@"baseURL"];
    if (baseURLString != nil) dictionaryValue[@"baseURL"] = [NSURL URLWithString:baseURLString] ?: NSNull.null;

    return dictionaryValue;
}



@end
