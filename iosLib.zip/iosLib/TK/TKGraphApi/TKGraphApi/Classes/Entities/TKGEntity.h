//
//  TKGEntity.h
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import <Mantle/Mantle.h>

@interface TKGEntity : MTLModel

@end
