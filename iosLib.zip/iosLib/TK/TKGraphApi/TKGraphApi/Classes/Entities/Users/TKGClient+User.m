//
//  TKGClient+User.m
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKGClient+User.h"

@implementation TKGClient (User)

@end
