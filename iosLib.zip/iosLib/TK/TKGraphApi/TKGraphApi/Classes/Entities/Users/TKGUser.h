//
//  TKGUser.h
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKGEntity.h"

@interface TKGUser : TKGEntity

@end
