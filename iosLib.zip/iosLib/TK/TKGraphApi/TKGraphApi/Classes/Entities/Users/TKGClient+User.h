//
//  TKGClient+User.h
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKGClient.h"

@interface TKGClient (User)

/// Fetches the full information of the current `user`.
- (RACSignal *)fetchUserInfo;

/// Fetches the full information for the specified `user`.
- (RACSignal *)fetchUserInfoForUser:(TKGUser *)user;

@end
