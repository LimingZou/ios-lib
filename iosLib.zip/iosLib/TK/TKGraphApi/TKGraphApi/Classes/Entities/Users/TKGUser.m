//
//  TKGUser.m
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKGUser.h"

@implementation TKGUser

@end
