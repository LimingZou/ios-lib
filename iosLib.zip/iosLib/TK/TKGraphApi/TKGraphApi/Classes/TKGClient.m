//
//  TKGClient.m
//  TKGialogAPIModule
//
//  Created by tretalk-888 on 2021/3/23.
//

#import "TKGClient.h"
#import "TKGClient+Private.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import <ReactiveObjC/RACEXTScope.h>

NSString * const TKGClientErrorDomain = @"TKGClientErrorDomain";

const NSInteger TKGClientErrorAuthenticationFailed = 666;
const NSInteger TKGClientErrorBadRequest = 670;
const NSInteger TKGClientErrorConnectionFailed = 668;
const NSInteger TKGClientErrorJSONParsingFailed = 669;

@interface TKGClient ()
@property (nonatomic, strong, readwrite) TKGUser *user;
@property (nonatomic, copy, readwrite) NSString *token;

// Returns any user agent previously given to +setUserAgent:.
+ (NSString *)userAgent;

// Returns any OAuth client ID previously given to +setClientID:clientSecret:.
+ (NSString *)clientID;

// Returns any OAuth client secret previously given to
// +setClientID:clientSecret:.
+ (NSString *)clientSecret;

// A subject to send callback URLs to after they're received by the app.
+ (RACSubject *)callbackURLs;

// Creates a request.
- (NSMutableURLRequest *)requestWithMethod:(NSString *)method path:(NSString *)path parameters:(NSDictionary *)parameters notMatchingEtag:(NSString *)etag;

@end

@implementation TKGClient

#pragma mark Properties

- (BOOL)isAuthenticated {
    return self.token != nil;
}

- (void)setToken:(NSString *)token {
    _token = [token copy];
}


- (RACSignal *)enqueueRequest:(NSURLRequest *)request resultClass:(Class)resultClass{
    return [RACSignal empty];
}

@end
