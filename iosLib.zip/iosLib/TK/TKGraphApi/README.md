# TKGraphApi

[![CI Status](https://img.shields.io/travis/LimingZou/TKGraphApi.svg?style=flat)](https://travis-ci.org/LimingZou/TKGraphApi)
[![Version](https://img.shields.io/cocoapods/v/TKGraphApi.svg?style=flat)](https://cocoapods.org/pods/TKGraphApi)
[![License](https://img.shields.io/cocoapods/l/TKGraphApi.svg?style=flat)](https://cocoapods.org/pods/TKGraphApi)
[![Platform](https://img.shields.io/cocoapods/p/TKGraphApi.svg?style=flat)](https://cocoapods.org/pods/TKGraphApi)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKGraphApi is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKGraphApi'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKGraphApi is available under the MIT license. See the LICENSE file for more info.
