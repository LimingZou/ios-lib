# TKIMSDK

[![CI Status](https://img.shields.io/travis/LimingZou/TKIMSDK.svg?style=flat)](https://travis-ci.org/LimingZou/TKIMSDK)
[![Version](https://img.shields.io/cocoapods/v/TKIMSDK.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK)
[![License](https://img.shields.io/cocoapods/l/TKIMSDK.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK)
[![Platform](https://img.shields.io/cocoapods/p/TKIMSDK.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKIMSDK is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKIMSDK'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKIMSDK is available under the MIT license. See the LICENSE file for more info.
