//
//  TKAppDelegate.h
//  TKIMSDK
//
//  Created by LimingZou on 04/09/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

@import UIKit;

@interface TKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
