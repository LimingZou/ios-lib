//
//  TKAppDelegate.m
//  TKIMSDK
//
//  Created by LimingZou on 04/09/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

#import "TKAppDelegate.h"
#import <TKIMSDK.h>

#define TKIMSDKAppKey @"f6cac64bd51b4898a7ca42be6a6304d4"

#define TKIMMyAccount   @"9586"
#define TKIMMyToken     @"123456"
#define TKIMChatTarget  @"22"

@implementation TKAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    [[TKIMSDK sharedSDK] registerWithAppID:TKIMSDKAppKey cerName:nil];

    [[TKIMSDK sharedSDK].loginManager login:TKIMMyAccount token:TKIMMyToken completion:^(NSError *error) {
        if (!error) {
            NSLog(@"登录成功");
            
#pragma mark - 发送消息
            TKIMSession *session = [TKIMSession session:TKIMChatTarget type:TKIMSessionTypeP2P];

            TKIMMessage *textMessage = [[TKIMMessage alloc] init];
            textMessage.text        = @"发送了一段文字123123123生生世世";
            [[TKIMSDK sharedSDK].chatManager sendMessage:textMessage toSession:session error:NULL];
            
            
#pragma mark - 文件上传
            NSData *imageData = UIImageJPEGRepresentation([UIImage imageNamed:@"my_new_photo.jpeg"], 0.5);
            NSString *fullPath = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:@"demo_image_9587_100222.jpeg"];
            [imageData writeToFile:fullPath atomically:NO];

            [[TKIMSDK sharedSDK].resourceManager upload:fullPath progress:^(CGFloat progress) {
                NSLog(@"上传进度: %f",progress);
            }
                                             completion:^(NSString *urlString, NSError *error) {
                if (!error)
                {
                    NSLog(@"上传成功");
                }
                else
                {
                    NSLog(@"上传失败");
                }
            }];
            
#pragma mark - 添加好友
            TKIMUserRequest *request = [[TKIMUserRequest alloc] init];
            request.userId       = @"9587";
            request.operation    = TKIMUserOperationAdd;
            [[TKIMSDK sharedSDK].userManager requestFriend:request completion:^(NSError *error) {
                if (!error)
                {
                    NSLog(@"添加好友成功!");
                }
                else
                {
                    NSLog(@"添加好友失败!");
                }
            }];
#pragma mark - 删除好友
            [[TKIMSDK sharedSDK].userManager deleteFriend:@"102" completion:^(NSError *error) {
                if (!error)
                {
                    NSLog(@"删除好友成功!");
                }
                else
                {
                    NSLog(@"删除好友失败!");
                }
            }];
#pragma mark - 获取所有好友
            NSArray *friends = [[TKIMSDK sharedSDK].userManager myFriends];
            NSLog(@"friends:%@",friends);
        }else{
            NSLog(@"登录失败");
        }
    }];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
