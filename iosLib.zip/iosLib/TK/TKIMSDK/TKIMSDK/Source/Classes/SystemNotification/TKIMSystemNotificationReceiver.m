//
//  TKIMSystemNotificationReceiver.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMSystemNotificationReceiver.h"
#import "TKIMSystemNotification_Priviate.h"
#import "TKIMCustomSystemNotification_Private.h"
#import "TKIMDispatch.h"
#import "TKIMSystemNotificationManager.h"

//link
#import "TKIMSessionServiceProtocol.h"


@interface TKIMSystemNotificationReceiver ()
@property (nonatomic,strong)    NSMutableArray *sysNotifications;
@property (nonatomic,strong)    NSMutableArray *customNotifications;
@end

@implementation TKIMSystemNotificationReceiver
- (instancetype)init
{
    if (self = [super init])
    {
        _sysNotifications = [NSMutableArray array];
        _customNotifications = [NSMutableArray array];
    }
    return self;
}


- (void)receiveNotifications:(NSArray *)msgs
{
    for (int i = 0; i < msgs.count; i++) {
        @autoreleasepool
        {
            Property messageProperty = msgs[i];
            TKIMSystemNotificationType type      = [[messageProperty objectForKey:@(TKIMSystemMsgTagType)] intValue];
            if (![self typeCanBeHandled:type])
            {
//                TKIMAssert();
                continue;
            }
            switch (type) {
                case TKIMCustomSystemNotificationTypeP2P:
                case TKIMCustomSystemNotificationTypeTeam:
                    [self handleCustomnSystemNotification:messageProperty];
                    break;
                default:
                    [self handleSystemNotification:messageProperty
                                              type:type];
                    break;
            }
        }
    }
    


    [self saveAndFireSysNotifications];
    [self fireCustomNotifications];
}




- (BOOL)typeCanBeHandled:(TKIMSystemNotificationType)type
{
    static NSDictionary *supportedTypes = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        supportedTypes = @{ @(TKIMSystemNotificationTypeTeamApply)       : [NSNull null],
                            @(TKIMSystemNotificationTypeTeamApplyReject) : [NSNull null],
                            @(TKIMSystemNotificationTypeTeamInvite)      : [NSNull null],
                            @(TKIMSystemNotificationTypeTeamIviteReject) : [NSNull null],
                            @(TKIMSystemNotificationTypeFriendAdd)       : [NSNull null],
                            @(TKIMSystemNotificationTypeFriendDelete)    : [NSNull null],
                            @(TKIMCustomSystemNotificationTypeP2P)       : [NSNull null],
                            @(TKIMCustomSystemNotificationTypeTeam)      : [NSNull null],
                           };
    });
    return [supportedTypes objectForKey:@(type)] != nil;
}

#pragma mark - 自定义系统通知
- (void)handleCustomnSystemNotification:(NSDictionary *)property
{
    
    TKIMCustomSystemNotification *notification = [[TKIMCustomSystemNotification alloc] initWithPorperty:property];
    [_customNotifications addObject:notification];

}

- (void)fireCustomNotifications
{
    if ([_customNotifications count] == 0)
    {
        return;
    }
    [_customNotifications sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2)
    {
        if ([(TKIMCustomSystemNotification *)obj1 timestamp] ==  [(TKIMCustomSystemNotification *)obj2 timestamp])
        {
            return [(TKIMCustomSystemNotification *)obj1 msgId] < [(TKIMCustomSystemNotification *)obj2 msgId] ? NSOrderedAscending : NSOrderedDescending;
        }
        else
        {
            return [(TKIMCustomSystemNotification *)obj1 timestamp] < [(TKIMCustomSystemNotification *)obj2 timestamp] ? NSOrderedAscending : NSOrderedDescending;
        }
        
    }];
    
    for (TKIMCustomSystemNotification *notification in _customNotifications)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[TKIMSystemNotificationManager sharedManager] onReceiveCustomSystemNotification:notification];
        });
    }
}

#pragma mark - 系统通知
- (void)handleSystemNotification:(NSDictionary *)property
                            type:(TKIMSystemNotificationType)type
{
    TKIMSystemNotification *notification = [[TKIMSystemNotification alloc] initWithPorperty:property];
    [notification saveDataAfterReceiving:_onlineNotification];
    
    if ([notification canSave])
    {
        [_sysNotifications addObject:notification];
    }
    
}


- (void)saveAndFireSysNotifications
{
    if ([_sysNotifications count] == 0)
    {
        return;
    }
    
    [_sysNotifications sortUsingComparator:^NSComparisonResult(id obj1, id obj2)
    {
        if ([(TKIMSystemNotification *)obj1 timestamp] == [(TKIMSystemNotification *)obj2 timestamp])
        {
            return [(TKIMSystemNotification *)obj1 msgId] < [(TKIMSystemNotification *)obj2 msgId] ? NSOrderedAscending : NSOrderedDescending;
        }
        else
        {
            return [(TKIMSystemNotification *)obj1 timestamp] < [(TKIMSystemNotification *)obj2 timestamp] ? NSOrderedAscending : NSOrderedDescending;
        }
    }];
    
    for (TKIMSystemNotification *notification in _sysNotifications)
    {
        if ([[TKIMSystemNotificationManager sharedManager] saveNotification:notification])
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[TKIMSystemNotificationManager sharedManager]  onReceiveSystemNotification:notification];
            });
        }
    }
    tkim_io_async(^{
        [[TKIMSystemNotificationManager sharedManager] queryUnreadCount];
    });
    
}

@end
