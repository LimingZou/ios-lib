//
//  TKIMSystemNotificationReceiver.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <Foundation/Foundation.h>

@interface TKIMSystemNotificationReceiver : NSObject
@property (nonatomic,assign)    BOOL    onlineNotification;
- (void)receiveNotifications:(NSArray *)msgs;
@end
