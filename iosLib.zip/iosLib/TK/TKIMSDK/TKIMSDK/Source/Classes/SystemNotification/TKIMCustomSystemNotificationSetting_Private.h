//
//  TKIMCustomSystemNotificationSetting+Private.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//


#import "TKIMCustomSystemNotificationSetting.h"
//#import "document.h"

@interface TKIMCustomSystemNotificationSetting()

+ (instancetype)settingByProperty:(NSDictionary *)messageProperty;

- (NSDictionary *)settingProperty;

@end
