//
//  TKIMCustomSystemNotificationSetting.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMCustomSystemNotificationSetting_Private.h"
#import "TKIMSessionServiceProtocol.h"

@implementation TKIMCustomSystemNotificationSetting

- (instancetype)init
{
    if (self = [super init])
    {
        _shouldBeCounted = YES;
        _apnsEnabled     = YES;
        _apnsWithPrefix  = NO;
    }
    return self;
}

+ (instancetype)settingByProperty:(NSDictionary *)messageProperty
{
    TKIMCustomSystemNotificationSetting *instance = nil;
    BOOL valid = [messageProperty objectForKey:@(TKIMSystemMsgTagApnsEnable)] ||
    [messageProperty objectForKey:@(TKIMSystemMsgTagShouldBeCounted)] ||
    [messageProperty objectForKey:@(TKIMSystemMsgTagNeedPushNick)];
    if (valid)
    {
        instance = [[TKIMCustomSystemNotificationSetting alloc] init];
        instance.shouldBeCounted = [messageProperty[@(TKIMSystemMsgTagShouldBeCounted)] boolValue];
        instance.apnsEnabled     = [messageProperty[@(TKIMSystemMsgTagApnsEnable)] boolValue];
        instance.apnsWithPrefix  = [messageProperty[@(TKIMSystemMsgTagNeedPushNick)] boolValue];
    }
    return instance;
    
}


- (Property)settingProperty
{
    Property settingProperty = @{
        @(TKIMSystemMsgTagShouldBeCounted):@(_shouldBeCounted),
        @(TKIMSystemMsgTagApnsEnable):@(_apnsEnabled),
        @(TKIMSystemMsgTagNeedPushNick):@(_apnsWithPrefix),
    };
    return settingProperty;
}

- (NSString *)description{
    return [NSString stringWithFormat:@"shouldBeCounted %d apnsEnabled %d apnsWithPrefix %d",
            _shouldBeCounted,_apnsEnabled,_apnsWithPrefix];
}


@end
