//
//  TKIMCustomSystemNotification_Private.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <Foundation/Foundation.h>
#import "TKIMSystemNotification.h"
#import "TKIMDocument.h"

typedef enum : NSUInteger {
    TKIMCustomSystemNotificationTypeP2P  = 100,
    TKIMCustomSystemNotificationTypeTeam = 101,
} TKIMCustomSystemNotificationType;


@interface TKIMCustomSystemNotification ()
@property (nonatomic,assign)                int64_t msgId;
@property (nonatomic,assign)                NSTimeInterval timestamp;
@property (nonatomic,copy)                  NSString *sender;
@property (nonatomic,copy)                  NSString *receiver;
@property (nonatomic,assign)                TKIMSessionType  receiverType;
@property (nonatomic,copy)                  NSString    *content;
- (instancetype)initWithPorperty:(Property)property;
@end
