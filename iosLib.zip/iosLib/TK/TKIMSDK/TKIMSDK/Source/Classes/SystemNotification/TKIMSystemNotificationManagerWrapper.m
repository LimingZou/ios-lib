//
//  TKIMSystemNotificationManagerWrapper.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMSystemNotificationManagerWrapper.h"
#import "TKIMSystemNotificationManager.h"
#import "TKIMDelegateCenter.h"
#import "TKIMDispatch.h"
#import "TKIMSessionPersistValidator.h"


@implementation TKIMSystemNotificationManagerWrapper

+ (instancetype)sharedWrapper
{
    static TKIMSystemNotificationManagerWrapper *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMSystemNotificationManagerWrapper alloc] init];
    });
    return instance;
}

- (NSArray *)fetchSystemNotifications:(TKIMSystemNotification *)notification
                                limit:(NSInteger)limit
{
    return [self fetchSystemNotifications:notification
                                    limit:limit
                                   filter:nil];
}

- (NSArray *)fetchSystemNotifications:(TKIMSystemNotification *)notification
                                limit:(NSInteger)limit
                               filter:(TKIMSystemNotificationFilter *)filter
{
    return [[TKIMSystemNotificationManager sharedManager] fetchSystemNotifications:notification
                                                                            limit:limit
                                                                           filter:filter];
}


- (NSInteger)allUnreadCount
{
    return [self allUnreadCount:nil];
}

- (NSInteger)allUnreadCount:(TKIMSystemNotificationFilter *)filter
{
    return [[TKIMSystemNotificationManager sharedManager] allUnreadCount:filter];
}


- (void)deleteNotification:(TKIMSystemNotification *)notification
{
    return [[TKIMSystemNotificationManager sharedManager] deleteNotification:notification];
}


- (void)deleteAllNotifications
{
    [self deleteAllNotifications:nil];
}

- (void)deleteAllNotifications:(TKIMSystemNotificationFilter *)filter
{
    [[TKIMSystemNotificationManager sharedManager] deleteAllNotifications:filter];
}


- (void)markNotificationsAsRead:(TKIMSystemNotification *)notification
{
    [[TKIMSystemNotificationManager sharedManager] markNotificationsAsRead:notification];
}

- (void)markAllNotificationsAsRead
{
    [self markAllNotificationsAsRead:nil];
 
}

- (void)markAllNotificationsAsRead:(TKIMSystemNotificationFilter *)filter
{
    [[TKIMSystemNotificationManager sharedManager] markAllNotificationsAsRead:filter];
}



- (void)sendCustomNotification:(TKIMCustomSystemNotification *)notification
                     toSession:(TKIMSession *)session
                    completion:(TKIMSystemNotificationHandler)completion
{
    TKIMAPITrace();
    
    dispatch_block_t mainBlock = ^(){
        

        if (![[TKIMSessionPersistValidator validator:session] isValid])
        {
            if (completion) {
                completion(TKIMLocalError(TKIMLocalErrorCodeInvalidParam));
            }
            return;
        }
        
        TKIMSystemNotificationManager *manager = [TKIMSystemNotificationManager sharedManager];
        if (manager) {
            [manager sendCustomNotification:notification
                                  toSession:session
                                 completion:completion];
        }
        else{
            if (completion) {
                completion(TKIMLocalError(TKIMLocalErrorCodeUserInfoNeeded));
            }
        }

    };
    
    tkim_main_async_safe(mainBlock);
    
    
}

- (void)addDelegate:(id<TKIMSystemNotificationManagerDelegate>)delegate
{
    TKIMAPITrace();
    
    [[TKIMDelegateCenter sharedCenter] addDelegate:delegate
                                          forType:TKIMDelegateTypeNotification];
}

- (void)removeDelegate:(id<TKIMSystemNotificationManagerDelegate>)delegate
{
    TKIMAPITrace();
    
    [[TKIMDelegateCenter sharedCenter] removeDelegate:delegate
                                             forType:TKIMDelegateTypeNotification];
}


@end
