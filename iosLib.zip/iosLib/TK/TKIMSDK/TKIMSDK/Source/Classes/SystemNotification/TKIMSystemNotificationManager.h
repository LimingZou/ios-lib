//
//  TKIMSystemNotificationManager.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <UIKit/UIKit.h>
#import "TKIMManager.h"
#import "TKIMSystemNotificationManagerProtocol.h"


@interface TKIMSystemNotificationManager : TKIMManager
#pragma mark - 对外接口
- (NSArray *)fetchSystemNotifications:(TKIMSystemNotification *)notification
                                limit:(NSInteger)limit
                               filter:(TKIMSystemNotificationFilter *)filter;

- (NSInteger)allUnreadCount:(TKIMSystemNotificationFilter *)filter;

- (void)deleteNotification:(TKIMSystemNotification *)notification;

- (void)deleteAllNotifications:(TKIMSystemNotificationFilter *)filter;

- (void)markNotificationsAsRead:(TKIMSystemNotification *)notification;

- (void)markAllNotificationsAsRead:(TKIMSystemNotificationFilter *)filter;

- (void)sendCustomNotification:(TKIMCustomSystemNotification *)notification
                     toSession:(TKIMSession *)session
                    completion:(TKIMSystemNotificationHandler)completion;


#pragma mark - SDK内部接口
- (BOOL)saveNotification:(TKIMSystemNotification *)notification;

- (void)updateNotificationStatus:(TKIMSystemNotification *)notification;
- (void)updateNotificationSubStatus:(TKIMSystemNotification *)notification;

- (void)onReceiveSystemNotification:(TKIMSystemNotification *)notification;
- (void)onReceiveCustomSystemNotification:(TKIMCustomSystemNotification *)notification;

- (void)queryUnreadCount;

@end

void    CallbackRecvSysMsgs(IAsynCallbackParam *msgParam);                           //收到系统消息
void    CallbackSendCustomNotification(IAsynCallbackParam *msgParam);               //自定义通知ACK
