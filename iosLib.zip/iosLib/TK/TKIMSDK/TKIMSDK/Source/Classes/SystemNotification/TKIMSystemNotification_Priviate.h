//
//  TKIMSystemNotification+Priviate.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMSystemNotification.h"
#import "TKIMSystemNotification.h"
#import "TKIMDocument.h"

typedef NS_ENUM(NSInteger, TKIMSystemNotificationTypePrivate){
    TKIMSystemNotificationTypeFriendDelete = 104,
};


typedef NS_ENUM(NSInteger, TKIMNotificationStatus){
    TKIMNotificationStatusNone   = 0,
    TKIMNotificationStatusRead   = 1,
    TKIMNotificationStatusDeleted= 2,
};


@interface TKIMSystemNotification ()
@property (nonatomic,assign)        NSInteger serial;
@property (nonatomic,assign)        int64_t msgId;
@property (nonatomic,assign)        TKIMSystemNotificationType type;
@property (nonatomic,assign)        NSTimeInterval timestamp;
@property (nonatomic,copy)          NSString *sourceID;
@property (nonatomic,copy)          NSString *targetID;
@property (nonatomic,copy)          NSString *postscript;
@property (nonatomic,copy)          NSString *attachString;
@property (nonatomic,assign)        NSInteger status;
@property (nonatomic,strong)        id attachmentObject;

- (BOOL)canSave;

- (void)saveDataAfterReceiving:(BOOL)online;

- (instancetype)initWithPorperty:(Property)property;


@end





@interface TKIMUserAddAttachment ()
- (instancetype)initWithOperation:(TKIMUserOperation)operation;
@end
