//
//  TKIMSystemNotification.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMSystemNotification_Priviate.h"
#import "NSDictionary+TKIMJson.h"
#import "TKIMSystemNotificationManager.h"
#import "TKIMProtocolUtil.h"
#import "TKIMSession_Private.h"
#import "TKIMUser_Private.h"

//link
#import "TKIMSessionServiceProtocol.h"
#import "TKIMTeamServiceProtocol.h"
#import "TKIMFriendServiceProtocol.h"

@implementation TKIMSystemNotification
- (instancetype)initWithPorperty:(Property)property
{
    if (self = [super init])
    {
        _msgId                  = [[property objectForKey:@(TKIMSystemMsgTagMsgID)] longLongValue];
        _timestamp              = TKIMTimeLongToDouble([[property objectForKey:@(TKIMSystemMsgTagTime)] longLongValue]);
        _type                   = [[property objectForKey:@(TKIMSystemMsgTagType)] intValue];
        _sourceID               = [property objectForKey:@(TKIMSystemMsgTagFromAccount)];
        _targetID               = [property objectForKey:@(TKIMSystemMsgTagToAccount)];
        _postscript             = [property objectForKey:@(TKIMSystemMsgTagPostscript)];
        _attachString           = [property objectForKey:@(TKIMSystemMsgTagAttach)];

    }
    return self;
}


- (NSString *)description
{
    return [NSString stringWithFormat:@"serial %zd msg_id %lld type %zd",self.serial,self.msgId,self.type];
}

- (BOOL)isRead
{
    return _status == TKIMNotificationStatusRead;
}

- (void)setRead:(BOOL)read
{
    if (read && _status == TKIMNotificationStatusNone)
    {
        _status = TKIMNotificationStatusRead;
    }
    else if(!read && _status == TKIMNotificationStatusRead)
    {
        _status = TKIMNotificationStatusNone;
    }
    else
    {
        TKIMAssert();
        return;
    }
}

- (void)setHandleStatus:(NSInteger)handleStatus
{
    if (_handleStatus != handleStatus) {
        _handleStatus = handleStatus;
        [[TKIMSystemNotificationManager sharedManager] updateNotificationSubStatus:self];
    }
}



- (id)attachment
{
    if (_attachmentObject == nil) {
        if (_type == TKIMSystemNotificationTypeFriendAdd) {
            [self parseAddUserAttachment];
        }
    }
    return _attachmentObject;
}

- (void)parseAddUserAttachment
{
    if (_attachString)
    {
        NSData *data = [_attachString dataUsingEncoding:NSUTF8StringEncoding];
        if (data)
        {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data
                                                                 options:0
                                                                   error:nil];
            if ([dict isKindOfClass:[NSDictionary class]]) {
            
                TKIMUserOperation type = [dict tkim_jsonInteger:@"vt"];
                _attachmentObject = [[TKIMUserAddAttachment alloc] initWithOperation:type];
            }
        }
    }

}

- (BOOL)canSave{
    return self.type != TKIMSystemNotificationTypeFriendDelete;
}

#pragma mark - 收到消息后的处理
- (void)saveDataAfterReceiving:(BOOL)online
{
    [self saveTeamInfo];
    
    if (online) {
        [self saveUList];
    }
    
}

- (void)saveTeamInfo
{
    if (_attachString)
    {
        NSData *data = [_attachString dataUsingEncoding:NSUTF8StringEncoding];
        if (data)
        {
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data
                                                                 options:0
                                                                   error:nil];
            if ([dict isKindOfClass:[NSDictionary class]])
            {
                NSDictionary *tinfo = [dict tkim_jsonDict:@"tinfo"];
                if (tinfo)
                {
                    Property property = tinfo;
                    id<TKIMTeamService>service = (id<TKIMTeamService>)GetServiceFromCore(SVID_TKIM_TEAM);
                    if (service)
                    {
                        [service saveTeamInfoFromServer:tinfo];
                    }
                }
                
                NSDictionary *tlist = [dict tkim_jsonDict:@"tlist"];
                if (tlist)
                {
                    Property property = tlist;
                    id<TKIMTeamService>service = (id<TKIMTeamService>)GetServiceFromCore(SVID_TKIM_TEAM);
                    if (service)
                    {
                        NSString *team_id = [property objectForKey:@(TKIMTeamMemberTagTID)];
                        NSMutableArray *users = @[property].mutableCopy;
                        [users addObject:property];
                        [service saveTeamUsers:team_id users:users post:YES];
                    }
                }
            }
        }
    }
}

- (void)saveUList
{
    if (_type == TKIMSystemNotificationTypeFriendAdd) {
        
        id attachment = [self attachment];
        if ([attachment isKindOfClass:[TKIMUserAddAttachment class]]) {
            if ([(TKIMUserAddAttachment *)attachment operationType] == TKIMUserOperationAdd ||
                [(TKIMUserAddAttachment *)attachment operationType] == TKIMUserOperationVerify)
            {
                [self updateUser:_sourceID
                    markAsFriend:YES];
            }
        }
    }
    else if(_type == TKIMSystemNotificationTypeFriendDelete)
    {
        [self updateUser:_sourceID
            markAsFriend:NO];
    }
}

- (void)updateUser:(NSString *)userId
      markAsFriend:(BOOL)mark
{
    id<TKIMFriendService>service = (id<TKIMFriendService>)GetServiceFromCore(SVID_TKIM_FRIEND);
    if (service) {
        [service markFriendTag:userId isFriend:mark];
    }
}
@end



@implementation TKIMUserAddAttachment
- (instancetype)initWithOperation:(TKIMUserOperation)operation
{
    if (self = [super init]) {
        _operationType = operation;
    }
    return self;
}

@end


@implementation TKIMSystemNotificationFilter



@end


