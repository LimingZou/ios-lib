//
//  TKIMSystemNotificationManager.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMSystemNotificationManager.h"
#import "TKIMGlobalDefs.h"
#import "TKIMDispatch.h"
#import "TKIMDatabase.h"
#import "TKIMPathManager.h"
#import "TKIMSystemNotification_Priviate.h"
#import "TKIMCustomSystemNotification_Private.h"
#import "TKIMDispatch.h"
#import "TKIMSystemNotificationReceiver.h"
#import "TKIMCoreCenter.h"
#import "TKIMUtil.h"
#import "TKIMSession_Private.h"
#import "TKIMDelegateCenter.h"
#import "TKIMSessionValidator.h"
#import "TKIMProtocolUtil.h"
#import "TKIMCustomSystemNotificationSetting_Private.h"
#import "TKIMUserInfoManager.h"

//link
#import "TKIMSessionServiceProtocol.h"

@interface TKIMSystemNotificationManager ()
@property (nonatomic,assign)    NSInteger totalUnreadCount;
@property (nonatomic,strong)    TKIMDatabase *db;
@property (nonatomic,strong)    NSMutableDictionary *customNotifications;
@end

@implementation TKIMSystemNotificationManager
- (instancetype)init
{
    if (self = [super init])
    {
        _customNotifications = [NSMutableDictionary dictionary];
        [self openDatabase];
    }
    return self;
}

- (void)dealloc
{
    tkim_io_sync_safe(^{
        [_db close];
        _db = nil;
    });
}

#pragma mark - Public API
- (NSArray *)fetchSystemNotifications:(TKIMSystemNotification *)notification
                                limit:(NSInteger)limit
                               filter:(TKIMSystemNotificationFilter *)filter
{
    __block NSArray *result = nil;
    
    NSString *sql = nil;
    NSString *timeCondition = @" order by timetag desc limit ?";
    NSString *filterCondition = [self filterCondition:filter];
    if (notification)
    {
        sql = [NSString stringWithFormat:@"select * from notifications where timetag < %lld and status != ?",
               TKIMTimeDoubleToLong(notification.timestamp)] ;
    }
    else
    {
        sql = @"select * from notifications where status != ?";
    }
    if (filterCondition)
    {
        sql = [sql stringByAppendingFormat:@" and %@",filterCondition];
    }
    sql = [sql stringByAppendingString:timeCondition];
    
    
    tkim_io_sync_safe(^{
        NSMutableArray *array = [NSMutableArray array];
        TKIMResultSet *rs = [self.db executeQuery:sql,@(TKIMNotificationStatusDeleted),@(limit)];
        while ([rs next])
        {
            TKIMSystemNotification *notification = [[TKIMSystemNotification alloc] init];
            notification.serial         = (NSInteger)[rs intForColumn:@"serial"];
            notification.type           = (NSInteger)[rs intForColumn:@"type"];
            notification.timestamp      = TKIMTimeLongToDouble([rs longLongIntForColumn:@"timetag"]);
            notification.sourceID       = [rs stringForColumn:@"source"];
            notification.targetID       = [rs stringForColumn:@"target"];
            notification.attachString   = [rs stringForColumn:@"attach"];
            notification.postscript     = [rs stringForColumn:@"postscript"];
            notification.status         = (NSInteger)[rs intForColumn:@"status"];
            notification.handleStatus   = (NSInteger)[rs intForColumn:@"substatus"];
            notification.msgId          = [rs longLongIntForColumn:@"msg_id"];
            
            [array addObject:notification];
        }
        [rs close];
        result = array;
    });
    
    return result;
}

- (NSInteger)allUnreadCount:(TKIMSystemNotificationFilter *)filter
{
    __block NSInteger count = 0;
    tkim_io_sync_safe(^{
        NSString *condition = [self filterCondition:filter];
        if (condition)
        {
            NSString *sql = [NSString stringWithFormat:@"select count(serial) from notifications where status = ? and %@",condition];
            TKIMResultSet *rs = [self->_db executeQuery:sql,@(TKIMNotificationStatusNone)];
            if ([rs next])
            {
                count = (NSInteger)[rs intForColumnIndex:0];
            }
            [rs close];
        }
        else
        {
            count = self->_totalUnreadCount;
        }
    });
    return count;
}

- (void)deleteNotification:(TKIMSystemNotification *)notification
{
    NSString *sql = @"update notifications set status  = ? where serial = ?";
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(TKIMNotificationStatusDeleted),@(notification.serial)])
        {
            TKIMLogErr(@"update failed %@ error %@",notification,self.db.lastError);
        }
        [self queryUnreadCount];
    });
}

- (void)deleteAllNotifications:(TKIMSystemNotificationFilter *)filter
{
    NSString *sql = @"update notifications set status  = ? where (status < ? or status > ?)";
    NSString *filterCondition = [self filterCondition:filter];
    if (filterCondition)
    {
        sql = [sql stringByAppendingFormat:@" and %@",filterCondition];
    }
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(TKIMNotificationStatusDeleted),@(TKIMNotificationStatusDeleted),@(TKIMNotificationStatusDeleted)])
        {
            TKIMLogErr(@"delete notifications failed");
        }
        [self queryUnreadCount];
    });
}

- (void)markNotificationsAsRead:(TKIMSystemNotification *)notification
{
    if (notification.status == TKIMNotificationStatusNone)
    {
        notification.status = TKIMNotificationStatusRead;
    }
    NSString *sql = @"update notifications set status  = ? where serial = ? and status = ?";
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(TKIMNotificationStatusRead),@(notification.serial),@(TKIMNotificationStatusNone)])
        {
            TKIMLogErr(@"update failed %@",notification);
        }
        [self queryUnreadCount];
    });

}

- (void)markAllNotificationsAsRead:(TKIMSystemNotificationFilter *)filter
{
    NSString *sql = @"update notifications set status  = ? where status = ?";
    NSString *filterCondition = [self filterCondition:filter];
    if (filterCondition)
    {
        sql = [sql stringByAppendingFormat:@" and %@ ",filterCondition];
    }
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(TKIMNotificationStatusRead),@(TKIMNotificationStatusNone)])
        {
            TKIMLogErr(@"mark notifications read failed");
        }
        [self queryUnreadCount];
    });
}

- (void)sendCustomNotification:(TKIMCustomSystemNotification *)notification
                     toSession:(TKIMSession *)session
                    completion:(TKIMSystemNotificationHandler)completion
{
    if (![[TKIMSessionValidator validator:session] isValid] ||
        ![notification isKindOfClass:[TKIMCustomSystemNotification class]])
    {
        if (completion) {
            completion(TKIMLocalError(TKIMLocalErrorCodeInvalidParam));
        }
        return;
    }
    
    notification.sender         = [[TKIMCoreCenter sharedCenter] currentUserID];
    notification.receiver       = session.sessionId;
    notification.receiverType   = session.sessionType;
    
    NSString *messageId = [TKIMUtil uuid];
    if (completion)
    {
        [_customNotifications setObject:[completion copy]
                                 forKey:messageId];
        
    }
    [self sendCustomNotification:notification
                   withMessageId:messageId];
}



#pragma mark - 更新系统消息状态
- (void)updateNotificationStatus:(TKIMSystemNotification *)notification
{
    NSString *sql = @"update notifications set status  = ? where serial = ?";
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(notification.status),@(notification.serial)])
        {
            TKIMLogErr(@"update failed %@",notification);
        }
        [self queryUnreadCount];
    });


}

- (void)updateNotificationSubStatus:(TKIMSystemNotification *)notification
{
    NSString *sql = @"update notifications set substatus  = ? where serial = ?";
    tkim_io_async(^{
        if (![self.db executeUpdate:sql,@(notification.handleStatus),@(notification.serial)])
        {
            TKIMLogErr(@"update failed %@",notification);
        }
    });

}

#pragma mark - misc
- (void)openDatabase
{
    NSString *filepath = [[[TKIMPathManager sharedManager] sdkCurrentUserDir] stringByAppendingPathComponent:@"notification.db"];
    TKIMDatabase *db = [TKIMDatabase databaseWithPath:filepath];
    if ([db open])
    {
        _db = db;
        NSArray *sqls = @[@"create table if not exists notifications(serial integer primary key, \
                          type integer,timetag integer,source text,target text,postscript text,attach text,status integer,\
                          substatus integer, msg_id integer unique)",
                          //移除旧的index
                         @"drop index if exists statusindex",
                          //添加新的index
                         @"create index if not exists statustypeindex on notifications(status,type)",
                         @"create index if not exists timetagindex on notifications(timetag)"];
        for (NSString *sql in sqls)
        {
            if (![_db executeUpdate:sql])
            {
                TKIMLogErr(@"error: execute sql %@ failed error %@",sql,_db.lastError);
            }
        }
        [self queryUnreadCount];
    }
    else
    {
        TKIMLogErr(@"error open database failed %@",filepath);
    }
}

- (void)queryUnreadCount
{
    NSInteger count = 0;
    NSString *sql = @"select count(serial) from notifications where status = ?";
    TKIMResultSet *rs = [_db executeQuery:sql,@(TKIMNotificationStatusNone)];
    if ([rs next])
    {
         count = (NSInteger)[rs intForColumnIndex:0];
    }
    [rs close];

    if (count != _totalUnreadCount)
    {
        _totalUnreadCount = count;
        dispatch_async(dispatch_get_main_queue(), ^{
            [[TKIMDelegateCenter notificationDelegate] onSystemNotificationCountChanged:count];
        });
    }
}

- (BOOL)saveNotification:(TKIMSystemNotification *)notification
{
    __block BOOL result = NO;
    tkim_io_sync_safe(^{
        if (notification)
        {
            NSString *sql = @"insert into notifications(type,timetag,source,target,postscript,attach,status,substatus,msg_id)  \
            values(?,?,?,?,?,?,?,?,?)";
            if (![self.db executeUpdate:sql,
                @(notification.type),
                 @(TKIMTimeDoubleToLong(notification.timestamp)),
                 notification.sourceID,
                 notification.targetID,
                 notification.postscript,
                 notification.attachString,
                 @(TKIMNotificationStatusNone),
                 @(0),
                 @(notification.msgId)])
            {
                TKIMLogErr(@"update failed %@ error %@",notification,self.db.lastError);
            }
            else
            {
                notification.serial = (NSInteger)[self.db lastInsertRowId];
                result = YES;
            }
        }
    });
    return result;
}


- (void)onReceiveSystemNotification:(TKIMSystemNotification *)notification{
    [[TKIMUserInfoManager sharedManager] checkSystemNotification:notification];
    [[TKIMDelegateCenter notificationDelegate]  onReceiveSystemNotification:notification];
}

- (void)onReceiveCustomSystemNotification:(TKIMCustomSystemNotification *)notification{
    
    [[TKIMUserInfoManager sharedManager] checkCustomSystemNotification:notification];
    [[TKIMDelegateCenter notificationDelegate]  onReceiveCustomSystemNotification:notification];
}

#pragma mark - types
- (NSString *)filterCondition:(TKIMSystemNotificationFilter *)filter
{
    NSString *condition = nil;
    if ([filter isKindOfClass:[TKIMSystemNotificationFilter class]])
    {
        NSMutableArray *types = [NSMutableArray array];
        if ([filter.notificationTypes isKindOfClass:[NSArray class]])
        {
            for (id type in filter.notificationTypes)
            {
                if ([type isKindOfClass:[NSString class]])
                {
                    [types addObject:type];
                }
                else if([type isKindOfClass:[NSNumber class]])
                {
                    [types addObject:[type stringValue]];
                }
            }
        }
        
        NSInteger count = [types count];
        if (count == 1)
        {
            condition = [NSString stringWithFormat:@" type = %@ ",[types firstObject]];
        }
        else if(count > 1)
        {
            NSString *inValue = [NSString stringWithFormat:@" (%@) ",[types componentsJoinedByString:@","]];
            condition = [NSString stringWithFormat:@" type in %@ ",inValue];
        }
    }
    return condition;

}


#pragma mark - 自定义系统通知
- (void)sendCustomNotification:(TKIMCustomSystemNotification *)notification
                 withMessageId:(NSString *)messageId
{
    id<TKIMSessionService>service = (id<TKIMSessionService>)GetServiceFromCore(SVID_TKIM_SESSION);
    if (service)
    {
        NSMutableDictionary *msg = @{
            @(TKIMSystemMsgTagType):@((uint32_t)[self notificationType:notification.receiverType]),
            @(TKIMSystemMsgTagToAccount):notification.receiver,
            @(TKIMSystemMsgTagFromAccount):notification.sender,
            @(TKIMSystemMsgTagAttach):notification.content,
            @(TKIMSystemMsgTagSaveFlag):notification.sendToOnlineUsersOnly ? @0 : @1,
        }.mutableCopy;
        
        if ([notification.apnsContent length]) {
            msg[@(TKIMSystemMsgTagApnsText)] = notification.apnsContent;
        }
        NSString *payload = [TKIMProtocolUtil stringByJsonDictionary:notification.apnsPayload];
        if ([notification.apnsContent length]) {
            msg[@(TKIMSystemMsgTagApnsPayload)] = payload;
        }
        
        if (notification.setting) {
            Property settingProperty = notification.setting.settingProperty;
            [msg addEntriesFromDictionary:settingProperty];
        }
        
        [service invokeSendCustomNotification:msg messageId:messageId];
    }
}

- (TKIMCustomSystemNotificationType)notificationType:(TKIMSessionType)sessionType
{
    TKIMCustomSystemNotificationType type = TKIMCustomSystemNotificationTypeP2P;
    switch (sessionType) {
        case TKIMSessionTypeP2P:
            type = TKIMCustomSystemNotificationTypeP2P;
            break;
        case TKIMSessionTypeTeam:
            type = TKIMCustomSystemNotificationTypeTeam;
            break;
        default:
            NSAssert(0, @"invalid type");
            TKIMLogErr(@"invalid session type %zd to notification type",sessionType);
            break;
    }
    return type;
}


- (void)onSendCustomNotificationAck:(NSString *)messageId
                               code:(NSInteger)code
{
    TKIMSystemNotificationHandler handler = [_customNotifications objectForKey:messageId];
    if (handler)
    {
        [_customNotifications removeObjectForKey:messageId];
        handler(TKIMRemoteError(code));
        
    }
}


@end

void    CallbackRecvSysMsgs(IAsynCallbackParam *msgParam)
{
    @autoreleasepool
    {
        CBRecvSysMsgsParam *param = (CBRecvSysMsgsParam *)msgParam;
        TKIMSystemNotificationReceiver *receiver = [[TKIMSystemNotificationReceiver alloc] init];
        receiver.onlineNotification = param.online_msg_;
        [receiver receiveNotifications:param.msgs_];
    }
}

void    CallbackSendCustomNotification(IAsynCallbackParam *msgParam)
{
    
}
