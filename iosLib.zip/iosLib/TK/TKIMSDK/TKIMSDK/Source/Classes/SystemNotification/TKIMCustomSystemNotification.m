//
//  TKIMCustomSystemNotification.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import "TKIMCustomSystemNotification_Private.h"
#import "NSDictionary+TKIMJson.h"
#import "TKIMTeamServiceProtocol.h"
#import "TKIMSessionServiceProtocol.h"
#import "TKIMProtocolUtil.h"
#import "TKIMCustomSystemNotificationSetting_Private.h"

@implementation TKIMCustomSystemNotification

- (instancetype)init
{
    if (self = [super init])
    {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithContent:(NSString *)content
{
    if (self = [super init])
    {
        [self commonInit];
        _content = content;
    }
    return self;
}

- (instancetype)initWithPorperty:(Property)property
{
    if (self = [super init])
    {
        _timestamp                  = TKIMTimeLongToDouble([property[@(TKIMSystemMsgTagTime)] longLongValue]);
        _sender                     = property[@(TKIMSystemMsgTagFromAccount)];
        _receiver                   = property[@(TKIMSystemMsgTagToAccount)];
        _msgId                      = [property[@(TKIMSystemMsgTagMsgID)] longLongValue];
        _content                    = property[@(TKIMSystemMsgTagAttach)];
        _apnsContent                = property[@(TKIMSystemMsgTagApnsText)];
        _apnsPayload                = [TKIMProtocolUtil dictByJsonString:property[@(TKIMSystemMsgTagApnsPayload)]];
        NSInteger type              = (NSInteger)property[@(TKIMSystemMsgTagType)];
        _receiverType               = type == TKIMCustomSystemNotificationTypeTeam ? TKIMSessionTypeTeam : TKIMSessionTypeP2P;
        _sendToOnlineUsersOnly      = _msgId == 0;
        _setting                    = [TKIMCustomSystemNotificationSetting settingByProperty:property];
    }
    return self;
}

- (void)commonInit
{
    _sendToOnlineUsersOnly = YES;
    _timestamp = [[NSDate date] timeIntervalSince1970];
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"cn: msg id %lld content %@ setting %@",_msgId,_content,_setting];
}
@end
