//
//  TKIMSystemNotificationManagerWrapper.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <Foundation/Foundation.h>
#import "TKIMSystemNotificationManagerProtocol.h"

@interface TKIMSystemNotificationManagerWrapper : NSObject<TKIMSystemNotificationManager>
+ (instancetype)sharedWrapper;
@end
