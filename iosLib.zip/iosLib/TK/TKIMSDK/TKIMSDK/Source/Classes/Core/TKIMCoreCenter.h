//
//  TKIMCoreCenter.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@interface TKIMCoreCenter : NSObject
+ (instancetype)sharedCenter;
- (void)start;
- (void)close;
- (void)setup:(NSString *)userID;

- (NSString *)currentUserID;
- (void)beginToConnect;
- (void)save;
@end
