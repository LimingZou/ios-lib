//
//  TKIMManager.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import "TKIMMacros.h"

//link
#import "TKIMService.h"
#import "TKIMCore.h"

@protocol TKIMManager <NSObject>
@optional
- (void)onReceiveMemoryWarning;
- (void)onEnterBackground;
- (void)onEnterForeground;
- (void)onAppWillTerminate;
@end

@interface TKIMManager : NSObject<TKIMManager>
+ (instancetype)sharedManager;

//空方法，只是输出log而已
//大部分的TKIMManager懒加载即可，但是有些因为业务需要在登录后就需要立马生成
- (void)start;
@end



@interface TKIMManagerCenter : NSObject
+ (id)sharedCenter;

- (void)createCenter;
- (void)destroyCenter;
@end
