//
//  TKIMLinkListener.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/1.
//

#import <Foundation/Foundation.h>
#import "TKIMCore.h"
@class TKIMLinkListener;

@protocol TKIMLinkProtocol <NSObject>
@optional
- (void)onNetChanged:(TKIMLinkListener *)listener;
- (void)onDisconnect:(TKIMLinkListener *)listener;
- (void)onConnectionBegin:(TKIMLinkListener *)listener;
- (void)onConnectSuccess:(TKIMLinkListener *)listener;
- (void)onConnectFailed:(TKIMLinkListener *)listener;
- (BOOL)shouldConnectServer:(TKIMLinkListener *)listener;
@end

typedef enum : NSUInteger
{
    TKIMConnectStateInit,           //初始状态
    TKIMConnectStateConnecting,     //正在链接
    TKIMConnectStateConnected,      //已链接
} TKIMConnectState;


@interface TKIMLinkListener : NSObject
+ (instancetype)sharedListener;
@property (nonatomic,assign)    TKIMConnectState    state;                   //链接状态
@property (nonatomic,strong)    NSString *token; 
@property (nonatomic,weak)      id<TKIMLinkProtocol>  delegate;              //回调

- (void)checkState;
@end

void    CallbackConnectLink(IAsynCallbackParam *connectParam);              //连接服务器callback
void    CallbackDisconnectLink(IAsynCallbackParam *disconnectParam);        //断开连接callback
