//
//  TKIMCoreCenter.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMCoreCenter.h"
#import "TKIMLinkListener.h"
#import "TKIMManager.h"
#import "TKIMChatManager.h"
#import "TKIMLoginManager.h"
#import "TKIMTeamManager.h"
#import "TKIMSystemNotificationManager.h"
#import "TKIMUser_Private.h"
#import "TKIMUserInfo_Private.h"
#import "TKIMDelegateCenter.h"
#import "TKIMDispatch.h"

//link
#import "TKIMCoreIMP.h"
#import "TKIMServiceIMP.h"
#import "TKIMIOSUtil.h"
#import "TKIMAuthServiceProtocol.h"
#import "TKIMSessionServiceProtocol.h"
#import "TKIMSyncServiceProtocol.h"
#import "TKIMFriendServiceProtocol.h"
#import "TKIMUserServiceProtocol.h"
#import "TKIMNotifyServiceProtocol.h"
#import "TKIMTeamServiceProtocol.h"

void CallbackUListChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id);
void CallbackRelationChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id);
void CallbackUserChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id);

@interface TKIMCoreCenter ()
@end

@implementation TKIMCoreCenter
+ (instancetype)sharedCenter
{
    static TKIMCoreCenter *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMCoreCenter alloc] init];
    });
    return instance;
}

- (void)start
{
    if (TKIMCore_Get() == nil)
    {
        TKIMCore_Create();
        [TKIMService LoadPreLoginServices];
        
        id<TKIMAuthService>auth = (id<TKIMAuthService>)GetServiceFromCore(SVID_TKIM_AUTH);
        if (auth)
        {
            [auth registerConnectCallback:CallbackConnectLink];
            
            [auth registerKickoutCallback:CallbackKickout];
            
            [auth registerMultipLoginCallback:CallbackMultiLogin];
        }
        
        [TKIMCore_Get() registerDisConnectCallback:CallbackDisconnectLink];
        [[TKIMLinkListener sharedListener] setState:TKIMConnectStateInit];
        TKIMLogApp(@"talk core start");
    }
    
}

- (void)close
{
    TKIMCore_Close(0);
}

- (NSString *)currentUserID
{
    TKIMCore *core = TKIMCore_Get();
    if (core) {
        [core uid];
    }
    
    if ([core uid] == nil) {
        TKIMLogApp(@"uid is empty");
    }
    return [core uid];
}

- (void)setup:(NSString *)userID
{
    TKIMCore *core = TKIMCore_Get();
    if (core)
    {
        TKIMLogApp(@"setup core by %@",userID);
        [core setUid:userID];
        
        [self createCenter];
        [self registerCallbacks];
        [self addDocumentWatchers];
    }
    else
    {
        TKIMAssert();
    }
}


- (void)beginToConnect
{
    id<TKIMAuthService>service = (id<TKIMAuthService>)GetServiceFromCore(SVID_TKIM_AUTH);
    
    if (service)
    {
        [service invokeConnect];
    }
    else
    {
        TKIMLogApp(@"core not ready");
    }
}

- (void)save
{
    TKIMCore *core = TKIMCore_Get();
    if (core)
    {
        [core flushDocument];
    }
}

- (BOOL)isInSync
{
    BOOL sync = NO;
    id<TKIMSyncService>service = (id<TKIMSyncService>)GetServiceFromCore(SVID_TKIM_SYNC);
    if (service) {
        sync = [service isInSync];
    }
    return sync;
}

#pragma mark - setup
- (void)createCenter
{
    [[TKIMManagerCenter sharedCenter] createCenter];
}

- (void)registerCallbacks
{
    id<TKIMSessionService>session = (id<TKIMSessionService>)GetServiceFromCore(SVID_TKIM_SESSION);
    if (session) {
        [session registerSendMsgCallback:CallbackSendMsg];
        [session registerRecvMsgsCallback:CallbackRecvMsgs];
        [session registerRecvSysMsgsCallback:CallbackRecvSysMsgs];
        [session registerRecvMsgReceiptCallback:CallbackRecvReceipt];
    }
    
    id<TKIMNotifyService>notify = (id<TKIMNotifyService>)GetServiceFromCore(SVID_TKIM_NOTIFY);
    if (notify)
    {
        [notify registerRecvMsgsCallback:CallbackRecvMsgs];
    }

    
    id<TKIMSyncService>sync = (id<TKIMSyncService>)GetServiceFromCore(SVID_TKIM_SYNC);
    if (sync)
    {
        [sync registerSyncCallback:CallbackSync];
    }
    
    id<TKIMTeamService>team = (id<TKIMTeamService>)GetServiceFromCore(SVID_TKIM_TEAM);
    if (team)
    {
        IAsynCallback teamActionCallback = CallbackTeamAction;
        [team registerActionCallback:teamActionCallback];
        
        IAsynCallback teamTlistChangedCallback = CallbackTlistChanged;
        [team registerTlistChangedCallback:teamTlistChangedCallback];
        
        IAsynCallback teamInfoChangedCallback = CallbackTInfoChanged;
        [team registerTInfoChangedCallback:teamInfoChangedCallback];
    }


}

- (void)addDocumentWatchers
{
    TKIMCore *core = TKIMCore_Get();
    if (core == nil) {
        TKIMLogErr(@"add document watcher");
        return;
    }

    if (![core isWatched]) {
        TKIMLogApp(@"add document watch");
        
        if (HostUserInfos()) {
            IWatchHandler ulistWatcher = CallbackUListChanged;
            [core watch:ulistWatcher dataId:DN_FRIENDS];

            IWatchHandler userWatcher = CallbackUserChanged;
            [core watch:userWatcher dataId:DN_USERS];
        }
        IWatchHandler relationWatcher = CallbackRelationChanged;
        [core watch:relationWatcher dataId:DN_RELATION];

        [core setWatached:YES];
    }
}

@end

#pragma mark - Document Watcher
void CallbackUListChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id)
{
    @autoreleasepool {
        id<TKIMFriendService>service = (id<TKIMFriendService>)GetServiceFromCore(SVID_TKIM_FRIEND);
        TKIMUser *user = nil;
        if (service) {
            NSMutableDictionary *property = @{}.mutableCopy;
            [service getFriendInfo:item_id info:&property];
            [property setObject:item_id forKey:@(TKIMUListTagId)];
            user = [[TKIMUser alloc] initWithProperty:property];
        }
        
        id<TKIMUserService>infoService = (id<TKIMUserService>)GetServiceFromCore(SVID_TKIM_USER);
        if (user && infoService) {
            Property property;
            [infoService getUserInfo:item_id info:&property];
            TKIMUserInfo *info = [TKIMUserInfo userInfoWithProperty:property];
            user.userInfo = info;
        }
        
        if (user)
        {
            tkim_main_async_safe(^{
                [[TKIMDelegateCenter userDelegate] onFriendChanged:user];
            });
        }
    }
}

void CallbackRelationChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id)
{
    @autoreleasepool {
        BOOL blackListChanged = NO;
        NSArray *allObjects = [tags allObjects];
        for (int it = 0; it < allObjects.count; it++){
            uint32_t tag = [allObjects[it] unsignedIntValue];
            if (tag == TKIMRelationTagBlackList) {
                blackListChanged = YES;
                break;
            }
        }
        if (blackListChanged) {
            tkim_main_async_safe(^{
                [[TKIMDelegateCenter userDelegate] onBlackListChanged];
            });
        }
    }
}

void CallbackUserChanged(NSString *data_id, NSString * item_id, TagSet tags, int event_id)
{
    @autoreleasepool {
        TKIMUser *user = nil;
        id<TKIMFriendService>service = (id<TKIMFriendService>)GetServiceFromCore(SVID_TKIM_FRIEND);
        if (service)
        {
            Property property;
            [service getFriendInfo:item_id info:&property];
            NSMutableDictionary *newProperty = property.mutableCopy;
            [newProperty setObject:item_id forKey:@(TKIMUListTagId)];
            user = [[TKIMUser alloc] initWithProperty:property];
        }
        
        id<TKIMUserService>infoService = (id<TKIMUserService>)GetServiceFromCore(SVID_TKIM_USER);
        if (user && infoService)
        {
            Property property;
            [infoService  getUserInfo:item_id info:&property];
            TKIMUserInfo *info = [TKIMUserInfo userInfoWithProperty:property];
            user.userInfo     = info;
        }

        if (user)
        {
            tkim_main_async_safe(^{
                [[TKIMDelegateCenter userDelegate] onUserInfoChanged:user];
            });
        }

    }
}
