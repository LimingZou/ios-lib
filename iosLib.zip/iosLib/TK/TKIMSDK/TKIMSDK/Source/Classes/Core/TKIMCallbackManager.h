//
//  TKIMCallbackManager.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/8.
//

#import <Foundation/Foundation.h>
#import "TKIMManager.h"
#import "TKIMGlobalDefs.h"
#import "TKIMMacros.h"

@interface TKIMCallbackResult : NSObject
@property (nonatomic,strong)    NSError *error;
@property (nonatomic,strong)    id resultObject;
@end


@protocol TKIMCallback <NSObject>
@required
- (void)convertParam:(IAsynCallbackParam *)param
            toResult:(TKIMCallbackResult *)result;

- (void)run:(TKIMCallbackResult *)result;
@end



@interface TKIMCallbackManager : TKIMManager
- (void)setCallback:(id<TKIMCallback>)object
            forTask:(NSInteger)taskId;
@end

IAsynCallback GetTKIMCallback(void);
