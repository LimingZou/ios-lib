//
//  TKIMTaskEngine.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/8.
//

#import "TKIMTaskEngine.h"
#import "TKIMMacros.h"


@interface TKIMTaskEngine ()
{
    BOOL _isCleanTask;
    NSOperationQueue *_taskQueue;
}
@end

@implementation TKIMTaskEngine
+ (instancetype)sharedEngine
{
    static TKIMTaskEngine *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMTaskEngine alloc]init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init])
    {
        _taskQueue = [[NSOperationQueue alloc]init];
        _taskQueue.name = @"tkim_task_queue";
        [_taskQueue setMaxConcurrentOperationCount:1];
        

    }
    return self;
}


- (void)runTask:(EngineTask)task
{
    if (_isCleanTask)
    {
        TKIMLogWar(@"Task Not Executed Beacuse Of In Cleaning");
        return;
    }
#if DEBUG
    NSArray *array =  [NSThread callStackSymbols];
    [_taskQueue addOperationWithBlock:^{
        NSDate *begin = [NSDate date];
        if (task)
        {
            task();
        }
        NSTimeInterval timeCost = [[NSDate date] timeIntervalSinceDate:begin];
        if (timeCost >= 2.0)
        {
            //如果进入到这个流程,需要考虑当前task是否能够放在taskQueue里面
            TKIMLogWar(@"Task‘s Time Cost Is %lf \n ....................\n%@",timeCost,array);
        }
    }];
#else
    [_taskQueue addOperationWithBlock:^{
        if (task)
        {
            task();
        }
    }];
#endif
}


@end
