//
//  TKIMCallbackManager.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/8.
//

#import "TKIMCallbackManager.h"
#import "TKIMDispatch.h"
//#import "bind.h"
//#import "callback.h"
#import "TKIMGlobalDefs.h"

@implementation TKIMCallbackResult
- (instancetype)init
{
    if (self = [super init])
    {
        _error = TKIMLocalError(TKIMLocalErrorCodeInvalidParam);
    }
    return self;
}
@end

@interface TKIMCallbackManager ()
@property (nonatomic,strong)    NSMutableDictionary *callbacks;
@property (nonatomic,strong)    NSRecursiveLock *lock;
@end

@implementation TKIMCallbackManager

- (instancetype)init
{
    if (self = [super init])
    {
        _callbacks = [NSMutableDictionary dictionary];
        _lock = [[NSRecursiveLock alloc] init];
    }
    return self;
}


- (void)setCallback:(id<TKIMCallback>)object
            forTask:(NSInteger)taskId
{
    [_lock lock];
    if (object)
    {
        if ([_callbacks objectForKey:@(taskId)] == nil)
        {
            [_callbacks setObject:object
                           forKey:@(taskId)];
        }
        else
        {
            TKIMAssert();
        }
    }

    [_lock unlock];
}

- (id<TKIMCallback>)callback:(NSInteger)taskId
{
    id<TKIMCallback> callback = nil;
    [_lock lock];
    callback = [_callbacks objectForKey:@(taskId)];
    [_lock unlock];
    return callback;
}

- (void)removeCallback:(NSInteger)taskId
{
    [_lock lock];
    [_callbacks removeObjectForKey:@(taskId)];
    [_lock unlock];
}

@end

void    CallbackTKIM(IAsynCallbackParam *result)
{
    @autoreleasepool
    {
        if (result)
        {
            IAsynTaskCallbackParam *param = (IAsynTaskCallbackParam *)result;
            if (param)
            {
                NSInteger taskId = param.task_id_;
                id<TKIMCallback> callback = [[TKIMCallbackManager sharedManager] callback:taskId];
                if (callback)
                {
                    TKIMCallbackResult *callbackResult = [[TKIMCallbackResult alloc] init];
                    if ([callback respondsToSelector:@selector(convertParam:toResult:)])
                    {
                        [callback convertParam:result
                                      toResult:callbackResult];
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if ([callback respondsToSelector:@selector(run:)])
                            {
                                [callback run:callbackResult];
                            }
                        });
                    }
                    [[TKIMCallbackManager sharedManager] removeCallback:taskId];
                }
            }
        }
    }
}


IAsynCallback GetTKIMCallback(void){
    return CallbackTKIM;
}
