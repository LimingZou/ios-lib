//
//  TKIMDelegateCenter.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>
#import "TKIMLoginManagerProtocol.h"
#import "TKIMChatManagerProtocol.h"
#import "TKIMConversationManagerProtocol.h"
#import "TKIMTeamManagerProtocol.h"
#import "TKIMSystemNotificationManagerProtocol.h"
#import "TKIMNetCallManagerProtocol.h"
#import "TKIMRTSManagerProtocol.h"
#import "TKIMUserManagerProtocol.h"
#import "TKIMChatroomManagerProtocol.h"


typedef NS_ENUM(NSInteger, TKIMDelegateType)
{
    TKIMDelegateTypeLogin,
    TKIMDelegateTypeChat,
    TKIMDelegateTypeConversation,
    TKIMDelegateTypeTeam,
    TKIMDelegateTypeNotification,
    TKIMDelegateTypeNetCall,
    TKIMDelegateTypeRTS,
    TKIMDelegateTypeUser,
    TKIMDelegateTypeChatroom,
};


@interface TKIMDelegateCenter : NSObject
+ (instancetype)sharedCenter;

- (void)addDelegate:(id)delegate
            forType:(TKIMDelegateType)type;

- (void)removeDelegate:(id)delegate
               forType:(TKIMDelegateType)type;

+ (id<TKIMLoginManagerDelegate>)loginDelegate;
+ (id<TKIMChatManagerDelegate>)chatDelegate;
+ (id<TKIMConversationManagerDelegate>)conversationDelegate;
+ (id<TKIMTeamManagerDelegate>)teamDelegate;
+ (id<TKIMSystemNotificationManagerDelegate>)notificationDelegate;
+ (id<TKIMNetCallManagerDelegate>)netCallDelegate;
+ (id<TKIMRTSManagerDelegate>)rtsDelegate;
+ (id<TKIMUserManagerDelegate>)userDelegate;
+ (id<TKIMChatroomManagerDelegate>)chatroomDelegate;
@end
