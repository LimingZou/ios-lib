//
//  TKIMLinkListener.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/1.
//

#import "TKIMLinkListener.h"
#import "TKIMReachability.h"
#import "TKIMResponseCode.h"
#import "TKIMAuthServiceProtocol.h"
#import "TKIMCoreCenter.h"
#import "TKIMTimer.h"
#import "TKIMSDK_Private.h"

//link
#import "TKIMCoreIMP.h"

TKIMNotification(TKIMConnectNotification);
TKIMNotification(TKIMDisconnectNotification);
TKIMNotification(TKIMRespCode);
TKIMNotification(TKIMConnectStep);
TKIMNotification(TKIMSocketToken);

@interface TKIMLinkListener ()<TKIMTimerDelegate>
@property (nonatomic,strong)    TKIMReachability    *networkListener;   //网络时间监听
@property (nonatomic,strong)    TKIMTimer           *reconnectTimer;    //重连Timer(重链需要delay一段时间)
@property (nonatomic,assign)    BOOL               connectOnce;        //是否尝试过至少一次连接
@end


@implementation TKIMLinkListener
+ (instancetype)sharedListener
{
    static TKIMLinkListener *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMLinkListener alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init])
    {
        [self addListenEvents];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_networkListener stopNotifier];
}

- (void)checkState
{
    [self beginToConnect];
}

- (void)addListenEvents
{
    
    //连接到服务器通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onConnectNotify:)
                                                 name:TKIMConnectNotification
                                               object:nil];
    
    //网络切换通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onNetChanged:)
                                                 name:TKIMReachabilityChangedNotification
                                               object:nil];
    
    //与服务器断开连接通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onDisconnect:)
                                                 name:TKIMDisconnectNotification
                                               object:nil];
    
    self.networkListener = [TKIMReachability reachabilityForInternetConnection];
    [_networkListener startNotifier];
}

#pragma mark - 事件处理
- (void)onConnectNotify:(NSNotification *)aNotification
{
    NSDictionary *dict = aNotification.userInfo;
    NSInteger code = [dict[TKIMRespCode] integerValue];
    NSInteger step = [dict[TKIMConnectStep] integerValue];
    TKIMLogApp(@"get connection notification: %@",dict);
    if (code == TKIMResSuccess)
    {
        if (step == TKIMConnectStepLinked)
        {
            _state = TKIMConnectStateConnected;
            if (_delegate && [_delegate respondsToSelector:@selector(onConnectSuccess:)])
            {
                [_delegate onConnectSuccess:self];
            }
        }
    }
    else
    {
        _state = TKIMConnectStateInit;
        if (_delegate && [_delegate respondsToSelector:@selector(onConnectFailed:)])
        {
            [_delegate onConnectFailed:self];
        }
        [self reconnect:1];
    }
}

- (void)onNetChanged:(NSNotification *)aNotification
{
    TKIMLogApp(@"net device changed: %@",[_networkListener currentReachabilityString]);
    //网络切换后,修改登录状态为非登录
    TKIMCore *core = TKIMCore_Get();
    if (core) {
        [core setLogin:NO];
    }
    
    if (_state == TKIMConnectStateConnected)
    {
        _state = TKIMConnectStateInit;
    }
    if (_delegate && [_delegate respondsToSelector:@selector(onNetChanged:)])
    {
        [_delegate onNetChanged:self];
    }
    [self reconnect:1];
}

- (void)onDisconnect:(NSNotification *)aNotification
{
    TKIMLogApp(@"on disconnect from server");
    if (_state == TKIMConnectStateConnected)
    {
        _state = TKIMConnectStateInit;
    }
    if (_delegate && [_delegate respondsToSelector:@selector(onDisconnect:)])
    {
        [_delegate onDisconnect:self];
    }
    [self reconnect:1];
}

#pragma mark - misc
- (void)onTKIMTimerFired:(TKIMTimer *)holder
{
    [self beginToConnect];
}

#pragma mark - 重连
- (void)reconnect:(NSTimeInterval)delay
{
    TKIMLogApp(@"set timer for reconnecting %d",(int)delay);
    if (delay)
    {
        if (_reconnectTimer == nil)
        {
            _reconnectTimer = [[TKIMTimer alloc]init];
        }
        [_reconnectTimer startTimer:delay
                           delegate:self
                            repeats:NO];
    }
    else
    {
        [self beginToConnect];
    }
}


- (void)beginToConnect
{
    TKIMLogApp(@"try to connect link");
    if (![_networkListener isReachable])
    {
        TKIMLogApp(@"bad connection state %@ with %d",[_networkListener currentReachabilityString],_connectOnce);
        if (_connectOnce)
        {
            return;
        }
    }
    if (_state == TKIMConnectStateConnecting ||
        _state == TKIMConnectStateConnected)
    {
        TKIMLogApp(@"connect cancelled because of in %lu state",(unsigned long)_state);
        return;
    }
    if (_delegate && [_delegate respondsToSelector:@selector(shouldConnectServer:)])
    {
        if (![_delegate shouldConnectServer:self])
        {
            TKIMLogApp(@"connect cancelled by delegate");
            return;
        }
    }
    _state = TKIMConnectStateConnecting;
    [[TKIMCoreCenter sharedCenter] beginToConnect];
    if (_delegate && [_delegate respondsToSelector:@selector(onConnectionBegin:)])
    {
        [_delegate onConnectionBegin:self];
    }
    _connectOnce = YES;
}

@end

void    CallbackConnectLink(IAsynCallbackParam *connectParam)
{
    @autoreleasepool
    {
        CBConnectStepParam *param = (CBConnectStepParam *)connectParam;
        NSDictionary *dict = @{TKIMConnectStep:@(param.step_),
                               TKIMRespCode:@(param.code_)};
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:TKIMConnectNotification
                                                                object:nil
                                                              userInfo:dict];
        });
    }

}
void    CallbackDisconnectLink(IAsynCallbackParam *disconnectParam)
{
    @autoreleasepool
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:TKIMDisconnectNotification
                                                                object:nil];
        });
    }

}

