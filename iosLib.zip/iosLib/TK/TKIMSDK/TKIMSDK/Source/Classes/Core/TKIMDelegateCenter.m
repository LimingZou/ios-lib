//
//  TKIMDelegateCenter.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMDelegateCenter.h"
#import "TKIMMulticastDelegate.h"
#import "TKIMDispatch.h"




@interface TKIMDelegateCenter ()
@property (nonatomic,strong)    NSDictionary *delegates;
@end

@implementation TKIMDelegateCenter
+ (instancetype)sharedCenter
{
    static TKIMDelegateCenter *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMDelegateCenter alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init])
    {
        _delegates = @{@(TKIMDelegateTypeLogin)          : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeChat)           : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeConversation)   : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeTeam)           : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeNotification)   : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeNetCall)        : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeRTS)            : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeUser)           : [[TKIMMulticastDelegate alloc] init],
                       @(TKIMDelegateTypeChatroom)       : [[TKIMMulticastDelegate alloc] init],
                       };
    }
    return self;
}

- (void)addDelegate:(id)delegate
            forType:(TKIMDelegateType)type
{
    tkim_main_sync_safe(^{
        [self->_delegates[@(type)] addDelegate:delegate];
    });
}

- (void)removeDelegate:(id)delegate
               forType:(TKIMDelegateType)type
{
    tkim_main_sync_safe(^{
        [self->_delegates[@(type)] removeDelegate:delegate];
    });
}

- (id)delegateForType:(TKIMDelegateType)type
{
    TKIMMTAssert();
    return _delegates[@(type)];
}


#pragma mark - 读取接口
+ (id<TKIMLoginManagerDelegate>)loginDelegate
{
    return (id<TKIMLoginManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeLogin]);
}

+ (id<TKIMChatManagerDelegate>)chatDelegate
{
    return (id<TKIMChatManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeChat]);
}

+ (id<TKIMConversationManagerDelegate>)conversationDelegate
{
    return (id<TKIMConversationManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeConversation]);
}

+ (id<TKIMTeamManagerDelegate>)teamDelegate
{
    return (id<TKIMTeamManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeTeam]);
}


+ (id<TKIMSystemNotificationManagerDelegate>)notificationDelegate
{
    return (id<TKIMSystemNotificationManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeNotification]);
}


+ (id<TKIMNetCallManagerDelegate>)netCallDelegate
{
    return (id<TKIMNetCallManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeNetCall]);
}


+ (id<TKIMRTSManagerDelegate>)rtsDelegate
{
    return (id<TKIMRTSManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeRTS]);
}

+ (id<TKIMUserManagerDelegate>)userDelegate
{
    return (id<TKIMUserManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeUser]);
}

+ (id<TKIMChatroomManagerDelegate>)chatroomDelegate
{
    return (id<TKIMChatroomManagerDelegate>)([[TKIMDelegateCenter sharedCenter] delegateForType:TKIMDelegateTypeChatroom]);
}
@end
