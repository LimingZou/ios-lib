//
//  TKIMTaskEngine.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/8.
//

#import <Foundation/Foundation.h>

typedef dispatch_block_t EngineTask;

@interface TKIMTaskEngine : NSObject
+ (instancetype)sharedEngine;

- (void)runTask:(EngineTask)task;
@end
