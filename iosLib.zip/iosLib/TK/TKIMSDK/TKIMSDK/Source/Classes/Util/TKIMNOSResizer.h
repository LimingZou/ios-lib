//
//  TKIMNOSResizer.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

//传入宽高后,自动会乘以retina scale并返回
//如传入 TKIMNOSX(100,100) 在3gs上返回 100x100  6p上返回300x300 而其他机器返回 200x200

#define TKIMNOSX(w,h) [[TKIMNOSResizer sharedResizer] resize:@"x" width:(w) height:(h)]
#define TKIMNOSY(w,h) [[TKIMNOSResizer sharedResizer] resize:@"y" width:(w) height:(h)]
#define TKIMNOSZ(w,h) [[TKIMNOSResizer sharedResizer] resize:@"z" width:(w) height:(h)]


@interface TKIMNOSResizer : NSObject

+ (instancetype)sharedResizer;

- (CGSize)resizeWidth:(CGFloat)width
               height:(CGFloat)height;

- (NSString *)resize:(NSString *)mode
               width:(CGFloat)width
              height:(CGFloat)height;

- (NSString *)imageThumbnailURL:(NSString *)urlString;
- (NSString *)videoThumbnailURL:(NSString *)urlString;

@end
