//
//  TKIMNetworkConfig.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMNetworkConfig.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "TKIMReachability.h"
#import "TKIMMacros.h"

@interface TKIMNetworkConfig ()
@property (nonatomic,strong)    NSDictionary    *networkTypes;
@end


@implementation TKIMNetworkConfig

+ (instancetype)sharedConfig
{
    static TKIMNetworkConfig *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMNetworkConfig alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init]){
        
        if (TKIMIOS7) {
            _networkTypes = @{CTRadioAccessTechnologyGPRS:@(TKIMNetworkType2G),
                              CTRadioAccessTechnologyEdge:@(TKIMNetworkType2G),
                              CTRadioAccessTechnologyWCDMA:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyHSDPA:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyHSUPA:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyCDMA1x:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyCDMAEVDORev0:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyCDMAEVDORevA:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyCDMAEVDORevB:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyeHRPD:@(TKIMNetworkType3G),
                              CTRadioAccessTechnologyLTE:@(TKIMNetworkType4G),
                              };
        }
    }
    return self;
}

- (TKIMNetworkType)currentNetworkType
{
    TKIMNetworkType type = TKIMNetworkTypeUnknown;
    TKIMNetworkStatus status = [[TKIMReachability reachabilityForInternetConnection] currentReachabilityStatus];
    switch (status) {
        case TKIMReachableViaWiFi:
            type = TKIMNetworkTypeWifi;
            break;
        case TKIMReachableViaWWAN:{
            if (TKIMIOS7) {
                CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
                NSNumber *typeNumber = [_networkTypes objectForKey:telephonyInfo.currentRadioAccessTechnology];
                type = typeNumber ? [typeNumber integerValue] : TKIMNetworkTypeWWAN;
            }
            else{
                type = TKIMNetworkTypeWWAN;
            }
        }
            break;
        default:
            break;
    }
    
    return type;
}

@end
