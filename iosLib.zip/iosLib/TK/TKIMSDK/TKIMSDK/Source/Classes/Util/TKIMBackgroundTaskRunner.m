//
//  TKIMBackgroundTaskRunner.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMBackgroundTaskRunner.h"

@interface TKIMBackgroundTaskRunner ()
@property (nonatomic, assign) UIBackgroundTaskIdentifier  backgroundTaskID;
@end

@implementation TKIMBackgroundTaskRunner
- (instancetype)init
{
    if (self = [super init])
    {
        _backgroundTaskID = UIBackgroundTaskInvalid;
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(didEnterBackground:)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(willEnterForeground:)
                                                     name:UIApplicationWillEnterForegroundNotification
                                                   object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didEnterBackground:(NSNotification *)aNotification
{
    _backgroundTaskID =  [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        if (self -> _backgroundTaskID != UIBackgroundTaskInvalid)
        {
            [[UIApplication sharedApplication] endBackgroundTask:self -> _backgroundTaskID];
            self -> _backgroundTaskID = UIBackgroundTaskInvalid;
        }
    }];
}

- (void)willEnterForeground:(NSNotification *)aNotification
{
    if (_backgroundTaskID != UIBackgroundTaskInvalid)
    {
        [[UIApplication sharedApplication] endBackgroundTask:_backgroundTaskID];
        _backgroundTaskID = UIBackgroundTaskInvalid;
    }
}
@end
