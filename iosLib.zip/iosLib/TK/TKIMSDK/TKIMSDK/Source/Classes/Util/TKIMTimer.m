//
//  TKIMTimer.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMTimer.h"

@interface TKIMTimer ()
{
    NSTimer *_timer;
    BOOL    _repeats;
}
- (void)onTimer: (NSTimer *)timer;
@end

@implementation TKIMTimer

- (void)dealloc
{
    [self stopTimer];
}

- (BOOL)isScheduled
{
    return _timer != nil;
}

- (void)startTimer:(NSTimeInterval)seconds
          delegate:(id<TKIMTimerDelegate>)delegate
           repeats:(BOOL)repeats;
{
    _delegate = delegate;
    _repeats = repeats;
    if (_timer)
    {
        [_timer invalidate];
        _timer = nil;
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:seconds
                                              target:self
                                            selector:@selector(onTimer:)
                                            userInfo:nil
                                             repeats:repeats];
}

- (void)stopTimer
{
    [_timer invalidate];
    _timer = nil;
    _delegate = nil;
}

- (void)onTimer:(NSTimer *)timer
{
    if (!_repeats)
    {
        _timer = nil;
    }
    if (_delegate && [_delegate respondsToSelector:@selector(onTKIMTimerFired:)])
    {
        [_delegate onTKIMTimerFired:self];
    }
}


@end
