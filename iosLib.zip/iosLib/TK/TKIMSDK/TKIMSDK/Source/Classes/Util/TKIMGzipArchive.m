//
//  TKIMGzipArchive.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMGzipArchive.h"
#import "NSData+TKIM.h"

@implementation TKIMGzipArchive

+ (BOOL)gzipArchive:(NSString *)path
              files:(NSArray *)filepaths
            maxSize:(NSInteger)maxSize
{
    NSMutableData *fileData = [NSMutableData data];
    do {
        for (NSString *filepath in filepaths) {
            @autoreleasepool {
                NSData *data = [NSData dataWithContentsOfFile:filepath];
                if ([data length]) {
                    [fileData appendData:data];
                    
                    //写入分隔符
                    NSData *sepData = [@"\n\n\n\n\n\n\n\n\n\nnim seperator\n\n\n\n\n\n\n\n\n\n" dataUsingEncoding:NSUTF8StringEncoding];
                    [fileData appendData:sepData];
                }
                if ([fileData length] >= maxSize) {
                    break;
                }
            }
        }
    } while (0);
    NSData *gzipData = [fileData tkim_gzippedData];
    return [gzipData length] && [gzipData writeToFile:path
                                           atomically:YES];
}

@end
