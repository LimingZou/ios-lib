//
//  TKIMDatabaseUpgrader.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@class TKIMDatabase;

@interface TKIMDatabaseUpgrader : NSObject
+ (instancetype)upgrader:(TKIMDatabase *)database
               tablename:(NSString *)tablename;

- (void)addColumn:(NSString *)name
             type:(NSString *)type;
@end
