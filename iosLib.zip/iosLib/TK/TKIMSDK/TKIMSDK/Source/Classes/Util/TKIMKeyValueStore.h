//
//  TKIMKeyValueStore.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@protocol TKIMKeyValueProtocol <NSObject>
- (NSString *)key;
- (NSString *)value;
@end

//内部使用的KeyValueItem,如果不先自己实现TKIMKeyValueProtocol协议,可以直接用这个类 (不推荐)
@interface TKIMKeyValueItem : NSObject<TKIMKeyValueProtocol>
@property (nonatomic,copy)      NSString    *key;
@property (nonatomic,copy)      NSString     *value;
@end

@interface TKIMKeyValueStore : NSObject

+ (instancetype)storeByPath:(NSString *)path;

- (void)storeObject:(id<TKIMKeyValueProtocol>)item;

- (void)removeObject:(id<TKIMKeyValueProtocol>)item;
- (void)removeObjectByID:(NSString *)key;

- (id<TKIMKeyValueProtocol>)objectByID:(NSString *)key;

- (NSArray *)allObjects;
- (void)removeAllObjects;

@end
