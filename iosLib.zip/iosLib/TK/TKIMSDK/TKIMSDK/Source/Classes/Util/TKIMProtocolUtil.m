//
//  TKIMProtocolUtil.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMProtocolUtil.h"
#import "TKIMMacros.h"
#import "NSDictionary+TKIMJson.h"
#import "NSObject+TKIM.h"

@implementation TKIMProtocolUtil

+ (NSArray <NSString *>*)arrayToStringList:(NSArray *)array
{
    NSMutableArray <NSString *>* strList = @[].mutableCopy;
    if ([array isKindOfClass:[NSArray class]])
    {
        for (id obj in array)
        {
            if ([obj isKindOfClass:[NSString class]])
            {
                [strList addObject:obj];
            }
        }
    }
    return strList;
}
+ (NSArray *)stringListToArray:(NSArray <NSString *>*)strList
{
    NSMutableArray *array = [NSMutableArray array];
    for (NSString *it in strList) {
        [array addObject:it];
    }
    return array;
}
+ (NSData *)jsonData:(NSDictionary *)dict
{
    NSData *data = nil;
    if([dict isKindOfClass:[NSDictionary class]])
    {
        NSError *error = nil;
        data = [NSJSONSerialization dataWithJSONObject:dict
                                               options:0
                                                 error:&error];
        if (error) {
            TKIMLogErr(@"jsonData failed %@ error %@",dict,error);
        }
    }
    return data;
}

+ (NSDictionary *)dictByJsonData:(NSData *)data
{
    NSDictionary *dict = nil;
    if ([data isKindOfClass:[NSData class]])
    {
        NSError *error = nil;
        dict = [NSJSONSerialization JSONObjectWithData:data
                                               options:0
                                                 error:&error];
        if (error) {
            TKIMLogErr(@"dictByJsonData failed %@ error %@",data,error);
        }
    }
    return [dict isKindOfClass:[NSDictionary class]] ? dict : nil;
}

+ (NSDictionary *)dictByJsonString:(NSString *)jsonString
{
    NSDictionary *dict = nil;
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    if (data && [data length])
    {
        NSError *error = nil;
        dict = [NSJSONSerialization JSONObjectWithData:data
                                               options:0
                                                 error:&error];
        if (error) {
            TKIMLogErr(@"dictByJsonString failed %@ error %@",jsonString,error);
        }
    }
    return [dict tkim_asObject:[NSDictionary class]];
}

+ (NSString *)stringByJsonDictionary:(NSDictionary *)dict
{
    NSString *result;
    if ([dict isKindOfClass:[NSDictionary class]])
    {
        NSError *error = nil;
        NSData *data = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:0
                                                         error:&error];
        if (error) {
            TKIMLogErr(@"stringByJsonDictionary failed %@ error %@",dict,error);
        }
        if (data)
        {
            NSString *jsonString = [[NSString alloc] initWithData:data
                                                         encoding:NSUTF8StringEncoding];
            result = jsonString;
        }
    }
    return result;

}
@end
