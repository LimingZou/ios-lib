//
//  TKIMDatabaseUpgrader.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMDatabaseUpgrader.h"
#import "TKIMDatabase.h"
#import "TKIMMacros.h"

@interface TKIMDatabaseUpgrader ()
@property (nonatomic,strong)    TKIMDatabase *db;
@property (nonatomic,copy)      NSString *tablename;
@property (nonatomic,strong)    NSMutableArray *columns;
@end

@implementation TKIMDatabaseUpgrader
+ (instancetype)upgrader:(TKIMDatabase *)database
               tablename:(NSString *)tablename
{
    TKIMDatabaseUpgrader *instance = [[TKIMDatabaseUpgrader alloc] init];
    instance.db = database;
    instance.tablename = tablename;
    [instance queryTableInfos];
    return instance;
}

- (void)queryTableInfos
{
    NSMutableArray *columns = [NSMutableArray array];
    NSString *sql = [NSString stringWithFormat:@"pragma table_info(%@)",_tablename];
    TKIMResultSet *rs = [_db executeQuery:sql];
    while ([rs next])
    {
        NSString *name = [rs stringForColumn:@"name"];
        if (name)
        {
            [columns addObject:name];
        }
    }
    [rs close];
    _columns = columns;
}

- (BOOL)columnExists:(NSString *)name
{
    for (NSString *column in _columns)
    {
        if ([name isEqualToString:column])
        {
            return YES;
        }
    }
    return NO;
}

- (void)addColumn:(NSString *)name
             type:(NSString *)type
{
    if (![self columnExists:name])
    {
        [self dbAddColumn:name
                     type:type];
    }
}

- (void)dbAddColumn:(NSString *)name
               type:(NSString *)type
{
    NSString *sql = [NSString stringWithFormat:@"alter table %@ add column %@ %@",_tablename,name,type];
    if ([_db executeUpdate:sql])
    {
        [_columns addObject:name];
    }
    else
    {
        TKIMLogApp(@"add column %@ for table %@ failed",name,_tablename);
    }
}

@end
