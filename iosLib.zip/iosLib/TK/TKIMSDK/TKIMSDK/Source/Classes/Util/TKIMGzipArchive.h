//
//  TKIMGzipArchive.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@interface TKIMGzipArchive : NSObject
+ (BOOL)gzipArchive:(NSString *)path
              files:(NSArray *)filepaths
            maxSize:(NSInteger)maxSize;
@end

