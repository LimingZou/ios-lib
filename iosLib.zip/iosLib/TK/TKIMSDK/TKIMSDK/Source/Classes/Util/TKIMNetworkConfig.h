//
//  TKIMNetworkConfig.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    TKIMNetworkTypeUnknown,
    TKIMNetworkType2G,
    TKIMNetworkType3G,
    TKIMNetworkType4G,
    TKIMNetworkTypeWWAN,
    TKIMNetworkTypeWifi,
} TKIMNetworkType;

@interface TKIMNetworkConfig : NSObject
+ (instancetype)sharedConfig;
- (TKIMNetworkType)currentNetworkType;
@end
