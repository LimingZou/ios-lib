//
//  TKIMProtocolUtil.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@interface TKIMProtocolUtil : NSObject
+ (NSArray <NSString *>*)arrayToStringList:(NSArray *)array;

+ (NSArray *)stringListToArray:(NSArray <NSString *>*)strList;

+ (NSData *)jsonData:(NSDictionary *)dict;

+ (NSDictionary *)dictByJsonData:(NSData *)data;
+ (NSDictionary *)dictByJsonString:(NSString *)jsonString;

+ (NSString *)stringByJsonDictionary:(NSDictionary *)dict;

@end
