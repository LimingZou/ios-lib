//
//  TKIMTimer.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>

@class TKIMTimer;

@protocol TKIMTimerDelegate <NSObject>
- (void)onTKIMTimerFired:(TKIMTimer *)timer;
@end

@interface TKIMTimer : NSObject
@property (nonatomic,weak)  id<TKIMTimerDelegate>  delegate;
- (BOOL)isScheduled;

- (void)startTimer:(NSTimeInterval)seconds
          delegate:(id<TKIMTimerDelegate>)delegate
           repeats:(BOOL)repeats;

- (void)stopTimer;
@end
