//
//  TKIMKeyValueStore.m
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import "TKIMKeyValueStore.h"
#import "TKIMDatabase.h"
#import "TKIMMacros.h"

static const void * const TKIMGetShareKeyValueQueueSpecificKey = &TKIMGetShareKeyValueQueueSpecificKey;
dispatch_queue_t TKIMGetShareKeyValueQueue()
{
    static dispatch_queue_t sharedQueue = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedQueue = dispatch_queue_create("com.xianyu.tkim.kv.queue", 0);
        dispatch_queue_set_specific(sharedQueue, TKIMGetShareKeyValueQueueSpecificKey, (void *)TKIMGetShareKeyValueQueueSpecificKey, NULL);
    });
    return sharedQueue;
}



@implementation TKIMKeyValueItem
@end

@interface TKIMKeyValueStore ()
@property (nonatomic,strong)    TKIMDatabase *db;
@end

@implementation TKIMKeyValueStore
+ (instancetype)storeByPath:(NSString *)path
{
    TKIMKeyValueStore *instance = [[TKIMKeyValueStore alloc] init];
    [instance createDB:path];
    return instance;
}

- (void)dealloc
{
    dispatch_block_t block = ^(){
        [self->_db close];
        self->_db = nil;
    };
    
    if (dispatch_get_specific(TKIMGetShareKeyValueQueueSpecificKey))
    {
        block();
    }
    else
    {
        dispatch_sync(TKIMGetShareKeyValueQueue(), block);
    }
}

- (void)storeObject:(id<TKIMKeyValueProtocol>)item
{
    dispatch_async(TKIMGetShareKeyValueQueue(), ^{
        NSString *key = [item key];
        NSString *value = [item value];
        if (key && value)
        {
            BOOL result = [self->_db executeUpdate:@"REPLACE INTO tkim_table (tkim_key,tkim_value) values (?,?)",key,value];
            if (!result)
            {
                TKIMLogErr(@"insert/update %@ failed %@",key,self->_db.lastError);
            }
        }
    });
}

- (void)removeObject:(id<TKIMKeyValueProtocol>)item
{
    return [self removeObjectByID:[item key]];
}

- (void)removeObjectByID:(NSString *)key
{
    if (key)
    {
        dispatch_async(TKIMGetShareKeyValueQueue(), ^{
            BOOL result = [self->_db executeUpdate:@"DELETE FROM tkim_table WHERE tkim_key = ?",key];
            if (!result)
            {
                TKIMLogErr(@"remove object %@ failed %@",key,self->_db.lastError);
            }
        });
    }
}

- (id<TKIMKeyValueProtocol>)objectByID:(NSString *)key
{
    __block TKIMKeyValueItem *item = nil;
    if(key)
    {
        dispatch_sync(TKIMGetShareKeyValueQueue(), ^{
            TKIMResultSet *rs = [_db executeQuery:@"SELECT * FROM tkim_table WHERE tkim_key = ?",key];
            if ([rs next])
            {
                item = [[TKIMKeyValueItem alloc]init];
                item.key = key;
                item.value = [rs stringForColumn:@"tkim_value"];
            }
            [rs close];
        });
    }
    return item;
}

- (NSArray *)allObjects
{
    __block NSMutableArray *objects = nil;
    dispatch_sync(TKIMGetShareKeyValueQueue(), ^{
        TKIMResultSet *rs = [_db executeQuery:@"SELECT * FROM tkim_table"];
        objects = [NSMutableArray array];
        while ([rs next])
        {
            TKIMKeyValueItem * item = [[TKIMKeyValueItem alloc]init];
            item.key = [rs stringForColumn:@"tkim_key"];
            item.value = [rs stringForColumn:@"tkim_value"];
            [objects addObject:item];
        }
        [rs close];
    });
    return objects;
}

- (void)removeAllObjects
{
    dispatch_async(TKIMGetShareKeyValueQueue(), ^{
        
        BOOL removed =  [self->_db executeUpdate:@"DELETE FROM tkim_table"];
        if (!removed)
        {
            TKIMLogErr(@"remove all objects failed %@",self->_db.lastError);
        }
    });
}

#pragma mark - misc
- (BOOL)createDB:(NSString *)filepath
{
    _db = [[TKIMDatabase alloc] initWithPath:filepath];
    BOOL result = [_db open];
    if (result)
    {
        NSString *sql = @"CREATE TABLE IF NOT EXISTS 'tkim_table' ('tkim_key' TEXT PRIMARY KEY,'tkim_value' TEXT)";
        result =  [_db executeUpdate:sql];
    }
    if (!result)
    {
        TKIMLogErr(@"create db failed %@ %@",filepath,_db.lastError);
    }
    return result;
}
@end

