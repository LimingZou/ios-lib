//
//  TKIMUserManagerWrapper.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <Foundation/Foundation.h>
#import "TKIMUserManagerProtocol.h"

@interface TKIMUserManagerWrapper : NSObject<TKIMUserManager>
+ (instancetype)sharedWrapper;
@end
