//
//  TKIMMacros.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#ifndef TKIMMacros_h
#define TKIMMacros_h

#ifdef __OBJC__
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "TKIMMacros.h"
#import "TKIMLogger.h"
#else
#ifndef TKIM_EXTERN
#if defined(__cplusplus)
#define TKIM_EXTERN extern "C"
#else
#define TKIM_EXTERN extern
#endif
#endif
#endif



#define TKIMNotification(x)          NSString *x = @#x
#define TKIMConfigTag(x)             NSString *x = @#x
#define UTF8(str)                   [(str) isKindOfClass:[NSString class]] ? ([(str) UTF8String] ? : "") : "" //NSString转std::string使用这个方法，避免用NULL去初始化std::string引起崩溃
#define NSUTF8(str)                 ((str).c_str() ? [NSString stringWithUTF8String:(str).c_str()] : @"")
#define TKIMAssert()                 NSAssert(NO,@"invalid code path"); TKIMLogErr(@"invalid code path");

#define TKIMTimeLongToDouble(x)      (((double)(x)) / 1000.0)
#define TKIMTimeDoubleToLong(x)      ((uint64_t)((x) * 1000))


#define TKIMLocalError(x)            [NSError errorWithDomain:TKIMLocalErrorDomain \
                                                        code:(x) \
                                                    userInfo:nil]

#define TKIMRemoteError(x)           (x) == 200 ? nil :  \
                                    [NSError errorWithDomain:TKIMRemoteErrorDomain \
                                                        code:(x) \
                                                    userInfo:nil]


#define TKIMIOS7            ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 7.0)



//使用这个而不在工程配置里面设置,避免一些错误写法导致的方法不存在且不被发现
#define TKIMSuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)


#define TKIMTry  @try
#define TKIMCatch @catch

#endif /* TKIMMacros_h */
