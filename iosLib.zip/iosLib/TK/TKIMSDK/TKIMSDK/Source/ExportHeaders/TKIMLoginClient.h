//
//  TKIMLoginClient.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#import <Foundation/Foundation.h>
/**
 *  登录的设备枚举
 */
typedef NS_ENUM(NSInteger, TKIMLoginClientType){
    /**
     *  Android
     */
    TKIMLoginClientTypeAOS         = 1,
    /**
     *  iOS
     */
    TKIMLoginClientTypeIOS         = 2,
    /**
     *  PC
     */
    TKIMLoginClientTypePC          = 4,
    /**
     *  WEB
     */
    TKIMLoginClientTypeWeb         = 16,
    /**
     *  REST API
     */
    TKIMLoginClientTypeRest        = 32,
};


/**
 *  登录客户端描述
 */
@interface TKIMLoginClient : NSObject
/**
 *  类型
 */
@property (nonatomic,assign,readonly)   TKIMLoginClientType      type;
/**
 *  操作系统
 */
@property (nonatomic,copy,readonly)     NSString                *os;
/**
 *  登录时间
 */
@property (nonatomic,assign,readonly)   NSTimeInterval          timestamp;

@end

/**
 *  自动登录参数
 */
@interface TKIMAutoLoginData : NSObject
/**
 *  账号
 */
@property (nonatomic,copy)      NSString    *account;

/**
 *  令牌(在后台绑定的登录token)
 */
@property (nonatomic,copy)      NSString    *token;

/**
 *  强制模式
 *  @discussion 默认为 NO.
 */
@property (nonatomic,assign)    BOOL        forcedMode;

@end


