//
//  TKIMSystemNotification.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/7.
//

#import <Foundation/Foundation.h>
#import "TKIMSession.h"
#import "TKIMUser.h"
#import "TKIMCustomSystemNotificationSetting.h"

/**
 *  系统通知类型
 */
typedef NS_ENUM(NSInteger, TKIMSystemNotificationType){
    /**
     *  申请入群
     */
    TKIMSystemNotificationTypeTeamApply              = 0,
    /**
     *  拒绝入群
     */
    TKIMSystemNotificationTypeTeamApplyReject        = 1,
    /**
     *  邀请入群
     */
    TKIMSystemNotificationTypeTeamInvite             = 2,
    /**
     *  拒绝入群邀请
     */
    TKIMSystemNotificationTypeTeamIviteReject        = 3,
    
    /**
     *  添加好友
     */
    TKIMSystemNotificationTypeFriendAdd              = 508,
    
};

#pragma mark - 系统通知
/**
 *  系统通知
 */
@interface TKIMSystemNotification : NSObject
/**
 *  通知类型
 */
@property (nonatomic,assign,readonly)       TKIMSystemNotificationType type;

/**
 *  时间戳
 */
@property (nonatomic,assign,readonly)       NSTimeInterval timestamp;
/**
 *  操作者
 */
@property (nonatomic,copy,readonly)         NSString *sourceID;
/**
 *  目标ID,群ID或者是用户ID
 */
@property (nonatomic,copy,readonly)         NSString *targetID;

/**
 *  附言
 */
@property (nonatomic,copy,readonly)         NSString *postscript;

/**
 *  是否已读
 *  @discussion 修改这个属性并不会修改db中的数据
 */
@property (nonatomic,assign)                BOOL read;

/**
 *  消息处理状态
 *  @discussion 修改这个属性,后台会自动更新db中对应的数据,SDK调用者可以使用这个值来持久化他们对消息的处理结果,默认为0
 */
@property (nonatomic,assign)                NSInteger handleStatus;


/**
 *  附件
 *  @discussion 额外信息,目前只有好友添加有额外信息,attachment为TKIMUserAddAttachment
 */
@property (nonatomic,strong,readonly)       id attachment;

@end


/**
 *  添加好友附件
 */
@interface TKIMUserAddAttachment : NSObject

/**
 *  好友操作类型
 */
@property (nonatomic,assign,readonly)   TKIMUserOperation    operationType;

@end


/**
 *  系统通知过滤器
 */
@interface TKIMSystemNotificationFilter : NSObject
/**
 *  类型列表,取值范围为: TKIMSystemNotificationType 枚举类型
 */
@property (nonatomic,strong)    NSArray     <NSNumber *>*notificationTypes;
@end


#pragma mark - 自定义系统通知
/**
 *  自定义系统消息
 */
@interface TKIMCustomSystemNotification : NSObject

/**
 *  时间戳
 */
@property (nonatomic,assign,readonly)       NSTimeInterval timestamp;

/**
 *  通知发起者id
 */
@property (nonatomic,copy,readonly)         NSString *sender;

/**
 *  通知接受者id
 */
@property (nonatomic,copy,readonly)         NSString *receiver;


/**
 *  通知接受者类型
 */
@property (nonatomic,assign,readonly)       TKIMSessionType  receiverType;

/**
 *  透传的消息体内容
 */
@property (nonatomic,copy,readonly)         NSString    *content;

/**
 *  是否只发送给在线用户
 *  @discussion 默认为YES 如果这个值为NO,通知接受者如果在通知投递时不在线,那么他会在下次登录时收到这个通知。如果消息接受者是群,则只允许投递到当前在线的用户
 */
@property (nonatomic,assign)                BOOL sendToOnlineUsersOnly;

/**
 *  apns推送文案
 *  @discussion 默认为nil,用户可以设置当前通知的推送文案
 */
@property (nonatomic,copy)                  NSString *apnsContent;


/**
 *  apns推送Payload
 *  @discussion 可以通过这个字段定义自定义通知的推送Payload,支持字段参考苹果技术文档,最多支持2K
 */
@property (nonatomic,copy)                  NSDictionary *apnsPayload;

/**
 *  自定义系统通知设置
 *  @discussion 可以通过这个字段制定当前通知的各种设置,如是否需要计入推送未读，是否需要带推送前缀等等
 */
@property (nonatomic,strong)                TKIMCustomSystemNotificationSetting *setting;


- (instancetype)initWithContent:(NSString *)content;

@end
