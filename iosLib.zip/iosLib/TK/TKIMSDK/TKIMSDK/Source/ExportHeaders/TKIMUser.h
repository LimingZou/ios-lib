//
//  TKIMUser.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/6.
//

#import <Foundation/Foundation.h>
@class TKIMUserInfo;

/**
 *  好友操作类型
 */
typedef NS_ENUM(NSInteger, TKIMUserOperation){
    /**
     *  添加好友
     *  @discussion 直接添加为好友,无需验证
     */
    TKIMUserOperationAdd     =   1,
    /**
     *  请求添加好友
     */
    TKIMUserOperationRequest =   2,
    /**
     *  通过添加好友请求
     */
    TKIMUserOperationVerify  =   3,
    /**
     *  拒绝添加好友请求
     */
    TKIMUserOperationReject  =   4,
};

/**
 *  用户性别
 */
typedef NS_ENUM(NSInteger, TKIMUserGender) {
    /**
     *  未知性别
     */
    TKIMUserGenderUnknown,
    /**
     *  性别男
     */
    TKIMUserGenderMale,
    /**
     *  性别女
     */
    TKIMUserGenderFemale,
};

typedef NS_ENUM(NSInteger, TKIMUserSearchRangeOption){
    /*
     * 在好友中查询
     */
    TKIMUserSearchRangeOptionFriends = 0,
    /*
     * 在所有人中查询
     */
    TKIMUserSearchRangeOptionAll,
};

typedef NS_OPTIONS(NSInteger, TKIMUserSearchContentOption){
    /*
     * 匹配UserId
     */
    TKIMUserSearchContentOptionUserId = 1 << 0,
    /*
     * 匹配备注名（只有好友支持备注名匹配）
     */
    TKIMUserSearchContentOptionAlias = 1 << 1,
    /*
     * 匹配昵称
     */
    TKIMUserSearchContentOptionNickName = 1 << 2,
    /*
     * 匹配全部
     */
    TKIMUserSearchContentOptionAll = TKIMUserSearchContentOptionUserId | TKIMUserSearchContentOptionAlias | TKIMUserSearchContentOptionNickName,
};


/**
 *  用户
 */
@interface TKIMUser : NSObject

/**
 *  用户Id
 */
@property (nonatomic,copy)   NSString    *userId;

/**
 *  备注名，长度限制为128个字符。
 */
@property (nonatomic,copy)   NSString    *alias;

/**
 *  扩展字段，上层需要保证NSDictionary可以转换为JSON,JSON长度限制为256个字符。
 */
@property (nonatomic,copy)   NSDictionary  *ext;

/**
 *  用户资料，仅当用户选择托管信息到时有效
 *  用户资料除自己之外，不保证其他用户资料实时更新
 *  其他用户资料更新的时机为: 1.调用 - (void)fetchUserInfos:completion: 方法刷新用户
 *                        2.收到此用户发来消息
 *                        3.程序再次启动，此时会同步好友信息
 */
@property (nonatomic,strong,readonly) TKIMUserInfo *userInfo;

/**
 *  是否需要消息提醒
 *
 *  @return 是否需要消息提醒
 */
- (BOOL)notifyForNewMsg;

/**
 *  是否在黑名单中
 *
 *  @return 是否在黑名单中
 */

- (BOOL)isInMyBlackList;

@end


/**
 *  用户资料，仅当用户选择托管信息到时有效
 */
@interface TKIMUserInfo : NSObject

/**
 *  用户昵称
 */
@property (nonatomic,copy,readonly) NSString *nickName;

/**
 *  用户头像
 */
@property (nonatomic,copy,readonly) NSString *avatarUrl;

/**
 *  用户头像缩略图，仅适用于使用上传服务进行上传的资源。否则为和用户头像原图值一致。
 */
@property (nonatomic,copy,readonly) NSString *thumbAvatarUrl;

/**
 *  用户签名
 */
@property (nonatomic,copy,readonly) NSString *sign;

/**
 *  用户性别
 */
@property (nonatomic,assign,readonly) TKIMUserGender gender;

/**
 *  邮箱
 */
@property (nonatomic,copy,readonly) NSString *email;

/**
 *  生日
 */
@property (nonatomic,copy,readonly) NSString *birth;

/**
 *  电话号码
 */
@property (nonatomic,copy,readonly) NSString *mobile;

/**
 *  用户自定义扩展字段
 */
@property (nonatomic,copy,readonly) NSString *ex;


@end

/**
 *  好友请求
 */
@interface TKIMUserRequest : NSObject
/**
 *  目标用户ID
 */
@property (nonatomic,copy)      NSString            *userId;

/**
 *  操作类型
 */
@property (nonatomic,assign)    TKIMUserOperation    operation;

/**
 *  附言
 *  @dicussion
 */
@property (nonatomic,copy)      NSString            *message;

@end


@interface TKIMUserSearchOption : NSObject

/**
*  搜索文本的搜索范围。（默认：TKIMUserSearchRangeOptionAll）
*/
@property (nonatomic, assign) TKIMUserSearchRangeOption searchRange;

/**
*  搜索文本的匹配区域。（默认：TKIMUserSearchContentOptionAll）
*/
@property (nonatomic, assign) TKIMUserSearchContentOption searchContentOption;

/**
*  忽略大小写。（默认：YES）
*/
@property (nonatomic, assign) BOOL ignoreingCase;

/**
*  搜索文本。
*/
@property (nonatomic,copy) NSString *searchContent;

@end
