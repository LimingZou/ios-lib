//
//  TKIMSDKHeaders.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/3/31.
//

#ifndef TKIMSDKHeaders_h
#define TKIMSDKHeaders_h

/**
 *  全局枚举和结构体定义
 */
#import "TKIMGlobalDefs.h"


/**
 *  配置项
 */
#import "TKIMSDKConfig.h"

/**
 *  会话相关定义
 */
#import "TKIMSession.h"
#import "TKIMRecentSession.h"
#import "TKIMMessageSearchOption.h"

/**
 *  用户定义
 */
#import "TKIMUser.h"

/**
 *  群相关定义
 */
#import "TKIMTeam.h"
#import "TKIMTeamMember.h"

/**
 *  聊天室相关定义
 */
#import "TKIMChatroom.h"
#import "TKIMChatroomEnterRequest.h"
#import "TKIMMessageChatroomExtension.h"
#import "TKIMChatroomMember.h"
#import "TKIMChatroomMemberRequest.h"

/**
 *  消息定义
 */
#import "TKIMMessage.h"
#import "TKIMSystemNotification.h"

/**
 *  推送定义
 */
#import "TKIMPushNotificationSetting.h"

/**
 *  登录定义
 */
#import "TKIMLoginClient.h"

/**
 *  实时会话选项定义
 */
//#import "TKIMRTSOption.h"
//#import "TKIMRTSRecordingInfo.h"

/**
 *  音视频网络通话选项定义
 */
//#import "TKIMNetCallOption.h"


/**
 *  各个对外接口协议定义
 */
#import "TKIMLoginManagerProtocol.h"
#import "TKIMChatManagerProtocol.h"
#import "TKIMConversationManagerProtocol.h"
#import "TKIMMediaManagerProtocol.h"
#import "TKIMUserManagerProtocol.h"
#import "TKIMTeamManagerProtocol.h"
#import "TKIMSystemNotificationManagerProtocol.h"
#import "TKIMApnsManagerProtocol.h"
#import "TKIMResourceManagerProtocol.h"
#import "TKIMNetCallManagerProtocol.h"
#import "TKIMRTSManagerProtocol.h"
#import "TKIMChatroomManagerProtocol.h"

#endif /* TKIMSDKHeaders_h */
