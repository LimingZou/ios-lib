//
//  TKIMGlobalDefs.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/2.
//

#ifndef TKIMGlobalDefs_h
#define TKIMGlobalDefs_h

/**
 *  消息内容类型枚举
 */
typedef NS_ENUM(NSInteger, TKIMMessageType){
    /**
     *  文本类型消息
     */
    TKIMMessageTypeText          = 1,
    /**
     *  图片类型消息
     */
    TKIMMessageTypeImage         = 2,
    /**
     *  声音类型消息
     */
    TKIMMessageTypeAudio         = 3,
    /**
     *  位置类型消息
     */
    TKIMMessageTypeLocation      = 4,
    /**
     *  视频类型消息
     */
    TKIMMessageTypeVideo         = 6,
    /**
     *  名片类型消息
     */
    TKIMMessageTypeContact       = 8,
    /**
     *  文件类型消息
     */
    TKIMMessageTypeFile          = 9,
    /**
     *  提醒类型消息
     */
    TKIMMessageTypeTip           = 10,
    /**
     *  通知类型消息
     */
    TKIMMessageTypeNotification  = 14,
    /**
     *  自定义类型消息
     */
    TKIMMessageTypeCustom        = 100
};


/**
 *  网络通话类型
 */
typedef NS_ENUM(NSInteger, TKIMNetCallType){
    /**
     *  音频通话
     */
    TKIMNetCallTypeAudio = 1,
    /**
     *  视频通话
     */
    TKIMNetCallTypeVideo = 2,
};

/**
 *  网络通话视频质量
 */
typedef NS_ENUM(NSInteger, TKIMNetCallVideoQuality) {
    /**
     *  默认视频质量
     */
    TKIMNetCallVideoQualityDefault = 0,
    /**
     *  低视频质量
     */
    TKIMNetCallVideoQualityLow     = 1,
    /**
     *  中等视频质量
     */
    TKIMNetCallVideoQualityMedium  = 2,
    /**
     *  高视频质量
     */
    TKIMNetCallVideoQualityHigh    = 3,
};



/**
 *  TKIM本地Error Domain
 */
extern NSString *const TKIMLocalErrorDomain;

/**
 *  TKIM服务器Error Domain
 */
extern NSString *const TKIMRemoteErrorDomain;



/**
 *  本地错误码
 */
typedef NS_ENUM(NSInteger, TKIMLocalErrorCode) {
    /**
     *  错误的参数
     */
    TKIMLocalErrorCodeInvalidParam                 = 1,
    /**
     *  多媒体文件异常
     */
    TKIMLocalErrorCodeInvalidMedia                 = 2,
    /**
     *  图片异常
     */
    TKIMLocalErrorCodeInvalidPicture               = 3,
    /**
     *  url异常
     */
    TKIMLocalErrorCodeInvalidUrl                   = 4,
    /**
     *  读取/写入文件失败
     */
    TKIMLocalErrorCodeIOError                      = 5,
    /**
     *  无效的token
     */
    TKIMLocalErrorCodeInvalidToken                 = 6,
    /**
     *  Http请求失败
     */
    TKIMLocalErrorCodeHttpReqeustFailed            = 7,
    /**
     *  无录音权限
     */
    TKIMLocalErrorCodeAudioRecordErrorNoPermission = 8,
    /**
     *  录音初始化失败
     */
    TKIMLocalErrorCodeAudioRecordErrorInitFailed   = 9,
    /**
     *  录音失败
     */
    TKIMLocalErrorCodeAudioRecordErrorRecordFailed   = 10,
    /**
     *  播放初始化失败
     */
    TKIMLocalErrorCodeAudioPlayErrorInitFailed     = 11,
    /**
     *  有正在进行的网络通话
     */
    TKIMLocalErrorCodeNetCallBusy                  = 12,
    /**
     *  这一通网络通话已经被其他端处理过了
     */
    TKIMLocalErrorCodeNetCallOtherHandled          = 13,
    /**
     *  SQL语句执行失败
     */
    TKIMLocalErrorCodeSQLFailed                    = 14,
    /**
     *  音频设备初始化失败
     */
    TKIMLocalErrorCodeAudioDeviceInitFailed        = 15,
    
    /**
     *  用户信息缺失 (未登录 或 未提供用户资料)
     */
    TKIMLocalErrorCodeUserInfoNeeded               = 16,
    
    /**
     *  无法开始录制, 因为文件路径不合法
     */
    TKIMLocalErrorCodeRecordInvalidFilePath       = 17,
    /**
     *  开始本地录制失败
     */
    TKIMLocalErrorCodeRecordStartFailed           = 18,

    /**
     *  创建录制文件失败
     */
    TKIMLocalErrorCodeRecordCreateFileFailed      = 19,
    
    /**
     *  初始化录制音频失败
     */
    TKIMLocalErrorCodeRecordInitAudioFailed       = 20,
    
    /**
     *  初始化录制视频失败
     */
    TKIMLocalErrorCodeRecordInitVideoFailed       = 21,
    
    /**
     *  开始写录制文件失败
     */
    TKIMLocalErrorCodeRecordStartWritingFailed    = 22,
    
    /**
     *  结束本地录制失败
     */
    TKIMLocalErrorCodeRecordStopFailed            = 23,
    
    /**
     *  写录制文件失败
     */
    TKIMLocalErrorCodeRecordWritingFileFailed     = 24,
    
    /**
     *  空间不足，录制即将结束
     */
    TKIMLocalErrorCodeRecordWillStopForLackSpace  = 25,
    
    /**
     *  聊天室不存在
     */
    TKIMLocalErrorChatroomNotExists               = 26,
    
    /**
     *  操作尚未完成
     */
    TKIMLocalErrorCodeOperationIncomplete         = 27,
    /**
     *  AppKey 缺失，未注册 AppKey 就进行登录行为之类的接口
     */
    TKIMLocalErrorCodeAppKeyNeed                  = 28,
    /**
     *  无效的Appkey
     */
    TKIMLocalErrorCodeInvalidAppKey               = 29

    
};




/**
 *  服务器错误码
 *  @discussion 更多错误详见 http://dev.netease.im/docs/index.php?index=6&title=%E5%85%A8%E5%B1%80%E8%BF%94%E5%9B%9E%E7%A0%81%E8%AF%B4%E6%98%8E
 */
typedef NS_ENUM(NSInteger, TKIMRemoteErrorCode) {
    /**
     *  客户端版本错误
     */
    TKIMRemoteErrorCodeInvalidVersion      = 201,
    /**
     *  密码错误
     */
    TKIMRemoteErrorCodeInvalidPass         = 302,
    /**
     *  CheckSum校验失败
     */
    TKIMRemoteErrorCodeInvalidCRC          = 402,
    /**
     *  非法操作或没有权限
     */
    TKIMRemoteErrorCodeForbidden           = 403,
    /**
     *  请求的目标（用户或对象）不存在
     */
    TKIMRemoteErrorCodeNotExist            = 404,
    /**
     *  对象只读
     */
    TKIMRemoteErrorCodeReadOnly            = 406,
    /**
     *  请求过程超时
     */
    TKIMRemoteErrorCodeTimeoutError        = 408,
    /**
     *  参数错误
     */
    TKIMRemoteErrorCodeParameterError      = 414,
    /**
     *  网络连接出现错误
     */
    TKIMRemoteErrorCodeConnectionError     = 415,
    /**
     *  操作太过频繁
     */
    TKIMRemoteErrorCodeFrequently          = 416,
    /**
     *  对象已经存在
     */
    TKIMRemoteErrorCodeExist               = 417,
    /**
     *  未知错误
     */
    TKIMRemoteErrorCodeUnknownError        = 500,
    /**
     *  服务器数据错误
     */
    TKIMRemoteErrorCodeServerDataError     = 501,
    /**
     *  不足
     */
    TKIMRemoteErrorCodeNotEnough           = 507,
    /**
     *  超过期限
     */
    TKIMRemoteErrorCodeDomainExpireOld     = 508,
    /**
     *  无效协议
     */
    TKIMRemoteErrorCodeInvalidProtocol      = 509,
    /**
     *  用户不存在
     */
    TKIMRemoteErrorCodeUserNotExist        = 510,
    /**
     *  服务不可用
     */
    TKIMRemoteErrorCodeServiceUnavailable  = 514,
    /**
     *  没有操作群的权限
     */
    TKIMRemoteErrorCodeTeamAccessError     = 802,
    /**
     *  群组不存在
     */
    TKIMRemoteErrorCodeTeamNotExists       = 803,
    /**
     *  用户不在兴趣组内
     */
    TKIMRemoteErrorCodeNotInTeam           = 804,
    /**
     *  群类型错误
     */
    TKIMRemoteErrorCodeTeamInvaildType     = 805,
    /**
     *  超出群成员个数限制
     */
    TKIMRemoteErrorCodeTeamMemberLimit     = 806,
    /**
     *  已经在群里
     */
    TKIMRemoteErrorCodeTeamAlreadyIn       = 809,
    /**
     *   不是群成员
     */
    TKIMRemoteErrorCodeTeamNotMember       = 810,
    /**
     *  在群黑名单中
     */
    TKIMRemoteErrorCodeTeamBlackList       = 812,
    /**
     *  解包错误
     */
    TKIMRemoteErrorCodeEUnpacket           = 998,
    /**
     *  打包错误
     */
    TKIMRemoteErrorCodeEPacket             = 999,
    
    /**
     *  被叫离线(无可送达的被叫方)
     */
    TKIMRemoteErrorCodeCalleeOffline       = 11001,
};




#endif /* TKIMGlobalDefs_h */
