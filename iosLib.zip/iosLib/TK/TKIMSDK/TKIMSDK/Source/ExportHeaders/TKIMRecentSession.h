//
//  TKIMRecentSession.h
//  TKIMSDKModule
//
//  Created by tretalk-888 on 2021/4/2.
//

#import <Foundation/Foundation.h>
@class TKIMMessage;
@class TKIMSession;

/**
 *  最近会话
 */

@interface TKIMRecentSession : NSObject

/**
 *  当前会话
 */
@property (nonatomic,readonly,strong)   TKIMSession  *session;

/**
 *  最后一条消息
 */
@property (nonatomic,readonly,strong)   TKIMMessage  *lastMessage;

/**
 *  未读消息数
 */
@property (nonatomic,readonly,assign)   NSInteger   unreadCount;

@end
