//
//  TKDUser.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDEntity.h"

@interface TKDUser : TKDEntity

@end
