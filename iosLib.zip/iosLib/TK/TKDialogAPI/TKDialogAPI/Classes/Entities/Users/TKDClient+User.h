//
//  TKDClient+User.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDClient.h"

@interface TKDClient (User)

/// Fetches the full information of the current `user`.
- (RACSignal *)fetchUserInfo;

/// Fetches the full information for the specified `user`.
- (RACSignal *)fetchUserInfoForUser:(TKDUser *)user;

@end
