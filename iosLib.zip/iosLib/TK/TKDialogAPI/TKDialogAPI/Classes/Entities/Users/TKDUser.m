//
//  TKDUser.m
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDUser.h"

@implementation TKDUser

@end
