//
//  TKDObject+Private.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDObject.h"

@interface TKDObject ()

// The URL of the API endpoint from which the receiver came. This should only be
// set at the time of initialization, and is responsible for filling in the
// `server` property.
@property (nonatomic, strong) NSURL *baseURL;

@end
