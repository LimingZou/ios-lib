//
//  TKDObject.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import <Mantle/Mantle.h>

@class TKDServer;
// The base model class for any objects retrieved through the Dialog API.
@interface TKDObject : MTLModel<MTLJSONSerializing>

// The unique ID for this object. This is only guaranteed to be unique among
// objects of the same type, from the same server.
@property (nonatomic, copy, readonly) NSString *objectID;

// The server this object is associated with.
//
// This object is not encoded into JSON.
@property (nonatomic, strong, readonly) TKDServer *server;

@end
