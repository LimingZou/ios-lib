//
//  TKDResponse.m
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDResponse.h"
#import <ReactiveObjC/RACEXTKeyPathCoding.h>

@interface TKDResponse ()

@property (nonatomic, copy, readonly) NSHTTPURLResponse *HTTPURLResponse;

@end
@implementation TKDResponse

#pragma mark Properties

- (NSString *)etag {
    return self.HTTPURLResponse.allHeaderFields[@"ETag"];
}

- (NSInteger)statusCode {
    return self.HTTPURLResponse.statusCode;
}

- (NSInteger)maximumRequestsPerHour {
    return [self.HTTPURLResponse.allHeaderFields[@"X-RateLimit-Limit"] integerValue];
}

- (NSInteger)remainingRequests {
    return [self.HTTPURLResponse.allHeaderFields[@"X-RateLimit-Remaining"] integerValue];
}

- (NSNumber *)pollInterval {
    NSString *intervalString = self.HTTPURLResponse.allHeaderFields[@"X-Poll-Interval"];
    return (intervalString.length > 0 ? @(intervalString.doubleValue) : nil);
}

#pragma mark Lifecycle

- (id)initWithHTTPURLResponse:(NSHTTPURLResponse *)response parsedResult:(id)parsedResult {
    return [super initWithDictionary:@{
        @keypath(self.parsedResult): parsedResult ?: NSNull.null,
        @keypath(self.HTTPURLResponse): [response copy] ?: NSNull.null,
    } error:NULL];
}

#pragma mark NSCopying

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

#pragma mark NSObject

- (NSUInteger)hash {
    return self.HTTPURLResponse.hash;
}
@end
