//
//  TKDServer+Private.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDServer.h"

// The full URL String for the github.com homepage
extern NSString * const TKDServerDotComBaseWebURL;

// The full URL String for the github.com API
extern NSString * const TKDServerDotComAPIEndpoint;

// The path to the API for an Enterprise instance
// (relative to the baseURL).
extern NSString * const TKDServerEnterpriseAPIEndpointPathComponent;
