//
//  TKDServer.m
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDServer.h"
#import "TKDServer+Private.h"

NSString * const TKDServerDotComAPIEndpoint = @"https://api.github.com";
NSString * const TKDServerDotComBaseWebURL = @"https://github.com";
NSString * const TKDServerEnterpriseAPIEndpointPathComponent = @"api/v3";

// Enterprise defaults to HTTP, and not all instances have HTTPS set up.
NSString * const TKDServerDefaultEnterpriseScheme = @"http";

// Expose Enterprise HTTPS scheme for clients.
NSString * const TKDServerHTTPSEnterpriseScheme = @"https";

@interface TKDServer ()

@property (nonatomic, copy, readwrite) NSURL *baseURL;

@end

@implementation TKDServer

#pragma mark Properties

- (NSURL *)APIEndpoint {
    if (self.baseURL == nil) {
        // This environment variable can be used to debug API requests by
        // redirecting them to a different URL.
        NSString *endpoint = NSProcessInfo.processInfo.environment[@"API_ENDPOINT"];
        if (endpoint != nil) return [NSURL URLWithString:endpoint];

        return [NSURL URLWithString:TKDServerDotComAPIEndpoint];
    } else {
        return [self.baseURL URLByAppendingPathComponent:TKDServerEnterpriseAPIEndpointPathComponent isDirectory:YES];
    }
}

- (NSURL *)baseWebURL {
    if (self.baseURL == nil) {
        return [NSURL URLWithString:TKDServerDotComBaseWebURL];
    } else {
        return self.baseURL;
    }
}

- (BOOL)isEnterprise {
    return self.baseURL != nil;
}

#pragma mark Lifecycle

+ (instancetype)dotComServer {
    static TKDServer *dotComServer = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dotComServer = [[self alloc] initWithBaseURL:nil];
    });
    return dotComServer;
}

+ (instancetype)serverWithBaseURL:(NSURL *)baseURL {
    if (baseURL == nil) return self.dotComServer;

    return [[TKDServer alloc] initWithBaseURL:baseURL];
}

- (instancetype)initWithBaseURL:(NSURL *)baseURL {
    self = [super init];
    if (self == nil) return nil;

    _baseURL = baseURL;

    return self;
}

#pragma mark Migration

+ (NSDictionary *)dictionaryValueFromArchivedExternalRepresentation:(NSDictionary *)externalRepresentation version:(NSUInteger)fromVersion {
    NSMutableDictionary *dictionaryValue = [[super dictionaryValueFromArchivedExternalRepresentation:externalRepresentation version:fromVersion] mutableCopy];

    NSString *baseURLString = externalRepresentation[@"baseURL"];
    if (baseURLString != nil) dictionaryValue[@"baseURL"] = [NSURL URLWithString:baseURLString] ?: NSNull.null;

    return dictionaryValue;
}



@end
