//
//  TKDClient.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/23.
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>

#if __IPHONE_OS_VERSION_MIN_REQUIRED
    #import <MobileCoreServices/MobileCoreServices.h>
#else
    #import <CoreServices/CoreServices.h>
#endif

#import <AFNetworking/AFNetworking.h>

@class TKDServer;
@class TKDUser;
@class RACSignal;

// The domain for all errors originating in TKDClient.
extern NSString * const TKDClientErrorDomain;

// A request was made to an endpoint that requires authentication, and the user
// is not logged in.
extern const NSInteger TKDClientErrorAuthenticationFailed;

// The request was invalid (HTTP error 400).
extern const NSInteger TKDClientErrorBadRequest;

// There was a problem connecting to the server.
extern const NSInteger TKDClientErrorConnectionFailed;

// JSON parsing failed, or a model object could not be created from the parsed
// JSON.
extern const NSInteger TKDClientErrorJSONParsingFailed;

@interface TKDClient : AFHTTPSessionManager

// The active user for this session.
@property (nonatomic, strong, readonly) TKDUser *user;

// Whether this client supports authenticated endpoints.
@property (nonatomic, getter = isAuthenticated, readonly) BOOL authenticated;

// The OAuth access token that the client was initialized with.
@property (nonatomic, copy, readonly) NSString *token;

// Sets the HTTP User-Agent for the current app. This will have no effect on any
// clients that have already been created.
+ (void)setUserAgent:(NSString *)userAgent;

// Creates a client which can access any endpoints that don't require
// authentication
+ (instancetype)unauthenticatedClientWithUser:(TKDUser *)user;

// Creates a client which will authenticate as the given user, using the given
// OAuth token.
+ (instancetype)authenticatedClientWithUser:(TKDUser *)user token:(NSString *)token;

// Initializes the receiver to make requests to the given Dialog server.
- (id)initWithServer:(TKDServer *)server;

@end

@interface TKDClient (Requests)

// Creates a mutable URL request, which when sent will conditionally fetch the
// latest data from the server. If the latest data matches `etag`, nothing is
// downloaded and the call does not count toward the API rate limit.
- (NSMutableURLRequest *)requestWithMethod:(NSString *)method path:(NSString *)path parameters:(NSDictionary *)parameters notMatchingEtag:(NSString *)etag;

// Enqueues a request to be sent to the server.
- (RACSignal *)enqueueRequest:(NSURLRequest *)request resultClass:(Class)resultClass;

@end
