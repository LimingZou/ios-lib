//
//  TKDClient+Private.h
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/30.
//

#import "TKDClient.h"

// The version of the Dialog API to use.
extern NSString * const TKDClientAPIVersion;

@interface TKDClient ()

// An error indicating that a request required a valid user, but no `user`
// property was set.
+ (NSError *)userRequiredError;

// An error indicating that a request required authentication, but the client
// was not created with a token.
+ (NSError *)authenticationRequiredError;

// An error indicating that the current server version does not support our
// request.
+ (NSError *)unsupportedVersionError;

// Enqueues a request to fetch information about the current user by accessing
// a path relative to the user object.
//
// method       - The HTTP method to use.
// relativePath - The path to fetch, relative to the user object. For example,
//                to request `user/orgs` or `users/:user/orgs`, simply pass in
//                `/orgs`. This may not be nil, and must either start with a '/'
//                or be an empty string.
// parameters   - HTTP parameters to encode and send with the request.
// resultClass  - The class that response data should be returned as.
//
// Returns a signal which will send an instance of `resultClass` for each parsed
// JSON object, then complete. If no `user` is set on the receiver, the signal
// will error immediately.
- (RACSignal *)enqueueUserRequestWithMethod:(NSString *)method relativePath:(NSString *)relativePath parameters:(NSDictionary *)parameters resultClass:(Class)resultClass;

// Enqueues a request that will not automatically parse results.
//
// request       - The previously constructed URL request for the endpoint.
// fetchAllPages - Whether to fetch all pages of the given endpoint.
//
// Returns a signal which will send tuples for each page, containing the
// `NSHTTPURLResponse` and response object (the type of which will be determined
// by AFNetworking), then complete. If an error occurs at any point, the
// returned signal will send it immediately, then terminate.
- (RACSignal *)enqueueRequest:(NSURLRequest *)request fetchAllPages:(BOOL)fetchAllPages;

// Enqueues a request to be sent to the server.
//
// request       - The previously constructed URL request for the endpoint.
// resultClass   - A subclass of OCTObject that the response data should be
//                 returned as. If this is nil, NSDictionary will be used for
//                 each object in the JSON received.
// fetchAllPages - Whether to fetch all pages of the given endpoint.
//
// Returns a signal which will send an instance of `OCTResponse` for each parsed
// JSON object, then complete. If an error occurs at any point, the returned
// signal will send it immediately, then terminate.
- (RACSignal *)enqueueRequest:(NSURLRequest *)request resultClass:(Class)resultClass fetchAllPages:(BOOL)fetchAllPages;

@end
