//
//  TKDClient.m
//  TKDialogAPIModule
//
//  Created by tretalk-888 on 2021/3/23.
//

#import "TKDClient.h"
#import "TKDClient+Private.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import <ReactiveObjC/RACEXTScope.h>

NSString * const TKDClientErrorDomain = @"TKDClientErrorDomain";

const NSInteger TKDClientErrorAuthenticationFailed = 666;
const NSInteger TKDClientErrorBadRequest = 670;
const NSInteger TKDClientErrorConnectionFailed = 668;
const NSInteger TKDClientErrorJSONParsingFailed = 669;

@interface TKDClient ()
@property (nonatomic, strong, readwrite) TKDUser *user;
@property (nonatomic, copy, readwrite) NSString *token;

// Returns any user agent previously given to +setUserAgent:.
+ (NSString *)userAgent;

// Returns any OAuth client ID previously given to +setClientID:clientSecret:.
+ (NSString *)clientID;

// Returns any OAuth client secret previously given to
// +setClientID:clientSecret:.
+ (NSString *)clientSecret;

// A subject to send callback URLs to after they're received by the app.
+ (RACSubject *)callbackURLs;

// Creates a request.
- (NSMutableURLRequest *)requestWithMethod:(NSString *)method path:(NSString *)path parameters:(NSDictionary *)parameters notMatchingEtag:(NSString *)etag;

@end

@implementation TKDClient

#pragma mark Properties

- (BOOL)isAuthenticated {
    return self.token != nil;
}

- (void)setToken:(NSString *)token {
    _token = [token copy];
}


- (RACSignal *)enqueueRequest:(NSURLRequest *)request resultClass:(Class)resultClass{
    return [RACSignal empty];
}

@end
