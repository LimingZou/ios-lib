# TKDialogAPI

[![CI Status](https://img.shields.io/travis/LimingZou/TKDialogAPI.svg?style=flat)](https://travis-ci.org/LimingZou/TKDialogAPI)
[![Version](https://img.shields.io/cocoapods/v/TKDialogAPI.svg?style=flat)](https://cocoapods.org/pods/TKDialogAPI)
[![License](https://img.shields.io/cocoapods/l/TKDialogAPI.svg?style=flat)](https://cocoapods.org/pods/TKDialogAPI)
[![Platform](https://img.shields.io/cocoapods/p/TKDialogAPI.svg?style=flat)](https://cocoapods.org/pods/TKDialogAPI)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKDialogAPI is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKDialogAPI'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKDialogAPI is available under the MIT license. See the LICENSE file for more info.
