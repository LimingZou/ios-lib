# TKBasic

[![CI Status](https://img.shields.io/travis/LimingZou/TKBasic.svg?style=flat)](https://travis-ci.org/LimingZou/TKBasic)
[![Version](https://img.shields.io/cocoapods/v/TKBasic.svg?style=flat)](https://cocoapods.org/pods/TKBasic)
[![License](https://img.shields.io/cocoapods/l/TKBasic.svg?style=flat)](https://cocoapods.org/pods/TKBasic)
[![Platform](https://img.shields.io/cocoapods/p/TKBasic.svg?style=flat)](https://cocoapods.org/pods/TKBasic)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKBasic is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKBasic'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKBasic is available under the MIT license. See the LICENSE file for more info.
