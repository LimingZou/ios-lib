//
//  main.m
//  TKBasic
//
//  Created by LimingZou on 04/12/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

@import UIKit;
#import "TKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TKAppDelegate class]));
    }
}
