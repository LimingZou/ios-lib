# TKMe

[![CI Status](https://img.shields.io/travis/LimingZou/TKMe.svg?style=flat)](https://travis-ci.org/LimingZou/TKMe)
[![Version](https://img.shields.io/cocoapods/v/TKMe.svg?style=flat)](https://cocoapods.org/pods/TKMe)
[![License](https://img.shields.io/cocoapods/l/TKMe.svg?style=flat)](https://cocoapods.org/pods/TKMe)
[![Platform](https://img.shields.io/cocoapods/p/TKMe.svg?style=flat)](https://cocoapods.org/pods/TKMe)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKMe is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKMe'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKMe is available under the MIT license. See the LICENSE file for more info.
