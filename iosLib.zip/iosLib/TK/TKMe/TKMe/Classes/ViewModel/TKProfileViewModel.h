//
//  TKProfileViewModel.h
//  TKMe
//
//  Created by tretalk-888 on 2021/4/13.
//

#import <Foundation/Foundation.h>

#import <TKIMSDK_UIKit/TKIMKit.h>

@interface TKProfileViewModel : NSObject

@end
