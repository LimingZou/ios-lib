# TKIMSDK_UIKit

[![CI Status](https://img.shields.io/travis/LimingZou/TKIMSDK_UIKit.svg?style=flat)](https://travis-ci.org/LimingZou/TKIMSDK_UIKit)
[![Version](https://img.shields.io/cocoapods/v/TKIMSDK_UIKit.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK_UIKit)
[![License](https://img.shields.io/cocoapods/l/TKIMSDK_UIKit.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK_UIKit)
[![Platform](https://img.shields.io/cocoapods/p/TKIMSDK_UIKit.svg?style=flat)](https://cocoapods.org/pods/TKIMSDK_UIKit)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TKIMSDK_UIKit is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TKIMSDK_UIKit'
```

## Author

LimingZou, zlm@tretalk.cn

## License

TKIMSDK_UIKit is available under the MIT license. See the LICENSE file for more info.
