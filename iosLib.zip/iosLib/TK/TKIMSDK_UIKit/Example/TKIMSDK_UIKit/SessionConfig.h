//
//  SessionConfig.h
//  DemoApplication
//
//  Created by chris on 15/11/1.
//  Copyright © 2015年 chris. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TKIMKit.h"

@interface SessionConfig : NSObject<TKIMSessionConfig>

@end
