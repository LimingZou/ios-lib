//
//  ContactViewController.h
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/23.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactViewController : UITableViewController
@property (nonatomic, strong) NSMutableArray *contact;
@end
