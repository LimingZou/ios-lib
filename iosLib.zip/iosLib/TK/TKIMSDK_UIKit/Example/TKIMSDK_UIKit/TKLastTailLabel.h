//
//  TKLastTailLabel.h
//  TKIMSDK_UIKit_Example
//
//  Created by ios on 2021/4/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKLastTailLabel : UILabel

@property (nonatomic, assign, readonly) CGFloat lastLineTailIndent;

- (CGFloat)setText:(NSString *)text lastLineTailIndent:(CGFloat)lastLineTailIndent;

@end

NS_ASSUME_NONNULL_END
