//
//  TKLastTailLabel.m
//  TKIMSDK_UIKit_Example
//
//  Created by ios on 2021/4/29.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "TKLastTailLabel.h"

@interface TKLastTailLabel ()

@property (nonatomic, assign) CGFloat lastLineTailIndent;

@end

@implementation TKLastTailLabel

- (CGFloat)setText:(NSString *)text lastLineTailIndent:(CGFloat)lastLineTailIndent
{
    self.lastLineTailIndent = lastLineTailIndent;
    self.numberOfLines = 0;
    
    if (lastLineTailIndent <= 0) {
        self.text = text;
        CGSize size = [self sizeThatFits:CGSizeMake(self.frame.size.width, MAXFLOAT)];
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, size.height);
        return size.height;
    }
    NSMutableParagraphStyle *paraStyle = [NSMutableParagraphStyle new];
    paraStyle.lineBreakMode = NSLineBreakByWordWrapping;
    paraStyle.lineSpacing = 7;

    // 占位符
    NSTextAttachment *attchImage = [[NSTextAttachment alloc] init];
    attchImage.image =  [self zm_imageWithColor:[UIColor clearColor] imageSize:CGSizeMake(lastLineTailIndent, 50)];
    NSAttributedString *blankImageAttrStr = [NSAttributedString attributedStringWithAttachment:attchImage];
    
    
    NSString *message = text;
    NSDictionary *attrs = @{
            NSFontAttributeName : [UIFont systemFontOfSize:14],
            NSForegroundColorAttributeName : [UIColor redColor],
            NSParagraphStyleAttributeName : paraStyle,
            NSAttachmentAttributeName: attchImage,
    };
    
    NSMutableAttributedString *attrText = [[NSMutableAttributedString alloc] initWithString:message attributes:attrs];
    [attrText appendAttributedString:blankImageAttrStr];
    self.attributedText = attrText;
    CGSize size = [self sizeThatFits:CGSizeMake(self.frame.size.width, MAXFLOAT)];
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, size.height);
    return size.height;
}

#pragma mark - Private Methods
- (UIImage *)zm_imageWithColor:(UIColor *)color imageSize:(CGSize)imageSize {
    if (color == nil) {
        return nil;
    }
    CGRect rect = CGRectMake(0.0f, 0.0f, imageSize.width, imageSize.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);

    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

@end
