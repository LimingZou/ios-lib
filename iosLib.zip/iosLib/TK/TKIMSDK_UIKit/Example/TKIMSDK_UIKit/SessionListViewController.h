//
//  SessionListViewController.h
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/23.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <TKIMKit.h>

@interface SessionListViewController : TKIMSessionListViewController

@end
