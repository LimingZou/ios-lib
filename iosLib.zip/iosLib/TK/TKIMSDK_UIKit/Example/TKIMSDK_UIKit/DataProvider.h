//
//  DataProvider.h
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/15.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TKIMKit.h>

@interface DataProvider : NSObject<TKIMKitDataProvider>

@end
