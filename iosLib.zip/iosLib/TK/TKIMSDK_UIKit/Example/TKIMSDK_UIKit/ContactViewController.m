//
//  ContactViewController.m
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/23.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "ContactViewController.h"
#import "SessionViewController.h"

@interface ContactViewController ()

@end

@implementation ContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addSession)];
    self.navigationItem.rightBarButtonItem = item;
}

- (void)addSession {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"添加对方用户id" preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) weakself = self;
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
    }];
    
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *envirnmentNameTextField = alert.textFields.firstObject;
        if (![[[TKIMSDK sharedSDK] loginManager].currentAccount isEqualToString:envirnmentNameTextField.text] && envirnmentNameTextField.text.length > 0) {
            [weakself.contact addObject:envirnmentNameTextField.text];
            [weakself.tableView reloadData];
            TKIMUserRequest *userRequest = [[TKIMUserRequest alloc] init];
            userRequest.userId = envirnmentNameTextField.text;
            [[TKIMSDK sharedSDK].userManager requestFriend:userRequest completion:^(NSError *error) {
                            
            }];
        }
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:sureAction];
    [alert addAction:cancelAction];
    [self.navigationController presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.contact.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSString *title = [self.contact objectAtIndex:indexPath.row];
    cell.textLabel.text = title;
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    NSString *sessionId = [self.contact objectAtIndex:indexPath.row];
    TKIMSession *session = [TKIMSession session:sessionId type:TKIMSessionTypeP2P];
    SessionViewController *vc = [[SessionViewController alloc] initWithSession:session];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
