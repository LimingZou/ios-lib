//
//  SessionListViewController.m
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/23.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "SessionListViewController.h"
#import "SessionViewController.h"
#import "ContactViewController.h"
#import <TKIMSessionListCell.h>
#import <TKIMGlobalMacro.h>
#import <TKIMSDK/TKIMSDK.h>

@interface SessionListViewController ()

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) NSMutableArray *contact;
@end

@implementation SessionListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"聊天";
    
    self.tableView.backgroundColor = UIColor.whiteColor;
    
    self.contact = [NSMutableArray array];
    for (TKIMRecentSession *session in self.recentSessions) {
        [self.contact addObject:session.session.sessionId];
    }
}

- (void)onSelectedRecent:(TKIMRecentSession *)recent
             atIndexPath:(NSIndexPath *)indexPath
{
    SessionViewController *vc = [[SessionViewController alloc] initWithSession:recent.session];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)addSession
{
    ContactViewController *vc = [[ContactViewController alloc] initWithNibName:nil bundle:nil];
    vc.contact = self.contact;
    [self.navigationController pushViewController:vc animated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TKIMSessionListCell *cell = (TKIMSessionListCell *)[super tableView:tableView cellForRowAtIndexPath:indexPath];
    
    cell.lineView.hidden = NO;
    if (indexPath.row == self.recentSessions.count - 1) {
        cell.lineView.hidden = YES;
    }
    
    return cell;
}

@end
