//
//  CellLayoutConfig.m
//  DemoApplication
//
//  Created by chris on 15/11/1.
//  Copyright © 2015年 chris. All rights reserved.
//

#import "CellLayoutConfig.h"

@implementation CellLayoutConfig

- (CGSize)contentSize:(TKIMMessageModel *)model cellWidth:(CGFloat)width{
    if ([self canLayout:model]) {
        return CGSizeMake(200, 50);
    }
    return [super contentSize:model cellWidth:width];
}

- (NSString *)cellContent:(TKIMMessageModel *)model{
    if ([self canLayout:model]) {
        //填入自定义的气泡contentView
        return @"ContentView";
    }
    return [super cellContent:model];
}

- (UIEdgeInsets)cellInsets:(TKIMMessageModel *)model{
    if ([self canLayout:model]) {
        //填入气泡距cell的边距,选填
        return UIEdgeInsetsMake(5, 5, 5, 5);
    }
    return [super cellInsets:model];
    
}


- (UIEdgeInsets)contentViewInsets:(TKIMMessageModel *)model{
    if ([self canLayout:model]) {
        //填入内容距气泡的边距,选填
        return UIEdgeInsetsMake(5, 5, 5, 5);
    }
    return [super contentViewInsets:model];
    
}

- (BOOL)shouldShowAvatar:(TKIMMessageModel *)model {
    return model.message.session.sessionType == TKIMSessionTypeTeam;
}

- (BOOL)canLayout:(TKIMMessageModel *)model
{
    return model.message.messageType == TKIMMessageTypeCustom;
}


- (BOOL)shouldShowNickName:(TKIMMessageModel *)model {
    if (model.message.messageType == TKIMMessageTypeImage) {
        return NO;
    }
    return ![model.message.from isEqualToString:[TKIMSDK sharedSDK].loginManager.currentAccount];
}

- (BOOL)shouldShowForward:(TKIMMessageModel *)model {
    return NO;
}
@end
