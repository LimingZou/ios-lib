//
//  DataProvider.m
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/15.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "DataProvider.h"

@implementation DataProvider

- (TKIMKitInfo *)infoByUser:(NSString *)userId
               withMessage:(TKIMMessage *)message{
    TKIMKitInfo *info = [[TKIMKitInfo alloc] init];
    info.avatarImage = [UIImage imageNamed:@"DefaultAvatar"];
    //注意只有将用户数据托管给云信才可以调用此方法，否则请自行维护用户昵称等数据
    TKIMUser *user = [[TKIMSDK sharedSDK].userManager userInfo:userId];
    info.showName = [NSString stringWithFormat:@"用户(%@)",user.userId];
    return info;
}

- (TKIMKitInfo *)infoByUser:(NSString *)userId
                  inSession:(TKIMSession *)session
{
    TKIMSessionType sessionType = session.sessionType;
    TKIMKitInfo *info;
    switch (sessionType) {
        case TKIMSessionTypeP2P:
        {
            info = [[TKIMKitInfo alloc] init];
            info.avatarImage = [UIImage imageNamed:@"DefaultAvatar"];
            //注意只有将用户数据托管给云信才可以调用此方法，否则请自行维护用户昵称等数据
            info.showName = [NSString stringWithFormat:@"用户(%@)",userId];
        }
            break;
        case TKIMSessionTypeTeam:
        {
            break;
        }
        default:
            NSAssert(0, @"invalid type");
            break;
    }
    return info;
}
@end

