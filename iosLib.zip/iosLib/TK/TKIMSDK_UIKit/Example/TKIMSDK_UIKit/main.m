//
//  main.m
//  TKIMSDK_UIKit
//
//  Created by LimingZou on 04/15/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

@import UIKit;
#import "TKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TKAppDelegate class]));
    }
}
