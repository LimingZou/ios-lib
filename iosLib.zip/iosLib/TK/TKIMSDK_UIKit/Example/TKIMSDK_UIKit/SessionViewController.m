//
//  SessionViewController.m
//  TKIMSDK_UIKit_Example
//
//  Created by tretalk-888 on 2021/4/15.
//  Copyright © 2021 LimingZou. All rights reserved.
//

#import "SessionViewController.h"
#import "SessionConfig.h"
#import "Attachment.h"
#import "TKIMMessageMaker.h"
#import "TKIMKitLocationPoint.h"
#import <TKIMUtil.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface SessionViewController ()<TKIMChatManagerDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate, TKIMMessageCellDelegate>

@property (nonatomic,strong) SessionConfig *config;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, assign) NSInteger index;

@property (nonatomic, assign) BOOL isStart;

@property (nonatomic) dispatch_semaphore_t semaphore;

@end



@implementation SessionViewController

- (instancetype)initWithSession:(TKIMSession *)session
{
    self = [super initWithSession:session];
    if (self) {
        _config = [[SessionConfig alloc] init];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[TKIMSDK sharedSDK].chatManager addDelegate:self];
//    [[TKOSSUploadManager sharedManager] initWithAccessKey:@"LTAI4FcbZk4NMcHifB2sddHC" secretKey:@"u3tBQ1ZCcYh0mkvf4OhWXIhBSEm3tr" publicBucket:@"tretalk-hk-ever" privateBucket:@"tretalk-hk" endPoint:@"https://oss-cn-hongkong.aliyuncs.com"];
    

}

- (NSString *)sessionTitle{
    return @"聊天";
}

- (id<TKIMSessionConfig>)sessionConfig{
    return self.config;
}

- (void)sendMessage:(TKIMMessage *)message didCompleteWithError:(NSError *)error {
    [super sendMessage:message didCompleteWithError:error];
    if (self.semaphore) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            dispatch_semaphore_signal(self.semaphore);
        });
    }
}

- (void)sendTextMessage {
    self.index += 1;
    TKIMMessage *message = [TKIMMessageMaker msgWithText:[NSString stringWithFormat:@"%ld", self.index]];
    [self sendMessage:message];
}

- (void)sendCustomMessage {
    // org.cocoapods.demo.TKIMSDK-UIKit-Example
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入发送条数" preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) weakself = self;
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
    }];
    
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *envirnmentNameTextField = alert.textFields.firstObject;
        int count = [envirnmentNameTextField.text intValue];
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            self.semaphore = dispatch_semaphore_create(0);
            for (int i = 0; i < count; i++) {
                TKIMMessage *message = [TKIMMessageMaker msgWithText:[NSString stringWithFormat:@"%d", i]];
                [weakself sendMessage:message];
                dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
            }
        });
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:sureAction];
    [alert addAction:cancelAction];
    [self.navigationController presentViewController:alert animated:YES completion:nil];
    
}

- (void)sendCustomMessageTimer {
    if (self.isStart) {
        self.index = 0;
        [self.timer invalidate];
        self.timer = nil;
    } else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入发送间隔(毫秒)" preferredStyle:UIAlertControllerStyleAlert];
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
        }];
        
        UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UITextField *envirnmentNameTextField = alert.textFields.firstObject;
            int count = [envirnmentNameTextField.text intValue];
            if (!self.timer) {
                self.timer = [NSTimer timerWithTimeInterval:count / 1000 target:self selector:@selector(sendTextMessage) userInfo:nil repeats:YES];
                [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
            }
        }];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:sureAction];
        [alert addAction:cancelAction];
        [self.navigationController presentViewController:alert animated:YES completion:nil];
    }
    self.isStart = !self.isStart;
}

- (void)tkim_tableView:(UITableView *)tableView willCellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSLog(@"touchend");
}

- (void)onDidSelectCellInRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"_--%ld", indexPath.row);
}

- (void)sendImageMessage {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.mediaTypes = @[(NSString *)kUTTypeImage,  (NSString *)kUTTypeMovie];
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (void)sendContactMessage {
    TKIMMessage *message = [TKIMMessageMaker msgWithContact:nil];
    [self sendMessage:message];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    NSString *mediaType = info[UIImagePickerControllerMediaType];
    if ([mediaType isEqualToString:(NSString *)kUTTypeImage]) { //选择图片
        NSData *imageData = [NSData dataWithContentsOfFile:info[@"UIImagePickerControllerImageURL"]];
        UIImage *image = [UIImage imageWithData:imageData scale:0.7];

        [self sendImageMessage:image];
        
    } else if ([mediaType isEqualToString:(NSString *)kUTTypeMovie]) {//选择封面
        NSURL* mediaUrl = [info objectForKey:UIImagePickerControllerMediaURL];

        [self sendVideoMessage:mediaUrl.path];
    } else {
        NSLog(@"暂不支持其他上传方式");
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    self.isStart = !self.isStart;
    [self.timer invalidate];
    self.timer = nil;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:[NSString stringWithFormat:@"内存警告:%ld条", self.index] preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:sureAction];
    [self.navigationController presentViewController:alert animated:YES completion:nil];
    self.index = 0;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.timer invalidate];
    self.timer = nil;
}

- (void)dealloc {
    [self.timer invalidate];
    self.timer = nil;
    
    NSLog(@"dealloc ---- %@", NSStringFromClass(self.class));
}
@end
