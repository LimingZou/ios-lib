//
//  SessionConfig.m
//  DemoApplication
//
//  Created by chris on 15/11/1.
//  Copyright © 2015年 chris. All rights reserved.
//

#import "SessionConfig.h"
#import "TKIMMediaItem.h"
#import "CellLayoutConfig.h"
#import "TKIMKitUIConfig.h"

@implementation SessionConfig

- (NSArray *)mediaItems{
    TKIMMediaItem *custom1 =
             [TKIMMediaItem item:@"sendCustomMessage"
                    normalImage:[UIImage imageNamed:@"icon_custom_normal"]
                  selectedImage:[UIImage imageNamed:@"icon_custom_pressed"]
                          title:@"批量发"];
    TKIMMediaItem *custom2 =
             [TKIMMediaItem item:@"sendCustomMessageTimer"
                    normalImage:[UIImage imageNamed:@"icon_custom_normal"]
                  selectedImage:[UIImage imageNamed:@"icon_custom_normal"]
                          title:@"定时发送"];
    
    TKIMMediaItem *custom3 =
             [TKIMMediaItem item:@"sendImageMessage"
                    normalImage:[UIImage imageNamed:@"icon_custom_normal"]
                  selectedImage:[UIImage imageNamed:@"icon_custom_normal"]
                          title:@"图片消息"];
    
    TKIMMediaItem *custom4 =
             [TKIMMediaItem item:@"sendContactMessage"
                    normalImage:[UIImage imageNamed:@"icon_custom_normal"]
                  selectedImage:[UIImage imageNamed:@"icon_custom_normal"]
                          title:@"名片信息"];
    NSMutableArray *array = [NSMutableArray arrayWithArray:[TKIMKitUIConfig sharedConfig].defaultMediaItems];
    [array addObjectsFromArray:@[custom1, custom2, custom3, custom4]];
    return array;
}

- (BOOL)disableCharlet
{
    return YES;
}


@end
