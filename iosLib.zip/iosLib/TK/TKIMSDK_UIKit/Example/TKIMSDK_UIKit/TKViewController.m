//
//  TKViewController.m
//  TKIMSDK_UIKit
//
//  Created by LimingZou on 04/15/2021.
//  Copyright (c) 2021 LimingZou. All rights reserved.
//

#import "TKViewController.h"
#import "TKIMKit.h"
#import "SessionListViewController.h"
#import "TKTZImagePickerController.h"
#import "TKIMSessionEditViewController.h"
#import "TKIMAlertModel.h"

#define TKIMMyAccount   @"admin001"
#define TKIMMyToken     @"e10adc3949ba59abbe56e057f20f883e"

@interface TKViewController ()<TKIMSessionEditViewControllerDelegate>
@property (nonatomic, strong) UITextField *fromTextField;
@end

@implementation TKViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"登录";
    self.fromTextField = [[UITextField alloc] initWithFrame:CGRectMake(20, 200, UIScreen.mainScreen.bounds.size.width - 40, 40)];
    self.fromTextField.layer.borderColor = UIColor.grayColor.CGColor;
    self.fromTextField.layer.borderWidth = 1;
    self.fromTextField.layer.cornerRadius = 5;
    self.fromTextField.keyboardType = UIKeyboardTypeNumberPad;
    [self.view addSubview:self.fromTextField];
    
    UIView *fromView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 40)];
    UILabel *fromLabel = [[UILabel alloc] initWithFrame:fromView.bounds];
    fromLabel.text = @"我的id";
    [fromView addSubview:fromLabel];
    self.fromTextField.leftViewMode = UITextFieldViewModeAlways;
    self.fromTextField.leftView = fromView;
}


- (IBAction)login:(id)sender{
    

    //请将 TKIMMyAccount 以及 TKIMMyToken 替换成您自己提交到此App下的账号和密码
    [self.view endEditing:YES];
    NSString *fromStr = self.fromTextField.text.length ? self.fromTextField.text : TKIMMyAccount;
    [[TKIMSDK sharedSDK].loginManager login:fromStr token:TKIMMyToken completion:^(NSError *error) {
        if (!error) {
            NSLog(@"登录成功");
            //创建会话列表页
            SessionListViewController *vc = [[SessionListViewController alloc] initWithNibName:nil bundle:nil];
            [self.navigationController pushViewController:vc animated:YES];
        }else{
            NSLog(@"登录失败");
        }
    }];
//    SessionListViewController *vc = [[SessionListViewController alloc] initWithNibName:nil bundle:nil];
//    [self.navigationController pushViewController:vc animated:YES];
}


@end
