//
//  TKIMKit.h
//  TKIMKit
//
//  Created by amao on 8/14/15.
//

#import <Foundation/Foundation.h>


//! Project version number for TKIMKit.
FOUNDATION_EXPORT double TKIMKitVersionNumber;

//! Project version string for TKIMKit.
FOUNDATION_EXPORT const unsigned char TKIMKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TKIMKit/PublicHeader.h>


#import <TKIMSDK/TKIMSDK.h>

/**
 *  基础Model
 */
#import "TKIMKitInfo.h"
#import "TKIMMediaItem.h"            //多媒体面板对象
#import "TKIMMessageModel.h"         //message Wrapper


/**
 *  协议
 */
#import "TKIMKitMessageProvider.h"
#import "TKIMCellConfig.h"           //message cell配置协议
#import "TKIMInputProtocol.h"        //输入框回调
#import "TKIMKitDataProvider.h"      //APP内容提供器
#import "TKIMMessageCellProtocol.h"  //message cell事件回调
#import "TKIMSessionConfig.h"        //会话页面配置
#import "TKIMKitEvent.h"             //点击事件封装类

#import "TKIMCellLayoutConfig.h"

/**
 *  消息cell的视觉模板
 */
#import "TKIMSessionMessageContentView.h"

/**
 *  UI 配置器
 */
#import "TKIMKitUIConfig.h"

/**
 *  会话页
 */
#import "TKIMSessionViewController.h"

/**
 *  会话列表页
 */
#import "TKIMSessionListViewController.h"


@interface TKIMKit : NSObject

+ (instancetype)sharedKit;

/**
 *  注册自定义的排版配置，通过注册自定义排版配置来实现自定义消息的定制化排版
 */
- (void)registerLayoutConfig:(Class)layoutConfigClass;

/**
 *  返回当前的排版配置
 */
- (id<TKIMCellLayoutConfig>)layoutConfig;

/**
 *  UI 配置器
 */
@property (nonatomic,strong) TKIMKitUIConfig *config;

/**
 *  内容提供者，由上层开发者注入。如果没有则使用默认 provider
 */
@property (nonatomic,strong)    id<TKIMKitDataProvider> provider;

/**
 *  TKIMKit图片资源所在的 bundle 名称。
 */
@property (nonatomic,copy)      NSString *resourceBundleName;

/**
 *  TKIMKit表情资源所在的 bundle 名称。
 */
@property (nonatomic,copy)      NSString *emoticonBundleName;

/**
 *  TKIMKit设置资源所在的 bundle 名称。
 */
@property (nonatomic,copy)      NSString *settingBundleName;


/**
 *  用户信息变更通知接口
 *
 *  @param userId 用户id
 */
- (void)notfiyUserInfoChanged:(NSArray *)userIds;

/**
 *  群信息变更通知接口
 *
 *  @param teamId 群id
 */
- (void)notifyTeamInfoChanged:(NSArray *)teamIds;


/**
 *  群成员变更通知接口
 *
 *  @param teamId 群id
 */
- (void)notifyTeamMemebersChanged:(NSArray *)teamIds;

/**
 *  返回用户信息
 */
- (TKIMKitInfo *)infoByUser:(NSString *)userId;


/**
 *  返回用户在会话中需要显示的信息
 */
- (TKIMKitInfo *)infoByUser:(NSString *)userId
                 inSession:(TKIMSession *)session;

/**
 *  返回用户在某条消息中需要显示的信息
 */
- (TKIMKitInfo *)infoByUser:(NSString *)userId
               withMessage:(TKIMMessage *)message;

/**
 *  返回群信息
 */
- (TKIMKitInfo *)infoByTeam:(NSString *)teamId;

/**
 *  @param message 被回复的消息
 *
 *  @return 格式化的内容
 */
- (NSString *)replyedContentWithMessage:(TKIMMessage *)message;
@end



