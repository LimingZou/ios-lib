//
//  TKIMKit.m
//  TKIMKit
//
//  Created by amao on 8/14/15.

//

#import "TKIMKit.h"
#import "TKIMKitTimerHolder.h"
#import "TKIMKitNotificationFirer.h"
#import "TKIMKitDataProviderImpl.h"
#import "TKIMCellLayoutConfig.h"
#import "TKIMKitUIConfig.h"

extern NSString *const TKIMKitUserInfoHasUpdatedNotification;
extern NSString *const TKIMKitTeamInfoHasUpdatedNotification;


@interface TKIMKit()
@property (nonatomic,strong)    TKIMKitNotificationFirer *firer;
@property (nonatomic,strong)    id<TKIMCellLayoutConfig> layoutConfig;
@end


@implementation TKIMKit
- (instancetype)init
{
    if (self = [super init]) {
        _resourceBundleName  = @"TKIMKitResource.bundle";
        _emoticonBundleName  = @"TKIMKitEmoticon.bundle";
        _settingBundleName   = @"TKIMKitSettings.bundle";
        _firer = [[TKIMKitNotificationFirer alloc] init];
        _provider = [[TKIMKitDataProviderImpl alloc] init];   //默认使用 TKIMKit 的实现

        _layoutConfig = [[TKIMCellLayoutConfig alloc] init];
    }
    return self;
}

+ (instancetype)sharedKit
{
    static TKIMKit *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKIMKit alloc] init];
    });
    return instance;
}

- (void)registerLayoutConfig:(Class)layoutConfigClass
{
    id instance = [[layoutConfigClass alloc] init];
    if ([instance isKindOfClass:[TKIMCellLayoutConfig class]])
    {
        self.layoutConfig = instance;
    }
    else
    {
        NSAssert(0, @"class should be subclass of TKIMLayoutConfig");
    }
}
- (TKIMKitUIConfig *)config{
    return [TKIMKitUIConfig sharedConfig];
}
- (id<TKIMCellLayoutConfig>)layoutConfig
{
    return _layoutConfig;
}

- (void)notfiyUserInfoChanged:(NSArray *)userIds{
    if (!userIds.count) {
        return;
    }
    for (NSString *userId in userIds) {
        TKIMSession *session = [TKIMSession session:userId type:TKIMSessionTypeP2P];
        TKIMKitFirerInfo *info = [[TKIMKitFirerInfo alloc] init];
        info.session = session;
        info.notificationName = TKIMKitUserInfoHasUpdatedNotification;
        [self.firer addFireInfo:info];
    }
}

- (void)notifyTeamInfoChanged:(NSArray *)teamIds{
    if (teamIds.count) {
        for (NSString *teamId in teamIds) {
            [self notifyTeam:teamId];
        }
    }else{
        [self notifyTeam:nil];
    }
}

- (void)notifyTeamMemebersChanged:(NSArray *)teamIds
{
    if (teamIds.count) {
        for (NSString *teamId in teamIds) {
            [self notifyTeamMemebers:teamId];
        }
    }else{
        [self notifyTeamMemebers:nil];
    }
}


- (void)notifyTeam:(NSString *)teamId
{
    TKIMKitFirerInfo *info = [[TKIMKitFirerInfo alloc] init];
    if (teamId.length) {
        TKIMSession *session = [TKIMSession session:teamId type:TKIMSessionTypeTeam];
        info.session = session;
    }
    info.notificationName = TKIMKitTeamInfoHasUpdatedNotification;
    [self.firer addFireInfo:info];
}

- (void)notifyTeamMemebers:(NSString *)teamId
{
    TKIMKitFirerInfo *info = [[TKIMKitFirerInfo alloc] init];
    if (teamId.length) {
        TKIMSession *session = [TKIMSession session:teamId type:TKIMSessionTypeTeam];
        info.session = session;
    }
    extern NSString *TKIMKitTeamMembersHasUpdatedNotification;
    info.notificationName = TKIMKitTeamMembersHasUpdatedNotification;
    [self.firer addFireInfo:info];
}

- (TKIMKitInfo *)infoByUser:(NSString *)userId
{
    return [self infoByUser:userId
                  inSession:nil];
}


- (TKIMKitInfo *)infoByUser:(NSString *)userId
                 inSession:(TKIMSession *)session
{
    TKIMKitInfo *info = nil;
    if (self.provider && [self.provider respondsToSelector:@selector(infoByUser:inSession:)]) {
        info = [self.provider infoByUser:userId inSession:session];
    }
    return info;
}

- (TKIMKitInfo *)infoByTeam:(NSString *)teamId
{
    TKIMKitInfo *info = nil;
    if (self.provider && [self.provider respondsToSelector:@selector(infoByTeam:)]) {
        info = [self.provider infoByTeam:teamId];
    }
    return info;

}

- (TKIMKitInfo *)infoByUser:(NSString *)userId
               withMessage:(TKIMMessage *)message
{
    NSAssert([userId isEqualToString:message.from], @"user id should be same with message from");
    
    TKIMKitInfo *info = nil;
    if (self.provider && [self.provider respondsToSelector:@selector(infoByUser:withMessage:)]) {
        info = [self.provider infoByUser:userId
                         withMessage:message];
    }
    return info;
}

- (NSString *)replyedContentWithMessage:(TKIMMessage *)message
{
    NSString *info = nil;

    if (!message)
    {
        return @"这是一条回复消息";
    }
    
    if (self.provider && [self.provider respondsToSelector:@selector(replyedContentWithMessage:)]) {
        info = [self.provider replyedContentWithMessage:message];
    }
    return info;
}
@end



