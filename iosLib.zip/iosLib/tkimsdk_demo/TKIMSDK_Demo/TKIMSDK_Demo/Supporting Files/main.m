//
//  main.m
//  TKIMSDK_Demo
//
//  Created by tretalk-888 on 2021/5/12.
//

#import <UIKit/UIKit.h>
#import "TKESAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TKESAppDelegate class]));
    }
}
