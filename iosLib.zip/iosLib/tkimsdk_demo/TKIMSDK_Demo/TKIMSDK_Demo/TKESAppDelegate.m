//
//  TKESAppDelegate.m
//  TKIMSDK_Demo
//
//  Created by tretalk-888 on 2021/5/12.
//

#import "TKESAppDelegate.h"
#import "TKESLoginViewController.h"
#import <TKIMSDK.h>
#import "UIView+Toast.h"
#import "TKESService.h"
#import "TKESNotificationCenter.h"
#import "TKESLogManager.h"
#import "TKESDemoConfig.h"
#import "TKESAppTokenManager.h"
#import "TKESSessionUtil.h"
#import "TKESMainTabController.h"
#import "TKESLoginManager.h"
#import "TKESCustomAttachmentDecoder.h"
#import "TKESClientUtil.h"
#import "TKESNotificationCenter.h"
#import "TKIMKit.h"
#import "TKESDataProvider.h"

NSString *TKESNotificationLogout = @"TKESNotificationLogout";

@interface TKESAppDelegate ()<TKIMLoginManagerDelegate>

@end

@implementation TKESAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    //配置 SDK 配置，需要在 SDK 启动之前进行配置 (如文件存储根目录等)
    //NSString *sdkPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    //[[TKIMSDKConfig sharedConfig] setupSDKDir:sdkPath];
    
    
    //appkey是应用的标识，不同应用之间的数据（用户、消息、群组等）是完全隔离的。
    NSString *appKey = [[TKESDemoConfig sharedConfig] appKey];
    NSString *cerName= [[TKESDemoConfig sharedConfig] cerName];
    
    [[TKIMSDK sharedSDK] registerWithAppID:appKey
                                  cerName:cerName];

    [TKIMCustomObject registerCustomDecoder:[TKESCustomAttachmentDecoder new]];
    
    [[TKIMKit sharedKit] setProvider:[TKESDataProvider new]];

    [self setupServices];
    [self registerAPNs];
    
    [self commonInitListenEvents];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor grayColor];
    [self.window makeKeyAndVisible];
    [application setStatusBarStyle:UIStatusBarStyleLightContent];

    [self setupMainViewController];
    
    return YES;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[[TKIMSDK sharedSDK] loginManager] removeDelegate:self];
}


#pragma mark - ApplicationDelegate
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSInteger count = [[[TKIMSDK sharedSDK] conversationManager] allUnreadCount];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:count];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    [[TKIMSDK sharedSDK] updateApnsToken:deviceToken];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    DDLogDebug(@"receive remote notification:  %@", userInfo);
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    DDLogDebug(@"fail to get apns token :%@",error);
}


#pragma mark - misc
- (void)registerAPNs
{
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerForRemoteNotifications)])
    {
        UIUserNotificationType types = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert;
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:types
                                                                                 categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else
    {
        UIRemoteNotificationType types = UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeBadge;
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:types];
    }
}

- (void)setupMainViewController
{
    LoginData *data = [[TKESLoginManager sdkManager] currentLoginData];
    NSString *account = [data account];
    NSString *token = [data token];
    
    //如果有缓存用户名密码推荐使用自动登录
    if ([account length] && [token length])
    {
        [[[TKIMSDK sharedSDK] loginManager] autoLogin:account
                                               token:token];
        [[TKESServiceManager sharedManager] start];
        TKESMainTabController *mainTab = [[TKESMainTabController alloc] initWithNibName:nil bundle:nil];
        self.window.rootViewController = mainTab;
    }
    else
    {
        [self setupLoginViewController];
    }
}

- (void)commonInitListenEvents
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(logout:)
                                                 name:TKESNotificationLogout
                                               object:nil];
    
    [[[TKIMSDK sharedSDK] loginManager] addDelegate:self];
}

- (void)setupLoginViewController
{
    TKESLoginViewController *loginController = [[TKESLoginViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginController];
    self.window.rootViewController = nav;
}


#pragma mark - 注销
-(void)logout:(NSNotification*)note
{
    [self doLogout];
}

- (void)doLogout
{
    [[TKESLoginManager sdkManager] setCurrentLoginData:nil];
    [[TKESLoginManager appManager] setCurrentLoginData:nil];
    [[TKESAppTokenManager sharedManager] cleanAppToken];
    [[TKESServiceManager sharedManager] destory];
    [self setupLoginViewController];
}


#pragma TKIMLoginManagerDelegate
-(void)onKick:(TKIMKickReason)code clientType:(TKIMLoginClientType)clientType
{
    NSString *reason = @"你被踢下线";
    switch (code) {
        case TKIMKickReasonByClient:
        case TKIMKickReasonByClientManually:{
            NSString *clientName = [TKESClientUtil clientName:clientType];
            reason = clientName.length ? [NSString stringWithFormat:@"你的帐号被%@端踢出下线，请注意帐号信息安全",clientName] : @"你的帐号被踢出下线，请注意帐号信息安全";
            break;
        }
        case TKIMKickReasonByServer:
            reason = @"你被服务器踢下线";
            break;
        default:
            break;
    }
    [[[TKIMSDK sharedSDK] loginManager] logout:^(NSError *error) {
        [[NSNotificationCenter defaultCenter] postNotificationName:TKESNotificationLogout object:nil];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"下线通知" message:reason delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
    }];
}

- (void)onAutoLoginFailed:(NSError *)error
{
    //添加密码出错等引起的自动登录错误处理
    if ([error code] == TKIMRemoteErrorCodeInvalidPass ||
        [error code] == TKIMRemoteErrorCodeExist)
    {
        [[[TKIMSDK sharedSDK] loginManager] logout:^(NSError *error) {
            [[NSNotificationCenter defaultCenter] postNotificationName:TKESNotificationLogout object:nil];
        }];
    }
}


#pragma mark - logic impl
- (void)setupServices
{
    [[TKESLogManager sharedManager] start];
    [[TKESNotificationCenter sharedCenter] start];
}


@end
