//
//  MainTabController.h
//  TKIMDemo
//
//  Created by chris on 15/2/2.


#import <UIKit/UIKit.h>
#import "TKIMKit.h"
@interface TKESMainTabController : UITabBarController

+ (instancetype)instance;

@end
