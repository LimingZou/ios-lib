//
//  TKESAppDelegate.h
//  TKIMSDK_Demo
//
//  Created by tretalk-888 on 2021/5/12.
//

#import <UIKit/UIKit.h>

@interface TKESAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

