//
//  UIResponder+TKESFirstResponder.h
//  TKIM
//
//  Created by chris on 15/9/26.


#import <UIKit/UIKit.h>

@interface UIResponder (TKESFirstResponder)

+ (instancetype)currentFirstResponder;

@end
