//
//  NSString+TKES.h
//  TKIMDemo
//
//  Created by chris on 15/2/12.


#import <UIKit/UIKit.h>

@interface NSString (TKES)

- (CGSize)stringSizeWithFont:(UIFont *)font;

- (NSString *)MD5String;

- (NSUInteger)getBytesLength;

- (NSString *)stringByDeletingPictureResolution;

- (NSString *)tokenByPassword;
@end
