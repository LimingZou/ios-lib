//
//  UIAlertView+TKESBlock.h
//  eim_iphone
//
//  Created by amao on 12-11-7.


#import <UIKit/UIKit.h>
typedef void (^AlertBlock)(NSInteger);

@interface UIAlertView (TKESBlock)
- (void)showAlertWithCompletionHandler: (AlertBlock)block;
- (void)clearActionBlock;
@end
