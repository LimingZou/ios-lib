//
//  NSData+TKES.h
//  TKIM
//
//  Created by amao on 7/2/15.


#import <Foundation/Foundation.h>

@interface NSData (TKES)
- (NSString *)MD5String;
@end
