//
//  UIImage+Color.h
//  yixin_iphone
//
//  Created by Xuhui on 14-3-17.


#import <UIKit/UIKit.h>

@interface UIImage (TKESColor)

+ (UIImage *)clearColorImage;

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
