//
//  UIActionSheet+TKESBlock.h
//  eim_iphone
//
//  Created by amao on 12-11-23.


#import <UIKit/UIKit.h>
typedef void (^ActionSheetBlock)(NSInteger);

@interface UIActionSheet (TKESBlock)<UIActionSheetDelegate>
- (void)showInView: (UIView *)view completionHandler: (ActionSheetBlock)block;
- (void)clearActionBlock;
@end
