//
//  UIImage+TKES.h
//  TKIM
//
//  Created by chris on 15/7/13.


#import <UIKit/UIKit.h>

@interface UIImage (TKES)

+ (UIImage *)fetchImage:(NSString *)imageNameOrPath;

+ (UIImage *)fetchChartlet:(NSString *)imageName chartletId:(NSString *)chartletId;

- (UIImage *)imageForAvatarUpload;

@end
