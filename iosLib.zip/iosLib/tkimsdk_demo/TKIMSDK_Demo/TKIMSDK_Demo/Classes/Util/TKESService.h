//
//  TKIMService.h
//  TKIM
//
//  Created by amao on 11/13/13.

#import <Foundation/Foundation.h>

@protocol TKESService <NSObject>
@optional
- (void)onCleanData;
- (void)onReceiveMemoryWarning;
- (void)onEnterBackground;
- (void)onEnterForeground;
- (void)onAppWillTerminate;
@end

@interface TKESService : NSObject<TKESService>
+ (instancetype)sharedInstance;

//空方法，只是输出log而已
//大部分的TKIMService懒加载即可，但是有些因为业务需要在登录后就需要立马生成
- (void)start;
@end

@interface TKESServiceManager: NSObject

+ (instancetype)sharedManager;

- (void)start;
- (void)destory;

@end
