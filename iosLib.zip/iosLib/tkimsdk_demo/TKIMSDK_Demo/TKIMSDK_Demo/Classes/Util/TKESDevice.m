//
//  TKESDevice.m
//  TKIM
//
//  Created by chris on 15/9/18.


#import "TKESDevice.h"
#import "Reachability.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <sys/sysctl.h>
#import <sys/utsname.h>

#define NormalImageSize       (1280 * 960)


@interface TKESDevice ()

@property (nonatomic,strong)    NSDictionary    *networkTypes;

@end

@implementation TKESDevice

- (instancetype)init
{
    if (self = [super init])
    {
        [self buildDeviceInfo];
    }
    return self;
}


+ (TKESDevice *)currentDevice{
    static TKESDevice *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKESDevice alloc] init];
    });
    return instance;
}

- (void)buildDeviceInfo
{
    _networkTypes = @{
                          CTRadioAccessTechnologyGPRS:@(TKESNetworkType2G),
                          CTRadioAccessTechnologyEdge:@(TKESNetworkType2G),
                          CTRadioAccessTechnologyWCDMA:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyHSDPA:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyHSUPA:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyCDMA1x:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyCDMAEVDORev0:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyCDMAEVDORevA:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyCDMAEVDORevB:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyeHRPD:@(TKESNetworkType3G),
                          CTRadioAccessTechnologyLTE:@(TKESNetworkType4G),
                     };
}


//图片/音频推荐参数
- (CGFloat)suggestImagePixels{
    return NormalImageSize;
}

- (CGFloat)compressQuality{
    return 0.5;
}


//App状态
- (BOOL)isUsingWifi{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus status =  [reachability currentReachabilityStatus];
    return status == ReachableViaWiFi;
}

- (BOOL)isInBackground{
    return [[UIApplication sharedApplication] applicationState] != UIApplicationStateActive;
}

- (TKESNetworkType)currentNetworkType{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus status =  [reachability currentReachabilityStatus];
    switch (status) {
        case ReachableViaWiFi:
            return TKESNetworkTypeWifi;
        case ReachableViaWWAN:
        {
            CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
            NSNumber *number = [_networkTypes objectForKey:telephonyInfo.currentRadioAccessTechnology];
            return number ? (TKESNetworkType)[number integerValue] :TKESNetworkTypeWwan;
        }
        default:
            return TKESNetworkTypeUnknown;
    }
}

- (NSInteger)cpuCount{
    size_t size = sizeof(int);
    int results;
    
    int mib[2] = {CTL_HW, HW_NCPU};
    sysctl(mib, 2, &results, &size, NULL, 0);
    return (NSUInteger) results;
}

- (BOOL)isLowDevice{
#if TARGET_IPHONE_SIMULATOR
    return NO;
#else
    return [[NSProcessInfo processInfo] processorCount] <= 1;
#endif
}

- (BOOL)isIphone{
    NSString *deviceModel = [UIDevice currentDevice].model;
    if ([deviceModel isEqualToString:@"iPhone"]) {
        return YES;
    }else {
        return NO;
    }
}

- (NSString *)machineName{
    struct utsname systemInfo;
    uname(&systemInfo);
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}



@end
