//
//  TKESDemoConfig.m
//  TKIM
//
//  Created by amao on 4/21/15.


#import "TKESDemoConfig.h"

@interface TKESDemoConfig ()
@property (nonatomic,copy)  NSString    *appKey;
@property (nonatomic,copy)  NSString    *apiURL;
@property (nonatomic,copy)  NSString    *cerName;
@end

@implementation TKESDemoConfig
+ (instancetype)sharedConfig
{
    static TKESDemoConfig *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKESDemoConfig alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if (self = [super init])
    {
        _appKey = @"f6cac64bd51b4898a7ca42be6a6304d4";
        _apiURL = @"http://192.168.3.9:8081";
        _cerName= @"ENTERPRISE";
    }
    return self;
}

- (NSString *)appKey
{
    return _appKey;
}

- (NSString *)apiURL
{
    return _apiURL;
}

- (NSString *)cerName
{
    return _cerName;
}


@end
