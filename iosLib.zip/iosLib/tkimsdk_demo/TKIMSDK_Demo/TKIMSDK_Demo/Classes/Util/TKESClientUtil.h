//
//  TKESClientUtil.h
//  TKIM
//
//  Created by chris on 15/7/27.


#import <Foundation/Foundation.h>

@interface TKESClientUtil : NSObject

+ (NSString *)clientName:(TKIMLoginClientType)clientType;

@end
