//
//  TKESUserDataProvider.m
//  TKIM
//
//  Created by amao on 8/13/15.


#import "TKESDataProvider.h"

@implementation TKESDataProvider
- (TKIMKitInfo *)infoByUser:(NSString *)userId withMessage:(TKIMMessage *)message
{
    TKIMKitInfo *info = [[TKIMKitInfo alloc] init];
    info.avatarImage = [UIImage imageNamed:@"DefaultAvatar"];
    //注意只有将用户数据托管给云信才可以调用此方法，否则请自行维护用户昵称等数据
    TKIMUser *user = [[TKIMSDK sharedSDK].userManager userInfo:userId];
    info.showName = [NSString stringWithFormat:@"用户(%@)",user.userId];
    return info;
}

- (TKIMKitInfo *)infoByUser:(NSString *)userId inSession:(TKIMSession *)session
{
    TKIMUser *user = [[TKIMSDK sharedSDK].userManager userInfo:userId];
    if (user) {
        //如果本地有数据则直接返回
        TKIMKitInfo *info = [[TKIMKitInfo alloc] init];
        info.infoId      = userId;
        info.showName    = user.userInfo.nickName.length && ![user.userInfo.nickName isEqualToString:@"null"] ? [NSString stringWithFormat:@"%@(%@)",user.userInfo.nickName, userId] : userId;
        info.avatarImage = [UIImage imageNamed:@"DefaultAvatar"];
        info.avatarUrlString = user.userInfo.thumbAvatarUrl;
        return info;
    }else{
        //如果本地没有数据则去自己的应用服务器请求数据
        [[TKIMSDK sharedSDK].userManager fetchUserInfos:@[userId] completion:^(NSArray *users, NSError *error) {
            if (!error) {
                [[TKIMKit sharedKit] notfiyUserInfoChanged:@[userId]];
            }
        }];
        //先返回一个默认数据,以供网络请求没回来的时候界面可以有东西展示
        TKIMKitInfo *info = [[TKIMKitInfo alloc] init];
        info.showName    = userId; //本地没有昵称，拿userId代替
        info.avatarImage = [UIImage imageNamed:@"DefaultAvatar"]; //默认占位头像
        return info;
    }
}

- (TKIMKitInfo *)infoByTeam:(NSString *)teamId{
    TKIMTeam *team    = [[TKIMSDK sharedSDK].teamManager teamById:teamId];
    TKIMKitInfo *info = [[TKIMKitInfo alloc] init];
    info.showName    = team.teamName;
    info.infoId      = teamId;
    info.avatarImage = [UIImage imageNamed:@"avatar_team"];
    return info;
}



@end
