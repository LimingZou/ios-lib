//
//  TKESNotificationCenter.h
//  TKIM
//
//  Created by Xuhui on 15/3/25.


#import "TKESService.h"
@class TKESCustomNotificationDB;


@interface TKESNotificationCenter : NSObject

+ (instancetype)sharedCenter;
- (void)start;

@end
