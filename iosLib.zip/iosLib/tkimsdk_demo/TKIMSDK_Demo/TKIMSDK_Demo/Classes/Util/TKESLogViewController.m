//
//  TKESLogViewController.m
//  TKIM
//
//  Created by Xuhui on 15/4/1.


#import "TKESLogViewController.h"
#import "TKESLogManager.h"

@interface TKESLogViewController ()<NSLayoutManagerDelegate>
@property (strong, nonatomic) IBOutlet UITextView *logTextView;
@property (copy,nonatomic) NSString *path;
@end

@implementation TKESLogViewController


- (instancetype)initWithFilepath:(NSString *)path
{
    if (self = [self initWithNibName:@"TKESLogViewController" bundle:nil])
    {
        self.path = path;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"退出" style:UIBarButtonItemStyleDone target:self action:@selector(onDismiss:)];
    NSData *data = [NSData dataWithContentsOfFile:_path];
    NSString *content = [[NSString alloc] initWithData:data
                                              encoding:NSUTF8StringEncoding];
    if (content == nil)
    {
        content = [[NSString alloc] initWithData:data
                                        encoding:NSASCIIStringEncoding];
    }
    _logTextView.text = content;
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [_logTextView scrollRangeToVisible:NSMakeRange([_logTextView.text length], 0)];
    [_logTextView setScrollEnabled:NO];
    [_logTextView setScrollEnabled:YES];
}


- (void)onDismiss:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
