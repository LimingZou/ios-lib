//
//  TKESCADisplayLinkHolder.h
//  TKIM
//
//  Created by Netease on 15/8/27.


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class TKESCADisplayLinkHolder;

@protocol TKESCADisplayLinkHolderDelegate <NSObject>

- (void)onDisplayLinkFire:(TKESCADisplayLinkHolder *)holder
                 duration:(NSTimeInterval)duration
              displayLink:(CADisplayLink *)displayLink;

@end


@interface TKESCADisplayLinkHolder : NSObject

@property (nonatomic,weak  ) id<TKESCADisplayLinkHolderDelegate> delegate;
@property (nonatomic,assign) NSInteger frameInterval;

- (void)startCADisplayLinkWithDelegate: (id<TKESCADisplayLinkHolderDelegate>)delegate;

- (void)stop;

@end
