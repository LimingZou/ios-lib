//
//  TKESLogManager.m
//  TKIM
//
//  Created by Xuhui on 15/4/1.


#import "TKESLogManager.h"
#import "TKESLogViewController.h"
#import <TKIMSDK.h>
#import "TKESBundleSetting.h"

@interface TKESLogManager () {
    DDFileLogger *_fileLogger;
}

@end

@implementation TKESLogManager

+ (instancetype)sharedManager
{
    static TKESLogManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKESLogManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if(self) {
        [DDLog addLogger:[DDASLLogger sharedInstance]];
        [DDLog addLogger:[DDTTYLogger sharedInstance]];
        [[DDTTYLogger sharedInstance] setColorsEnabled:YES];
        _fileLogger = [[DDFileLogger alloc] init];
        _fileLogger.rollingFrequency = 60 * 60 * 24; // 24 hour rolling
        _fileLogger.logFileManager.maximumNumberOfLogFiles = 7;
        [DDLog addLogger:_fileLogger];
    }
    return self;
}

- (void)start
{
    DDLogInfo(@"App Started SDK Version %@\nBundle Setting: %@",[[TKIMSDK sharedSDK] sdkVersion],[TKESBundleSetting sharedConfig]);
}

- (UIViewController *)demoLogViewController {
    NSString *filepath = _fileLogger.currentLogFileInfo.filePath;TKESLogViewController *vc = [[TKESLogViewController alloc] initWithFilepath:filepath];
    vc.title = @"Demo Log";
    return vc;
}

- (UIViewController *)sdkLogViewController
{
    NSString *filepath = [[TKIMSDK sharedSDK] currentLogFilepath];TKESLogViewController *vc = [[TKESLogViewController alloc] initWithFilepath:filepath];
    vc.title = @"SDK Log";
    return vc;
}

@end
