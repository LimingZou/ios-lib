//
//  TKESHttpRequest.h
//  TKIM
//
//  Created by amao on 2/10/14.
//  Copyright (c) 2014 Netease.

#import <Foundation/Foundation.h>

enum TKESHttpRequestCode
{
    kTKIMHttpRequestCodeInvalidToken  = -501,     //token失效
    kTKIMHttpRequestCodeDecryptError  = -502,     //解密出错
    
    kTKIMHttpRequestCodeSuccess       = 200,      //请求成功
    kTKIMHttpRequestCodeFailed        = 404,      //请求失败
    
    kTKIMHttpRequestCodeTimeout       = 2000,     //请求超时
};

typedef void(^TKESCompleteBlock)(NSInteger responseCode, NSDictionary *responseData);


@interface TKESHttpRequest : NSObject
@property (nonatomic,strong)    NSData      *responseData;  //已解密的Response
@property (nonatomic,assign)    NSInteger   responseCode;   //Http返回Code

+ (TKESHttpRequest *)requestWithURL: (NSURL *)url;
- (void)setPostDict: (NSDictionary *)dict;
- (void)setPostJsonData: (NSData *)data;

- (void)startAsyncWithComplete:(TKESCompleteBlock)result; //返回已解密后的data
@end
