//
//  TKESUserUtil.h
//  TKIM
//
//  Created by chris on 15/9/17.


#import <Foundation/Foundation.h>

@interface TKESUserUtil : NSObject

+ (BOOL)isMyFriend:(NSString *)userId;

+ (NSString *)genderString:(TKIMUserGender)gender;

@end
