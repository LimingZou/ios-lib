//
//  TKESDevice.h
//  TKIM
//
//  Created by chris on 15/9/18.


#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger,TKESNetworkType) {TKESNetworkTypeUnknown,TKESNetworkTypeWifi,TKESNetworkTypeWwan,TKESNetworkType2G,TKESNetworkType3G,TKESNetworkType4G,
};

@interface TKESDevice : NSObject

+ (TKESDevice *)currentDevice;

//图片/音频推荐参数
- (CGFloat)suggestImagePixels;

- (CGFloat)compressQuality;

//App状态
- (BOOL)isUsingWifi;
- (BOOL)isInBackground;

- (TKESNetworkType)currentNetworkType;

- (NSInteger)cpuCount;

- (BOOL)isLowDevice;
- (BOOL)isIphone;
- (NSString *)machineName;

@end
