//
//  TKESLogManager.h
//  TKIM
//
//  Created by Xuhui on 15/4/1.



@interface TKESLogManager : NSObject

+ (instancetype)sharedManager;

- (void)start;

- (UIViewController *)demoLogViewController;

- (UIViewController *)sdkLogViewController;
@end
