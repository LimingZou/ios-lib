//
//  TKESLogViewController.h
//  TKIM
//
//  Created by Xuhui on 15/4/1.


#import <UIKit/UIKit.h>

@interface TKESLogViewController : UIViewController
- (instancetype)initWithFilepath:(NSString *)path;
@end
