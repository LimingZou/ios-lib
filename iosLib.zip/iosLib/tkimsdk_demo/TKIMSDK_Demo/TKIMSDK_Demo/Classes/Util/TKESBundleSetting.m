//
//  TKESBundleSetting.m
//  TKIM
//
//  Created by chris on 15/7/1.


#import "TKESBundleSetting.h"

@implementation TKESBundleSetting

+ (instancetype)sharedConfig
{
    static TKESBundleSetting *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKESBundleSetting alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    if(self = [super init]) {
        [self checkDefaultSetting];

        NSDictionary *dict = @{
                               @"exception_upload_log_enabled" : @(NO),
                               @"custom_apns_content_type" : @"custom"
                               };
        [[NSUserDefaults standardUserDefaults] registerDefaults:dict];
    }
    return self;
}

- (void)checkDefaultSetting {
    NSString *settingBundlePath = [[NSBundle mainBundle] pathForResource:@"Settings" ofType:@"bundle"];
    NSString *plistPath = [settingBundlePath stringByAppendingPathComponent:@"Root.plist"];
    NSDictionary *plistDict = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    NSArray *preferences = [plistDict valueForKey:@"PreferenceSpecifiers"];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    for(NSDictionary *setting in preferences) {
        // 如果NSUserDefaults里有，则优先使用UserDefaults里的
        NSString *key = [setting valueForKey:@"Key"];
        
        if (key && key.length>0) {
            // 从Plist中获取值填充
            id value = [setting valueForKey:@"DefaultValue"];
            if(value) {
                [userDefaults setObject:value forKey:key];
            }
        }
    }
}

- (BOOL)removeSessionWheDeleteMessages{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"enabled_remove_recent_session"] boolValue];
}

- (BOOL)localSearchOrderByTimeDesc{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"local_search_time_order_desc"] boolValue];
}


- (BOOL)autoRemoveRemoteSession{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"auto_remove_remote_session"] boolValue];
}

- (BOOL)autoRemoveSnapMessage{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"auto_remove_snap_message"] boolValue];
}

- (BOOL)needVerifyForFriend
{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"add_friend_need_verify"] boolValue];
}


- (NSString *)description
{
    return [NSString stringWithFormat:@"\nenabled_remove_recent_session %d\nlocal_search_time_order_desc %d\n\
auto_remove_remote_session %d\nauto_remove_snap_message %d\nadd_friend_need_verify %d\n",
                                        [self removeSessionWheDeleteMessages],
                                        [self localSearchOrderByTimeDesc],
                                        [self autoRemoveRemoteSession],
                                        [self autoRemoveSnapMessage],
                                        [self needVerifyForFriend]];
}
@end
