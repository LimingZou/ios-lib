//
//  TKESUserDataProvider.h
//  TKIM
//
//  Created by amao on 8/13/15.


#import <Foundation/Foundation.h>
#import "TKIMKitDataProvider.h"

@interface TKESDataProvider : NSObject<TKIMKitDataProvider>

@end
