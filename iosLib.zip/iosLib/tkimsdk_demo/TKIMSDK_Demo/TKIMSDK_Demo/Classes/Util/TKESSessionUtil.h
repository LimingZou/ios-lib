//
//  TKESSessionUtil.h
//  TKIMDemo
//
//  Created by ght on 15-1-27.


#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <TKIMSDK.h>

@interface TKESSessionUtil : NSObject

+ (BOOL)messageIsFromMe:(TKIMMessage *)message;

+ (CGSize)getImageSizeWithImageOriginSize:(CGSize)originSize
                                  minSize:(CGSize)imageMinSize
                                  maxSize:(CGSize)imageMaxSize;

+ (NSString *)showNick:(NSString*)uid inSession:(TKIMSession*)session;


//接收时间格式化
+ (NSString*)showTime:(NSTimeInterval) msglastTime showDetail:(BOOL)showDetail;

+ (void)sessionWithInputURL:(NSURL*)inputURL
                  outputURL:(NSURL*)outputURL
               blockHandler:(void (^)(AVAssetExportSession*))handler;


+ (NSString *)formatedMessage:(TKIMMessage *)message;


@end
