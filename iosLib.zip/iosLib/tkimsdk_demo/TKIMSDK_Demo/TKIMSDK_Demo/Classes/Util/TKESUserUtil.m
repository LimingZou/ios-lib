//
//  TKESUserUtil.m
//  TKIM
//
//  Created by chris on 15/9/17.


#import "TKESUserUtil.h"

@implementation TKESUserUtil

+ (BOOL)isMyFriend:(NSString *)userId{
    for (TKIMUser *user in [TKIMSDK sharedSDK].userManager.myFriends) {
        if ([user.userId isEqualToString:userId]) {
            return YES;
        }
    }
    return NO;
}

+ (NSString *)genderString:(TKIMUserGender)gender{
    NSString *genderStr = @"";
    switch (gender) {
        case TKIMUserGenderMale:
            genderStr = @"男";
            break;
        case TKIMUserGenderFemale:
            genderStr = @"女";
            break;
        case TKIMUserGenderUnknown:
            genderStr = @"未知";
        default:
            break;
    }
    return genderStr;
}

@end
