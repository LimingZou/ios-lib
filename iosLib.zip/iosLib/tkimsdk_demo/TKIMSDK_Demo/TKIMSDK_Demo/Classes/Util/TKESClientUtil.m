//
//  TKESClientUtil.m
//  TKIM
//
//  Created by chris on 15/7/27.


#import "TKESClientUtil.h"

@implementation TKESClientUtil

+ (NSString *)clientName:(TKIMLoginClientType)clientType{
    switch (clientType) {
        case TKIMLoginClientTypeAOS:
        case TKIMLoginClientTypeIOS:
            return @"移动";
        case TKIMLoginClientTypePC:
            return @"电脑";
        case TKIMLoginClientTypeWeb:
            return @"网页";
        default:
            return @"";
    }
}

@end
