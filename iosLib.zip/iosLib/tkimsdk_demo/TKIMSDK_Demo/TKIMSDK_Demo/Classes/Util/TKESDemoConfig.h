//
//  TKESDemoConfig.h
//  TKIM
//
//  Created by amao on 4/21/15.


#import <Foundation/Foundation.h>

@interface TKESDemoConfig : NSObject
+ (instancetype)sharedConfig;

- (NSString *)appKey;
- (NSString *)apiURL;//此处为TretalkDemo应用服务器地址，更换appkey后，请更新为应用自己的服务器接口地址，并提供相关接口服务。
- (NSString *)cerName;

@end
