//
//  TKIMManager.m
//  TKIM
//
//  Created by amao on 11/13/13.

#import "TKESService.h"
#import "TKESSessionUtil.h"

#pragma mark - TKIMServiceManagerImpl
@interface TKIMServiceManagerImpl : NSObject
@property (nonatomic,strong)    NSString                *key;
@property (nonatomic,strong)    NSMutableDictionary     *singletons;
@end


@implementation TKIMServiceManagerImpl

+ (TKIMServiceManagerImpl *)coreImpl:(NSString *)key
{
    TKIMServiceManagerImpl *impl = [[TKIMServiceManagerImpl alloc]init];
    impl.key = key;
    return impl;
}

- (id)init
{
    if (self = [super init])
    {
        _singletons = [[NSMutableDictionary alloc]init];
    }
    return self;
}



- (instancetype)singletonByClass:(Class)singletonClass
{
    NSString *singletonClassName = NSStringFromClass(singletonClass);
    id singleton = [_singletons objectForKey:singletonClassName];
    if (!singleton) {
        singleton = [[singletonClass alloc]init];
        [_singletons setObject:singleton forKey:singletonClassName];
    }
    return singleton;
}

- (void)callSingletonSelector: (SEL)selecotr
{
    NSArray *array = [_singletons allValues];
    for (id obj in array)
    {
        if ([obj respondsToSelector:selecotr])
        {
            SuppressPerformSelectorLeakWarning([obj performSelector:selecotr]);
        }
    }
}

@end

#pragma mark - TKIMServiceManager()
@interface TKESServiceManager ()
@property (nonatomic,strong)    NSRecursiveLock *lock;
@property (nonatomic,strong)    TKIMServiceManagerImpl *core;
+ (instancetype)sharedManager;
- (id)singletonByClass:(Class)singletonClass;
@end

#pragma mark - TKIMService
@implementation TKESService
+ (instancetype)sharedInstance
{
    return [[TKESServiceManager sharedManager] singletonByClass:[self class]];
}

- (void)start
{
    DDLogDebug(@"TKIMService %@ Started", self);
}
@end

#pragma mark - TKIMServiceManager
@implementation TKESServiceManager

+ (instancetype)sharedManager
{
    static TKESServiceManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TKESServiceManager alloc]init];
    });
    return instance;
}

- (id)init
{
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(callReceiveMemoryWarning)
                                                     name:UIApplicationDidReceiveMemoryWarningNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(callEnterBackground)
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(callEnterForeground)
                                                     name:UIApplicationWillEnterForegroundNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(callAppWillTerminate)
                                                     name:UIApplicationWillTerminateNotification
                                                   object:nil];

    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)start {
    [_lock lock];
    NSString *key = [[[TKIMSDK sharedSDK] loginManager] currentAccount];
    _core = [TKIMServiceManagerImpl coreImpl:key];
    [_lock unlock];
}

- (void)destory {
    [_lock lock];
    [self callSingletonClean];
    _core = nil;
    [_lock unlock];
}

- (id)singletonByClass: (Class)singletonClass
{
    id instance = nil;
    [_lock lock];
    instance = [_core singletonByClass:singletonClass];
    [_lock unlock];
    return instance;
}

#pragma mark - Call Functions
- (void)callSingletonClean
{
    [self callSelector:@selector(onCleanData)];
}


- (void)callReceiveMemoryWarning
{
    [self callSelector:@selector(onReceiveMemoryWarning)];
}


- (void)callEnterBackground
{
    [self callSelector:@selector(onEnterBackground)];
}

- (void)callEnterForeground
{
    [self callSelector:@selector(onEnterForeground)];
}

- (void)callAppWillTerminate
{
    [self callSelector:@selector(onAppWillTerminate)];
}

- (void)callSelector: (SEL)selector
{
    [_core callSingletonSelector:selector];
}


@end
